if not ((GAME_LOCALE or GetLocale()) == "esMX") then
  return
end
local addonName, MDT = ...
local L = MDT.L
L = L or {}

-- MDT
L[" >Battle for Azeroth"] = ">Battle for Azeroth"
L[" >Legion"] = ">Legión"
--[[Translation missing --]]
L[" K'aresh Elemental"] = "K'aresh Elemental"
L["%s HP"] = "%s Vida"
L["%s is in sublevel: %s"] = "%s Está en el subnivel: %s"
L["(G %d)"] = "(G %d)"
L["*Live*"] = "*Directo*"
L["+ Add pull"] = "+ Añadir pull"
--[[Translation missing --]]
L["<New Preset>"] = "<New Route>"
--[[Translation missing --]]
L["> More Dungeons"] = "> More Dungeons"
L["4.RF-4.RF"] = "GU.4U-GU.4U"
L["Aberration"] = "Aberración"
L["Abstract Nullifier"] = "Nulificador abstracto"
L["Abyss Dweller"] = "Habitante del abismo"
L["Abyssal Cultist"] = "Cultor abisal"
L["Abyssal Eel"] = "Anguila abisal"
L["Achillite"] = "Achillite"
L["Acidic Bile"] = "Bilis ácida"
L["Acolyte"] = "Acólito"
L["Adderis"] = "Adderis"
L["Addled Arcanomancer"] = "Arcanomántico desconcertado"
L["Addled Thug"] = "Matón desconcertado"
--[[Translation missing --]]
L["AddOn Conflict"] = "AddOn Conflict"
L["Adorned Starseer"] = "Vidente estelar adornado"
L["Advent Nevermore"] = "Venida Nuncamás"
L["Advisor Melandrus"] = "Consejero Melandrus"
L["Aerial Unit R-21/X"] = "Unidad aérea R-21/X"
L["Affected by:"] = "Afectado por:"
L["Affixes"] = "Afijos"
--[[Translation missing --]]
L["Afflicted Civilian"] = "Afflicted Civilian"
L["Aggravated Skitterfly"] = "Escurriposa agravada"
--[[Translation missing --]]
L["Agile Pursuer"] = "Agile Pursuer"
L["Agitated Nimbus"] = "Nimbo inquieto"
L["Agronox"] = "Agronox"
L["Ahn'kahar Slasher"] = "Mutilador Ahn'kahar"
L["Ahn'kahar Spell Flinger"] = "Lanzahechizos Ahn'kahar"
L["Ahn'kahar Swarmer"] = "Enjambrista Ahn'kahar"
L["Ahn'kahar Watcher"] = "Vigía Ahn'kahar"
L["Ahn'kahar Web Winder"] = "Tejemarañas Ahn'kahar"
--[[Translation missing --]]
L["Ahn'kahet: The Old Kingdom"] = "Ahn'kahet: The Old Kingdom"
L["Ahnzon"] = "Ahnzon"
L["Ahri'ok Dugru"] = "Ahri'ok Dugru"
L["Aka'ali the Conqueror"] = "Aka'ali la Conquistadora"
L["Alarm-o-Bot"] = "Roboalarma"
L["Alcruux"] = "Alcruux"
L["Algeth'ar Echoknight"] = "Caballero del eco de Algeth'ar"
--[[Translation missing --]]
L["AlgetharAcademy"] = "Algeth'ar Academy"
--[[Translation missing --]]
L["algetharShortName"] = "AA"
L["Alliance Archer"] = "Arquero de la Alianza"
L["Alliance Berserker"] = "Rabioso de la Alianza"
L["Alliance Cleric"] = "Clérigo de la Alianza"
L["Alliance Conjuror"] = "Conjuradora de la Alianza"
L["Alliance Destroyer"] = "Destructor de la Alianza"
L["Alliance Footman"] = "Lacayo de la Alianza"
L["Alliance Knight"] = "Caballero de la Alianza"
L["Alliance Ranger"] = "Forestal de la Alianza"
L["Alpha Eagle"] = "Águila alfa"
L["Altairus"] = "Altairus"
--[[Translation missing --]]
L["AltarOfShadow"] = "Altar of Shadow"
--[[Translation missing --]]
L["altKeyDownStatusText"] = "Showing enemy group numbers"
--[[Translation missing --]]
L["altKeyGroupsTip"] = "Hold ALT to show enemy group numbers on all enemies"
L["Amalgam of Souls"] = "Amalgama de almas"
L["Amanitar"] = "Amanitar"
L["Amarth"] = "Amarth"
L["Ancient Captain"] = "Capitán ancestral"
L["Ancient Core Hound"] = "Can del Núcleo anciano"
L["Ancient Tome"] = "Tomo antiguo"
L["Anduin Lothar"] = "Anduin Lothar"
L["Angerhoof Bull"] = "Astado Uñainquina"
--[[Translation missing --]]
L["Angry Hound"] = "Angry Hound"
--[[Translation missing --]]
L["Anima Fountain"] = "Anima Fountain"
L["Animated Droplet"] = "Gota animada"
L["Animated Guardian"] = "Guardián animado"
--[[Translation missing --]]
L["Animated Shadow"] = "Animated Shadow"
L["Animated Storm"] = "Tormenta animada"
L["Animated Weapon"] = "Arma animada"
L["Anodized Coilbearer"] = "Portabobina anodizado"
L["Anomalus"] = "Anomalus"
L["Anub'ar Champion"] = "Campeón Anub'ar"
L["Anub'ar Crusher"] = "Triturador Anub'ar"
L["Anub'ar Crypt Fiend"] = "Maligno de cripta Anub'ar"
L["Anub'ar Necromancer"] = "Nigromante Anub'ar"
L["Anub'ar Prime Guard"] = "Guardia principal Anub'ar"
L["Anub'ar Shadowcaster"] = "Taumaturgo umbrío Anub'ar"
L["Anub'ar Skirmisher"] = "Hostigador Anub'ar"
L["Anub'ar Warrior"] = "Guerrero Anub'ar"
L["Anub'ar Webspinner"] = "Tejerred Anub'ar"
L["Anub'arak"] = "Anub'arak"
--[[Translation missing --]]
L["Anubikkaj"] = "Anubikkaj"
L["Anub'Rekhan"] = "Anub'Rekhan"
--[[Translation missing --]]
L["Anubzekt"] = "Anubzekt"
L["Apex Blazewing"] = "Alardiente alfa"
L["Apply to preset"] = "Aplicar a ruta"
L["Aqua Rager"] = "Furibundo acuático"
L["Aqu'sirr"] = "Aqu'sirr"
L["Arachnopod Destroyer"] = "Destructor aracnópodo"
--[[Translation missing --]]
L["AraKara"] = "Ara-Kara"
--[[Translation missing --]]
L["araKaraItemDescription"] = "Usable by Khaz Algar Tailors (25)"
--[[Translation missing --]]
L["araKaraShortName"] = "ARAK"
L["Aranasi Broodmother"] = "Madre de linaje aranasi"
--[[Translation missing --]]
L["Arathi Footman"] = "Arathi Footman"
--[[Translation missing --]]
L["Arathi Knight"] = "Arathi Knight"
--[[Translation missing --]]
L["Arathi Neophyte"] = "Arathi Neophyte"
L["Arcane Anomaly"] = "Anomalía Arcana"
L["Arcane Construct"] = "Ensamblaje Arcano"
L["Arcane Elemental"] = "Elemental Arcano"
L["Arcane Eye"] = "Ojo Arcano"
L["Arcane Forager"] = "Batidor Arcano"
L["Arcane Manifestation"] = "Manifestación Arcana"
L["Arcane Minion"] = "Esbirro Arcano"
L["Arcane Ravager"] = "Devastador Arcano"
--[[Translation missing --]]
L["Arcane Siphon"] = "Arcane Siphon"
L["Arcane Tender"] = "Cuidador Arcano"
L["Arcane Warden"] = "Celador arcano"
L["Arcanid"] = "Arcánido"
L["Archdruid Glaidalis"] = "Archidruida Glaidalis"
L["Archmage Sol"] = "Archimaga Sol"
--[[Translation missing --]]
L["arcwayShortName"] = "ARC"
--[[Translation missing --]]
L["Ardent Paladin"] = "Ardent Paladin"
--[[Translation missing --]]
L["Ardenweald"] = "Ardenweald"
L["Armored Mistral"] = "Mistral acorazado"
L["Armored Overseer"] = "Sobrestante acorazado"
--[[Translation missing --]]
L["Armsmaster Harlan"] = "Armsmaster Harlan"
L["Asaad"] = "Asaad"
--[[Translation missing --]]
L["Ascendant Viscoxria"] = "Ascendant Viscoxria"
--[[Translation missing --]]
L["Ascended Aristocrat"] = "Ascended Aristocrat"
L["Ash'Golm"] = "Ceniz'golm"
L["Ashvane Cannoneer"] = "Cañonero de los Gobernalle"
L["Ashvane Commander"] = "Comandante Gobernalle"
L["Ashvane Deckhand"] = "Marinero de cubierta de los Gobernalle"
L["Ashvane Destroyer"] = "Destructor de los Gobernalle"
L["Ashvane Flamecaster"] = "Taumaturga ígnea de los Gobernalle"
L["Ashvane Invader"] = "Invasor de los Gobernalle"
L["Ashvane Jailer"] = "Carcelero de los Gobernalle"
L["Ashvane Marine"] = "Marino de los Gobernalle"
L["Ashvane Officer"] = "Oficial de los Gobernalle"
L["Ashvane Priest"] = "Sacerdotisa de los Gobernalle"
L["Ashvane Sniper"] = "Francotirador de los Gobernalle"
L["Ashvane Spotter"] = "Avistador de los Gobernalle"
L["Ashvane Warden"] = "Celador de los Gobernalle"
--[[Translation missing --]]
L["Aspiring Forgehand"] = "Aspiring Forgehand"
L["Aspix"] = "Aspix"
L["Asset Manager"] = "Responsable de activos"
--[[Translation missing --]]
L["assignmentWarning"] = "MDT will NOT automatically set target markers on enemies in the game world."
--[[Translation missing --]]
L["Assistant Unnaturaler"] = "Assistant Unnaturaler"
L["Astral Attendant"] = "Auxiliar astral"
L["Astronos"] = "Astronos"
L["Atal'ai Deathwalker"] = "Caminamuerte Atal'ai"
L["Atal'ai Devoted"] = "Devoto Atal'ai"
L["Atal'ai High Priest"] = "Sumo sacerdote Atal'ai"
L["Atal'ai Hoodoo Hexxer"] = "Aojador hudú Atal'ai"
L["Atal'Dazar"] = "Atal'Dazar"
L["Atal'Dazar Sublevel"] = "Subnivel de Atal'Dazar"
--[[Translation missing --]]
L["atalDazarShortName"] = "AD"
L["atalTeemingNote"] = "Nota en Bullente:%s&sG29 no siempre presente.%sEnemigos Bullentes de G2 no siempre presentes.%sG27 no siempre presente"
--[[Translation missing --]]
L["Athenaeum"] = "Athenaeum"
--[[Translation missing --]]
L["Atik"] = "Atik"
L["Atrium of Sethraliss"] = "Atrio de Sethraliss"
--[[Translation missing --]]
L["Attumen the Huntsman"] = "Attumen the Huntsman"
L["Auriaya"] = "Auriaya"
L["Automatic Coloring"] = "Coloreo automático"
L["Automatically color pulls"] = "Colorea automáticamente pulls"
--[[Translation missing --]]
L["Avanoxx"] = "Avanoxx"
L["Avatar of Sethraliss"] = "Avatar de Sethraliss"
L["Awakened"] = "Despierta"
L["Awakened A"] = "Despierta A"
L["Awakened B"] = "Despierta B"
--[[Translation missing --]]
L["A'wazj"] = "A'wazj"
L["Azerite Extractor"] = "Extractor de azerita"
--[[Translation missing --]]
L["Azerite Footbomb"] = "Azerite Footbomb"
L["Azerokk"] = "Azerokk"
--[[Translation missing --]]
L["Azhiccar"] = "Azhiccar"
--[[Translation missing --]]
L["Azjol-Nerub"] = "Azjol-Nerub"
L["Azules"] = "Azules"
L["Azure Captain"] = "Capitán azur"
L["Azure Enforcer"] = "Déspota azur"
L["Azure Inquisitor"] = "Inquisidor azur"
L["Azure Invader"] = "Invasor azur"
L["Azure Ley-Whelp"] = "Cría-Ley azur"
L["Azure Magus"] = "Magus azur"
L["Azure Raider"] = "Asaltante azur"
L["Azure Scale-Binder"] = "Vinculador de escamas azur"
--[[Translation missing --]]
L["Azure Serpent"] = "Azure Serpent"
L["Azure Sorcerer"] = "Hechicera azur"
L["Azure Spellbinder"] = "Vinculahechizos azur"
L["Azure Stalker"] = "Acechador azur"
L["Azure Warder"] = "Depositario azur"
L["Azureblade"] = "Filoazur"
--[[Translation missing --]]
L["azureVaultShortName"] = "AV"
--[[Translation missing --]]
L["B.O.O.M.B.A."] = "B.O.O.M.B.A."
L["Baalgar the Watchful"] = "Baalgar el Vigilante"
L["Backup Singer"] = "Cantante suplente"
L["Baelog"] = "Baelog"
L["Balakar Khan"] = "Balakar Khan"
L["Balara"] = "Balara"
--[[Translation missing --]]
L["Band of Acceleration"] = "Band of Acceleration"
--[[Translation missing --]]
L["Band of Alignment"] = "Band of Alignment"
--[[Translation missing --]]
L["Band of Transmutation"] = "Band of Transmutation"
--[[Translation missing --]]
L["Band of Variance"] = "Band of Variance"
L["Banish"] = "Desterrar"
L["Banquet Steward"] = "Camarero de banquete"
L["Barbed Spiderling"] = "Arañita espinosa"
--[[Translation missing --]]
L["Baron Braunpyke"] = "Baron Braunpyke"
L["Baron Rivendare"] = "Barón Osahendido"
L["Batak"] = "Batak"
--[[Translation missing --]]
L["Battered"] = "Battered"
--[[Translation missing --]]
L["Battle for Azeroth"] = "Battle for Azeroth"
--[[Translation missing --]]
L["Battle Scarab"] = "Battle Scarab"
L["Battlefield Ritualist"] = "Ritualista del campo de batalla"
--[[Translation missing --]]
L["Bazaar Overseer"] = "Bazaar Overseer"
--[[Translation missing --]]
L["Bazaar Strongarm"] = "Bazaar Strongarm"
L["Beast"] = "Bestia"
--[[Translation missing --]]
L["Bee Wrangler"] = "Bee Wrangler"
--[[Translation missing --]]
L["Bee-let"] = "Bee-let"
L["Befouled Spirit"] = "Espíritu contaminado"
L["Beguiling"] = "Cautivadora"
L["Beguiling 1 Void"] = "Cautivadora Emisaria tocada por el Vacío"
L["Beguiling 2 Tides"] = "Cautivadora Emisaria de las mareas"
L["Beguiling 3 Ench."] = "Cautivadora Emisaria encantada"
--[[Translation missing --]]
L["Benk Buzzbee"] = "Benk Buzzbee"
L["Bewitched Captain"] = "Capitán aojado"
--[[Translation missing --]]
L["BFA"] = "Battle for Azeroth"
--[[Translation missing --]]
L["Big M.O.M.M.A."] = "Big M.O.M.M.A."
L["Big Money Crab"] = "Cangrejo acaudalado"
L["Bile Golem"] = "Gólem bílico"
L["Bile Retcher"] = "Arcadano bílico"
L["Bilespray Lasher"] = "Azotador de espuma biliar"
L["Bilge Rat Brinescale"] = "Escamasalada de las Ratas de Pantoque"
L["Bilge Rat Buccaneer"] = "Bucanero de las Ratas de Pantoque"
L["Bilge Rat Cutthroat"] = "Degollador de las Ratas de Pantoque"
L["Bilge Rat Demolisher"] = "Demoledor de las Ratas de Pantoque"
L["Bilge Rat Looter"] = "Despojador de las Ratas de Pantoque"
L["Bilge Rat Padfoot"] = "Piesuaves de las Ratas de Pantoque"
L["Bilge Rat Pillager"] = "Saqueador de las Ratas de Pantoque"
L["Bilge Rat Seaspeaker"] = "Orador del mar de las Ratas de Pantoque"
L["Bilge Rat Swabby"] = "Bisoño de las Ratas de Pantoque"
L["Bilge Rat Tempest"] = "Tempestad de las Ratas de Pantoque"
L["Bilge Rats"] = "Ratas de Pantoque"
L["Binder Ashioi"] = "Vinculadora Ashioi"
--[[Translation missing --]]
L["Binding Javelin"] = "Binding Javelin"
L["Bitterbrine Scavenger"] = "Carroñero Morroacre"
L["Bitterbrine Slave"] = "Esclavo Morroacre"
L["Black and Yellow"] = "Amarillo y Negro"
--[[Translation missing --]]
L["Black Blood"] = "Black Blood"
L["Black Rook Hold"] = "Torreón Grajo Negro"
--[[Translation missing --]]
L["blackrookHoldShortName"] = "BRH"
L["Blacktar Bomber"] = "Bombardero Breanegra"
L["Blacktooth"] = "Dientenegro"
L["Blacktooth Arsonist"] = "Pirómano Dientenegro"
L["Blacktooth Brute"] = "Tosco Dientenegro"
L["Blacktooth Knuckleduster"] = "Nudillos Dientenegro"
L["Blacktooth Scrapper"] = "Desguazador Dientenegro"
L["Blade Dancer Illianna"] = "Bailarina de hojas Illiana"
L["Bladebeak Hatchling"] = "Cría de picoespada"
L["Bladebeak Matriarch"] = "Matriarca picoespada"
L["Blastatron X-80"] = "Detonatrón X-80"
L["Blazebound Destroyer"] = "Destructor vinculado a las llamas"
--[[Translation missing --]]
L["Blazebound Firestorm"] = "Blazebound Firestorm"
--[[Translation missing --]]
L["Blazikon"] = "Blazikon"
--[[Translation missing --]]
L["Blazing Fiend"] = "Blazing Fiend"
L["Blazing Imp"] = "Diablillo llameante"
--[[Translation missing --]]
L["Bleed"] = "Bleed"
L["Blight Bag"] = "Bolsa de añublo"
L["Blight Chunk"] = "Trozo de añublo"
L["Blight of Galakrond"] = "Añublo de Galakrond"
L["Blight Toad"] = "Sapo de añublo"
L["Blightbone"] = "Huesoañublo"
L["Blighted Sludge-Spewer"] = "Vomitalodos contagiado"
L["Blighted Spinebreaker"] = "Partemédulas contagiado"
L["Blightshard Shaper"] = "Modelador Pizcañublo"
L["Blistering Steamrager"] = "Furibundo de vapor virulento"
--[[Translation missing --]]
L["Bloated Brew Alemental"] = "Bloated Brew Alemental"
L["Block Warden"] = "Celador del módulo"
L["Blood of the Corruptor"] = "Sangre del Corruptor"
--[[Translation missing --]]
L["Blood Overseer"] = "Blood Overseer"
L["Bloodscent Felhound"] = "Can manáfago Sangresencia"
--[[Translation missing --]]
L["Bloodstained Assistant"] = "Bloodstained Assistant"
--[[Translation missing --]]
L["Bloodstained Webmage"] = "Bloodstained Webmage"
L["Bloodsworn Agent"] = "Agente Jurasangre"
L["Bloodsworn Defiler"] = "Profanador Jurasangre"
L["Bloodtainted Fury"] = "Furia manchada de sangre"
L["Bloodthirsty Cub"] = "Cachorro sanguinario"
L["Bloodthirsty Tundra Wolf"] = "Lobo de tundra sanguinario"
--[[Translation missing --]]
L["Bloodworker"] = "Bloodworker"
--[[Translation missing --]]
L["Bloody Javelin"] = "Bloody Javelin"
L["Bolstering"] = "Potenciante"
L["Bomb Tonk"] = "Bomba potente"
--[[Translation missing --]]
L["Bombshell Crab"] = "Bombshell Crab"
L["Bone Magus"] = "Magus osario"
L["Bonebolt Hunter"] = "Cazador sacudehuesos"
L["Bonegrinder"] = "Muelehuesos"
L["Bonemaw"] = "Quijahueso"
--[[Translation missing --]]
L["Boneweaver"] = "Boneweaver"
L["Bony Construct"] = "Ensamblaje huesudo"
L["Boomer XP-500"] = "Tomabum XP-500"
--[[Translation missing --]]
L["Bored Student"] = "Bored Student"
L["Borka the Brute"] = "Borka el Bruto"
L["Bottom Feeder"] = "Limpiafondos"
L["Bound Air Elemental"] = "Elemental de aire esclavo"
L["Bound Energy"] = "Energía contenida"
L["Bound Fire Elemental"] = "Elemental de fuego esclavo"
L["Bound Voidlord"] = "Señor del Vacío esclavizado"
L["Bound Water Elemental"] = "Elemental de agua esclavo"
--[[Translation missing --]]
L["Bounty Hunter"] = "Bounty Hunter"
--[[Translation missing --]]
L[ [=[Bounty stacks 
after this pull]=] ] = [=[Bounty stacks 
after this pull]=]
--[[Translation missing --]]
L[ [=[Bounty stacks 
after this pull]=] ] = ""
--[[Translation missing --]]
L[ [=[Bounty stacks
after this pull]=] ] = ""
L["Bracken Warscourge"] = "Azote de guerra Frondacuero"
L["Brackenhide Shaper"] = "Modeladora Frondacuero"
--[[Translation missing --]]
L["brackenhideCage"] = "Meat Storage"
--[[Translation missing --]]
L["BrackenhideHollow"] = "Brackenhide Hollow"
--[[Translation missing --]]
L["brackenhideShortName"] = "BH"
L["Brain of Yogg-Saron"] = "Cerebro de Yogg-Saron"
L["Brawling Patron"] = "Cliente camorrista"
--[[Translation missing --]]
L["Brew Drop"] = "Brew Drop"
--[[Translation missing --]]
L["brewItemADescription"] = "Usable by Gnomes, Mechagnomes, Goblins or Khaz Algar Engineers (25)"
--[[Translation missing --]]
L["brewItemBDescription"] = "Usable by Khaz Algar Alchemists (25) or Khaz Algar Cooks (25)"
--[[Translation missing --]]
L["Brewmaster Aldryr"] = "Brewmaster Aldryr"
L["Brittlebone Crossbowman"] = "Ballestero de huesos frágiles"
L["Brittlebone Mage"] = "Mago de huesos frágiles"
L["Brittlebone Warrior"] = "Guerrero de huesos frágiles"
L["Bromach"] = "Bromach"
--[[Translation missing --]]
L["Bront"] = "Bront"
L["Brood Ambusher"] = "Emboscador de linaje"
L["Brood Assassin"] = "Asesino de linaje"
L["Brother Ironhull"] = "Hermano Cascoférreo"
--[[Translation missing --]]
L["Brother Korloff"] = "Brother Korloff"
L["Brush Size"] = "Tamaño del Pincel"
L["Brutal Spire of Ny'alotha"] = "Aguja brutal de Ny'alotha"
--[[Translation missing --]]
L["Bubbles"] = "Bubbles"
--[[Translation missing --]]
L["Bubbling Ooze"] = "Bubbling Ooze"
L["Burly Deckhand"] = "Marinero de cubierta fornido"
L["Burly Rock-Thrower"] = "Lanzapiedras fortachón"
L["Burning Geode"] = "Geoda ardiente"
--[[Translation missing --]]
L["Burrowing Creeper"] = "Burrowing Creeper"
L["Bursting"] = "Detonante"
L["Cancel"] = "Cancelar"
--[[Translation missing --]]
L["Candlestick Mage"] = "Candlestick Mage"
L["CannonNote"] = "Cañón pesado%sUtilizable por los jugadores%sde Daño tanto a enemigos como a aliados"
L["Cannot create preset '%s'"] = "No se puede crear la ruta '%s'"
--[[Translation missing --]]
L["Cannot export while in combat"] = "Cannot export while in combat"
--[[Translation missing --]]
L["Cannot import while in combat"] = "Cannot import while in combat"
L["Cannot rename preset to '%s'"] = "No se puede renombrar la ruta a '%s'"
--[[Translation missing --]]
L["Captain Dailcry"] = "Captain Dailcry"
L["Captain Eudora"] = "Capitana Eudora"
L["Captain Jolly"] = "Capitán Jolly"
L["Captain Raoul"] = "Capitán Raoul"
--[[Translation missing --]]
L["Careless Hopgoblin"] = "Careless Hopgoblin"
L["Carrion Spinner"] = "Hilandera carroñera"
L["Carrion Worm"] = "Gusano carroñero"
--[[Translation missing --]]
L["Cartel Lackey"] = "Cartel Lackey"
L["Cartel Muscle"] = "Matón del cártel"
L["Cartel Skulker"] = "Vagador del cártel"
L["Cartel Smuggler"] = "Contrabandista del cártel"
L["Cartel Wiseguy"] = "Mafioso del cártel"
L["Catacombs"] = "Catacumbas"
L["Cathedral of Eternal Night"] = "Catedral de la Noche Eterna"
--[[Translation missing --]]
L["cathedralOfEternalNightShortName"] = "COEN"
L["Cavern Seeker"] = "Buscador de la caverna"
L["Centrifuge Construct"] = "Ensamblaje de centrifugadora"
--[[Translation missing --]]
L["Chamber of Flames"] = "Chamber of Flames"
--[[Translation missing --]]
L["Chamber of Summoning"] = "Chamber of Summoning"
L["Chamber Overseer"] = "Sobrestante de la cámara"
L["Chamber Sentinel"] = "Centinela de la cámara"
--[[Translation missing --]]
L["ChamberOfFlames"] = "Chamber of Flames"
L["Champion Druna"] = "Campeona Druna"
L["Champion of Hodir"] = "Campeón de Hodir"
--[[Translation missing --]]
L["Change Language"] = "Change Language"
L["Channeler Varisz"] = "Canalizadora Varisz"
L["Chaotic Rift"] = "Falla caótica"
L["Chargath, Bane of Scales"] = "Chargath, Perdición de las Escamas"
L["Charged Dust Devil"] = "Diablesa de polvo cargado"
--[[Translation missing --]]
L["chatNoninteractiveWarning"] = "Chat frame is currently set to noninteractive, you will not be able to click on MDT routes."
--[[Translation missing --]]
L["Chef Chewie"] = "Chef Chewie"
L["Choose Enemy Forces Format"] = "Elige el Formato de Fuerzas Enemigas"
L["Choose Enemy Style. Requires Reload"] = "Elige el Estilo de Enemigos. Requiere recargar"
L["Choose NPC tooltip position"] = "Elige una posición para la descripción emergente del PNJ"
L["Choose number of colors"] = "Elige el número de colores"
L["Choose preferred color palette"] = "Elija la paleta de colores preferida"
L["Chopper Redhook"] = "Cortador Ganchorrojo"
L["Chosen Blood Matron"] = "Matriarca de sangre elegida"
L["Chromie"] = "Cromi"
L["Chronaxie"] = "Chronaxie"
L["Chronikar"] = "Chronikar"
L["Chrono-Lord Deios"] = "Cronolord Deios"
L["Chrono-Lord Epoch"] = "Cronolord Época"
--[[Translation missing --]]
L["Cinderbrew Meadery"] = "Cinderbrew Meadery"
--[[Translation missing --]]
L["cinderbrewShortName"] = "MEAD"
--[[Translation missing --]]
L["CityofEchoes"] = "CityofEchoes"
--[[Translation missing --]]
L["CityOfThreads"] = "City of Threads"
--[[Translation missing --]]
L["cityOfThreadsShortName"] = "COT"
L["Claw Fighter"] = "Luchador de zarpa"
--[[Translation missing --]]
L["Clear all Markers"] = "Clear all Markers"
L["Click the fullscreen button for a maximized view of MDT."] = "Haz click en el botón de pantalla completa para maximizar la vista de MDT."
L["Click to adjust color settings"] = "Click para ajustar los ajustes de color"
--[[Translation missing --]]
L["Click to assign player"] = "Click to assign player"
L["Click to go to %s"] = "Click para ir a %s"
L["Click to set dungeon level to 10"] = "Click para establecer una mazmorra al nivel 10"
L["Click to switch to current week"] = "Click para cambiar a la semana actual"
L["Click to toggle AddOn Window"] = [=[Click para activar la ventana de AddOn
,]=]
L["Clicking this button will attempt to join the ongoing Live Session of your group or create a new one if none is found"] = "Haciendo click en este botón intentarás unirte a la Sesión en Directo en marcha de uno de tu grupo o crear una nueva si no se encuentra ninguna"
L["Clockwork Sapper"] = "Zapador de relojería"
--[[Translation missing --]]
L["Close"] = "Close"
L["Cloud Prince"] = "Príncipe de las Nubes"
L["Coalesced Moment"] = "Momento combinado"
L["Coalesced Time"] = "Tiempo fusionado"
--[[Translation missing --]]
L["Coalescing Void Diffuser"] = "Coalescing Void Diffuser"
L["Coastwalker Goliath"] = "Goliat caminacostas"
L["Coin-Operated Crowd Pummeler"] = "Repartetundas de pago"
L["Coldmist Stalker"] = "Acechador Bruma Fría"
L["Coldmist Widow"] = "Viuda Bruma Fría"
L["Color Blind Friendly"] = "Modo para daltónicos"
L["Colorpicker"] = "Selector de color"
L["Colossal Tentacle"] = "Tentáculo colosal"
--[[Translation missing --]]
L["Combat Transparency"] = "Combat Transparency"
--[[Translation missing --]]
L["Commander Durand"] = "Commander Durand"
L["Commander Kolurg"] = "Comandante Kolurg"
--[[Translation missing --]]
L["Commander Lindon"] = "Commander Lindon"
--[[Translation missing --]]
L["Commander Ri'mok"] = "Commander Ri'mok"
L["Commander Shemdah'sohn"] = "Comandante Shemdah'sohn"
L["Commander Stoutbeard"] = "Comandante Barbarrecia"
L["Commander Ulthok"] = "Comandante Ulthok"
--[[Translation missing --]]
L["Commander Vo'jak"] = "Commander Vo'jak"
L["Commander Zo'far"] = "Comandante Zo'far"
L["Commerce Enforcer"] = "Déspota comercial"
--[[Translation missing --]]
L["conflictPrompt"] = [=[MDT has detected that you have certain AddOns installed that are conflicting with MDT.

Please remove or update the following AddOns:

]=]
--[[Translation missing --]]
L["Congealed Droplet"] = "Congealed Droplet"
L["Congealed Slime"] = "Baba coagulada"
L["Conjured Lasher"] = "Azotador conjurado"
--[[Translation missing --]]
L["ConnectedTip"] = "Group connections in MDT do not reflect if NPCs are linked together in the game world."
--[[Translation missing --]]
L["Consuming Sha"] = "Consuming Sha"
L["Containment Apparatus"] = "Aparato de contención"
L["Control Undead"] = "Controlar no-muerto"
--[[Translation missing --]]
L["Cooking Pot"] = "Cooking Pot"
--[[Translation missing --]]
L["copiedToClipboard"] = "copied!"
L["Copy"] = "Copiar"
--[[Translation missing --]]
L["Copy error"] = "Copy error"
L["Cordana Felsong"] = "Cordana Cantovil"
L["Corpse Collector"] = "Recolector de cadáveres"
L["Corpse Harvester"] = "Cosechacadáveres"
L["Corpse Skitterling"] = "Arañuelo cadáver"
--[[Translation missing --]]
L["Corridor Creeper"] = "Corridor Creeper"
--[[Translation missing --]]
L["Corridor Sleeper"] = "Corridor Sleeper"
L["Corrupt Droplet"] = "Gotita corrupta"
L["Corrupt Living Water"] = "Agua viviente corrupta"
L["Corrupted Manafiend"] = "Maligno de maná corrupto"
--[[Translation missing --]]
L["Corrupted Oracle"] = "Corrupted Oracle"
L["Corrupted Scroll"] = "Pergamino corrupto"
L["Corrupted Servitor"] = "Servidor corrupto"
--[[Translation missing --]]
L["Corsair Brute"] = "Corsair Brute"
L["Corsair Officer"] = "Oficial corsario"
L["Corstilax"] = "Corstilax"
L["Court of Stars"] = "Corte de las Estrellas"
L["Court of Stars Sublevel"] = "Subnivel de Corte de las Estrellas"
--[[Translation missing --]]
L["courtOfStarsShortName"] = "COS"
L["Cove Seagull"] = "Gaviota de cala"
L["Coven Diviner"] = "Adivina del aquelarre"
L["Coven Thornshaper"] = "Urdespina del aquelarre"
--[[Translation missing --]]
L["Covert Webmancer"] = "Covert Webmancer"
L["Cragmaw the Infested"] = "Bocarrisco el Infestado"
L["Crawler Mine"] = "Mina reptadora"
L["Crawth"] = "Crawth"
L["Crazed Incubator"] = "Incubador enloquecido"
L["Crazed Mana-Surge"] = "Oleada de maná enloquecido"
L["Crazed Mana-Wraith"] = "Espectro de maná enloquecido"
L["Crazed Marksman"] = "Tirador enloquecido"
L["Crazed Razorbeak"] = "Picovaja enloquecido"
L["Create"] = "Crear"
L["Create a new preset"] = "Crear una nueva ruta"
L["Creepy Crawler"] = "Reptador espeluznante"
L["Critter"] = "Alimañas"
L["Cruel Bonecrusher"] = "Aplastahuesos cruel"
--[[Translation missing --]]
L["Crusaders' Chapel"] = "Crusaders' Chapel"
L["Crypt Fiend"] = "Maligno de cripta"
L["Crypt Reaver"] = "Atracador de la cripta"
--[[Translation missing --]]
L["CryptOfTheAncients"] = "Crypt of the Ancients"
L["Crystal Fury"] = "Furia de cristal"
--[[Translation missing --]]
L["Crystal Shard"] = "Crystal Shard"
L["Crystal Thrasher"] = "Descarnador de cristal"
--[[Translation missing --]]
L["CrystalChamber"] = "Crystal Chamber"
L["Crystalline Frayer"] = "Rasgador cristalino"
L["Crystalline Keeper"] = "Vigilante cristalino"
L["Crystalline Protector"] = "Protector cristalino"
L["Crystalline Shardling"] = "Fragmentizo cristalino"
L["Crystalline Tender"] = "Cuidadora cristalina"
--[[Translation missing --]]
L["ctrlKeyCountTip"] = "Hold CTRL to show enemy forces on all enemies"
--[[Translation missing --]]
L["ctrlKeyDownStatusText"] = "Showing enemy forces"
L["Curious Swoglet"] = "Cornisapito curioso"
--[[Translation missing --]]
L["Curse"] = "Curse"
L["Cursed Falke"] = "Falco maldito"
--[[Translation missing --]]
L["Cursed Rookguard"] = "Cursed Rookguard"
--[[Translation missing --]]
L["Cursed Rooktender"] = "Cursed Rooktender"
L["Cursed Spire of Ny'alotha"] = "Aguja maldita de Ny'alotha"
--[[Translation missing --]]
L["Cursed Thunderer"] = "Cursed Thunderer"
--[[Translation missing --]]
L["Cursedforge Honor Guard"] = "Cursedforge Honor Guard"
--[[Translation missing --]]
L["Cursedforge Mender"] = "Cursedforge Mender"
--[[Translation missing --]]
L["Cursedforge Stoneshaper"] = "Cursedforge Stoneshaper"
--[[Translation missing --]]
L["Cursedheart Invader"] = "Cursedheart Invader"
L["Custom"] = "Personalizar"
L["Custom Color Palette"] = "Personalizar Paleta de Color"
L["Customs Security"] = "Seguridad aduanera"
L["Cutwater"] = "Aguacortada"
L["Cutwater Duelist"] = "Duelista Aguacortada"
L["Cutwater Harpooner"] = "Arponero Aguacortada"
L["Cutwater Knife Juggler"] = "Malabarista de cuchillos Aguacortada"
L["Cutwater Striker"] = "Asediador Aguacortada"
L["Cyanigosa"] = "Cianigosa"
L["Cyclone"] = "Ciclón"
--[[Translation missing --]]
L["Cyclone Summit"] = "Cyclone Summit"
L["Dalronn the Controller"] = "Dalronn el Controlador"
L["Damaged Golem"] = "Gólem dañado"
--[[Translation missing --]]
L["Dantalionax"] = "Dantalionax"
L["Dargrul"] = "Dargrul"
L["Dark Acolyte"] = "Acólita oscura"
L["Dark Necromancer"] = "Nigromante oscuro"
L["Dark Rune Controller"] = "Controlador Runa Oscura"
L["Dark Rune Elementalist"] = "Elementalista Runa Oscura"
L["Dark Rune Giant"] = "Gigante Runa Oscura"
L["Dark Rune Ravager"] = "Devastador Runa Oscura"
L["Dark Rune Scholar"] = "Erudito Runa Oscura"
L["Dark Rune Shaper"] = "Modelador Runa Oscura"
L["Dark Rune Theurgist"] = "Teúrgo Runa Oscura"
L["Dark Rune Thunderer"] = "Tronador Runa Oscura"
L["Dark Rune Warrior"] = "Guerrero Runa Oscura"
L["Dark Rune Worker"] = "Trabajador Runa Oscura"
L["Dark Touched Warrior"] = "Guerrero tocado por la oscuridad"
--[[Translation missing --]]
L["Darkflame Cleft"] = "Darkflame Cleft"
--[[Translation missing --]]
L["darkflameDespawns"] = "Unkilled enemies in this area will despawn after the mine cart event"
--[[Translation missing --]]
L["darkflameShortName"] = "DFC"
--[[Translation missing --]]
L["darkflameSpawns"] = "Corridor Creepers and Skittering Darkness will spawn after the mine cart event"
--[[Translation missing --]]
L["Darkfuse Bloodwarper"] = "Darkfuse Bloodwarper"
--[[Translation missing --]]
L["Darkfuse Demolitionist"] = "Darkfuse Demolitionist"
--[[Translation missing --]]
L["Darkfuse Hyena"] = "Darkfuse Hyena"
--[[Translation missing --]]
L["Darkfuse Inspector"] = "Darkfuse Inspector"
--[[Translation missing --]]
L["Darkfuse Jumpstarter"] = "Darkfuse Jumpstarter"
--[[Translation missing --]]
L["Darkfuse Mechadrone"] = "Darkfuse Mechadrone"
--[[Translation missing --]]
L["Darkfuse Soldier"] = "Darkfuse Soldier"
L["Darkheart Thicket"] = "Arboleda Corazón Oscuro"
L["Darkheart Thicket Sublevel"] = "Sublevel Arboleda Corazón Oscuro"
--[[Translation missing --]]
L["darkheartThicketShortName"] = "DHT"
--[[Translation missing --]]
L["Darkmaster Gandling"] = "Darkmaster Gandling"
L["Darkweb Hatchling"] = "Prole de Tejeoscura"
L["Darkweb Recluse"] = "Ermitaña Tejeoscura"
--[[Translation missing --]]
L["DataImportButtonTooltip"] = "Import external NPC Data."
--[[Translation missing --]]
L["dawnBreakerShortName"] = "DAWN"
--[[Translation missing --]]
L["dawnlowerShortName"] = "FALL"
--[[Translation missing --]]
L["DawnOfTheInfiniteLower"] = "DOTI: Galakrond's Fall"
--[[Translation missing --]]
L["DawnOfTheInfiniteUpper"] = "DOTI: Murozond's Rise"
--[[Translation missing --]]
L["dawnPortalNote"] = [=[Infinite Riftmage 2 and 4 need to be defeated for the portals to activate.
Temporal Deviations will keep respawning but give no count.]=]
--[[Translation missing --]]
L["dawnupperShortName"] = "RISE"
L["Dazar'ai Augur"] = "Augur Dazar'ai"
L["Dazar'ai Colossus"] = "Coloso Dazar'ai"
L["Dazar'ai Confessor"] = "Confesor Dazar'ai"
L["Dazar'ai Honor Guard"] = "Guardia de honor Dazar'ai"
L["Dazar'ai Juggernaut"] = "Gigante Dazar'ai"
L["Dazhak"] = "Dazhak"
L["Dazzling Dragonfly"] = "Libélula deslumbrante"
--[[Translation missing --]]
L["De Other Side"] = "De Other Side"
L["Dealer Xy'exa"] = "Tratante Xy'exa"
L["Death Knight"] = "Caballero de la Muerte"
L["Death Knight Captain"] = "Capitán caballero de la Muerte"
L["Death Knight Cavalier"] = "Hidalgo caballero de la Muerte"
L["Death Speaker"] = "Portavoz de la muerte"
L["Deathcharger Steed"] = "Corcel destrero de la Muerte"
--[[Translation missing --]]
L["Deathscreamer Ikentak"] = "Deathscreamer Ikentak"
--[[Translation missing --]]
L["Deathwalker"] = "Deathwalker"
L["Decatriarch Wratheye"] = "Descompotriarca Ojoiracundo"
L["Decay Speaker"] = "Portavoz de la descomposición"
L["Decayed Elder"] = "Ancestro descompuesto"
L["Decaying Flesh Giant"] = "Gigante de carne putrefacta"
L["Decaying Slime"] = "Babosa en descomposición"
L["Decrease Brush Size"] = "Reducir Tamaño del Pincel"
L["Deep Crawler"] = "Reptador Profundo"
L["Deep Murloc Drudge"] = "Bracero múrloc profundo"
--[[Translation missing --]]
L["Deep Sea Murloc"] = "Deep Sea Murloc"
L["Deepsea Ritualist"] = "Ritualista de fondo marino"
--[[Translation missing --]]
L["Default"] = "Default"
L["defaultPresetName"] = "Ruta"
L["Defective Sorter"] = "Clasificador defectuoso"
L["Defender of Many Eyes"] = "Defensor de muchos ojos"
L["Defense Bot Mk I"] = "Robot de defensa Mk I"
L["Defense Bot Mk III"] = "Robot de defensa Mk III"
L["Defier Draghar"] = "Desafiador Draghar"
L["Defiled Spire of Ny'alotha"] = "Aguja profanada de Ny'alotha"
L["Defiled Spirit"] = "Espíritu profanado"
L["Defunct Dental Drill"] = "Taladro dental en desuso"
L["Delete"] = "Eliminar"
L["Delete %s?"] = "Eliminar %s?"
L["Delete ALL drawings"] = "Eliminar TODOS los dibujos"
L["Delete ALL presets"] = "Eliminar TODAS las rutas"
L["Delete Preset"] = "Eliminar Ruta"
L["Delete this preset"] = "Eliminar esta ruta"
L["deleteAllDrawingsPrompt"] = "Quieres eliminar TODOS los dibujos de la actual ruta?%sEsto no se puede deshacer%s%s"
L["deleteAllWarning"] = "¡¡AVISO!!%sQuieres eliminar TODOS los preajustes de esta mazmorra?%sEstás a punto de eliminar %s ruta(s)%sÉsto no se puede deshacer"
L["Demolishing Terror"] = "Terror demoledor"
--[[Translation missing --]]
L["Demolition Duo"] = "Demolition Duo"
L["Demon"] = "Demonio"
--[[Translation missing --]]
L["DenOfDecay"] = "Den of Decay"
--[[Translation missing --]]
L["deOtherSideShortName"] = "DOS"
--[[Translation missing --]]
L["Depleted Anima Seed"] = "Depleted Anima Seed"
--[[Translation missing --]]
L["depletedAnimaSeedDescription"] = "Updates the graveyard location"
L["Depraved Collector"] = "Recolectora depravada"
L["Depraved Darkblade"] = "Filoscuro depravado"
L["Depraved Houndmaster"] = "Maestra de canes depravada"
L["Depraved Mistweaver"] = "Tejedora de niebla depravada"
L["Depraved Obliterator"] = "Obliterador depravado"
L["Depths Warden"] = "Celador de las profundidades"
L["Desecrated Bakar"] = "Bakar profanado"
L["Desecrated Ohuna"] = "Ohuna profanado"
L["Despondent Scallywag"] = "Pillo decaído"
L["Dessia the Decapitator"] = "Dessia la Decapitadora"
--[[Translation missing --]]
L["Destroying Sha"] = "Destroying Sha"
L["Detention Block"] = "Bloque de Detención"
--[[Translation missing --]]
L["Detonating Crystal"] = "Detonating Crystal"
L["Devos"] = "Devos"
L["Devoted Accomplice"] = "Cómplice devoto"
L["Devouring Ghoul"] = "Necrófago devorador"
L["Devouring Maggot"] = "Cresa devoradora"
L["Devout Blood Priest"] = "Sacerdotisa de sangre devota"
--[[Translation missing --]]
L["Devout Priest"] = "Devout Priest"
--[[Translation missing --]]
L["Dimension Portal"] = ""
L["Dinomancer Kish'o"] = "Dinomántica Kish'o"
--[[Translation missing --]]
L["Discarded Shield"] = "Discarded Shield"
--[[Translation missing --]]
L["Discharged Anima"] = "Discharged Anima"
--[[Translation missing --]]
L["Disease"] = "Disease"
L["Disease Slasher"] = "Mutiladora enfermiza"
L["Diseased Horror"] = "Horror malsano"
L["Diseased Lasher"] = "Azotador malsano"
L["Diseased Maggot"] = "Cresa malsana"
L["Diseased Mastiff"] = "Mastín malsano"
L["Disgusting Refuse"] = "Desecho asqueroso"
L["Disorient"] = "Desorientar"
L["Disruptive Patron"] = "Cliente perturbador"
--[[Translation missing --]]
L["Disturbed Kelp"] = "Disturbed Kelp"
L["Dockhound Packmaster"] = "Maestro de manada de canes de muelle"
L["Doctor Ickus"] = "Doctor Ickus"
L["Does not delete your drawings"] = "No elimina tus dibujos"
L["Dokigg the Brutalizer"] = "Dokigg el Brutalizador"
L["Domatrax"] = "Domatrax"
L["Domina Venomblade"] = "Domina Hojaveneno"
--[[Translation missing --]]
L["dotiLowerSublevel1"] = "Sublevel 1"
--[[Translation missing --]]
L["dotiUpperSublevel1"] = "Sublevel 1"
--[[Translation missing --]]
L["Draconic Illusion"] = "Draconic Illusion"
--[[Translation missing --]]
L["Draconic Image"] = "Draconic Image"
L["Drag the bottom right edge to resize MDT."] = "Arrastra la esquina de abajo a la derecha para redimensionar MDT."
--[[Translation missing --]]
L["Dragonflayer Ascent"] = "Dragonflayer Ascent"
L["Dragonflayer Bonecrusher"] = "Machacahuesos Desuelladragones"
L["Dragonflayer Deathseeker"] = "Buscamuerte Desuelladragones"
L["Dragonflayer Fanatic"] = "Fanático Desuelladragones"
L["Dragonflayer Forge Master"] = "Maestro de forja Desuelladragones"
L["Dragonflayer Heartsplitter"] = "Partecorazones Desuelladragones"
L["Dragonflayer Ironhelm"] = "Yelmo de hierro Desuelladragones"
L["Dragonflayer Metalworker"] = "Trabajador de metal Desuelladragones"
L["Dragonflayer Overseer"] = "Sobrestante Desuelladragones"
L["Dragonflayer Runecaster"] = "Taumaturgo de runas Desuelladragones"
L["Dragonflayer Seer"] = "Vidente Desuelladragones"
L["Dragonflayer Spiritualist"] = "Espiritista Desuelladragones"
L["Dragonflayer Strategist"] = "Estratega Desuelladragones"
L["Dragonflayer Weaponsmith"] = "Forjador de armas Desuelladragones"
--[[Translation missing --]]
L["Dragonflight Season 1"] = "Dragonflight Season 1"
--[[Translation missing --]]
L["Dragonflight Season 2"] = "Dragonflight Season 2"
--[[Translation missing --]]
L["Dragonflight Season 3"] = "Dragonflight Season 3"
--[[Translation missing --]]
L["Dragonflight Season 4"] = "Dragonflight Season 4"
L["Dragonkin"] = "Dragonante"
--[[Translation missing --]]
L["Drahga Shadowburner"] = "Drahga Shadowburner"
L["Drakkari Bat"] = "Murciélago Drakkari"
L["Drakkari Battle Rider"] = "Jinete de batalla Drakkari"
L["Drakkari Colossus"] = "Coloso Drakkari"
L["Drakkari Commander"] = "Comandante Drakkari"
L["Drakkari Earthshaker"] = "Sacudetierra Drakkari"
L["Drakkari Fire Weaver"] = "Tejefuego Drakkari"
L["Drakkari Frenzy"] = "Furia Drakkari"
L["Drakkari God Hunter"] = "Cazador de dioses Drakkari"
L["Drakkari Golem"] = "Gólem Drakkari"
L["Drakkari Guardian"] = "Guardián Drakkari"
L["Drakkari Gutripper"] = "Arrancatripas Drakkari"
L["Drakkari Inciter"] = "Incitador Drakkari"
L["Drakkari Lancer"] = "Lancero Drakkari"
L["Drakkari Medicine Man"] = "Auxiliador Drakkari"
L["Drakkari Raider"] = "Asaltante Drakkari"
L["Drakkari Rhino"] = "Rinoceronte Drakkari"
L["Drakkari Scytheclaw"] = "Segador Drakkari"
L["Drakkari Shaman"] = "Chamán Drakkari"
L["Drakonid Breaker"] = "Aniquiladora dracónida"
L["Drakos the Interrogator"] = "Drakos el Interrogador"
--[[Translation missing --]]
L["Drak'Tharon Keep"] = "Drak'Tharon Keep"
--[[Translation missing --]]
L["Drak'Tharon Overlook"] = "Drak'Tharon Overlook"
L["Drawing: Arrow"] = "Dibujando: Flecha"
L["Drawing: Eraser"] = "Dibujando: Borrador"
L["Drawing: Freehand"] = "Dibujando: Mano libre"
L["Drawing: Line"] = "Dibujando: Linea"
L["Dread Captain Lockwood"] = "Capitana aterradora Lockwood"
L["Dread Creeper"] = "Trepador aterrador"
L["Dreadborne Seer"] = "Vidente Terrornato"
L["Dreadfang"] = "Colminferno"
L["Dreadfire Imp"] = "Diablillo de fuego aterrador"
L["Dreadful Huntmaster"] = "Maestro de caza pavoroso"
L["Dreadhunter"] = "Cazador terrorífico"
L["Dreadlord Mendacius"] = "Señor del Terror Mendacius"
L["Dreadpetal"] = "Horripétalo"
L["Dreadsoul Poisoner"] = "Envenenador Almaespanto"
L["Dreadsoul Ruiner"] = "Arruinador Almaespanto"
L["Dreadwing"] = "Alatemible"
L["Dreadwing Raven"] = "Cuervo Alatemible"
L["Dredged Sailor"] = "Marinero dragador"
L["Dresaron"] = "Dresaron"
L["Droman Oulfarran"] = "Droman Oulfarran"
--[[Translation missing --]]
L["dropdownAssignPlayer"] = "Assign to Player"
--[[Translation missing --]]
L["dropdownClear"] = "Clear"
L["Drowned Depthbringer"] = "Liberabismos ahogado"
L["Drums of War"] = "Tambores de guerra"
L["Drunk Pirate"] = "Pirata borracho"
--[[Translation missing --]]
L["Drunken Hozen Brawler"] = "Drunken Hozen Brawler"
L["Drust Boughbreaker"] = "Romperramas Drust"
L["Drust Harvester"] = "Cosechador Drust"
L["Drust Soulcleaver"] = "Rajaalmas Drust"
L["Drust Spiteclaw"] = "Zarparrencor Drust"
L["Dulhu"] = "Dulhu"
L["Dul'zak"] = "Dul'zak"
--[[Translation missing --]]
L["Dungeon Data Missing"] = "Dungeon Data Missing"
--[[Translation missing --]]
L["Dungeon Entrance"] = "Dungeon Entrance"
L["Dungeon Level"] = "Nivel de Mazmorra"
L["Duskwatch Arcanist"] = "Arcanista Vigía del ocaso"
L["Duskwatch Guard"] = "Guardia Vigía del ocaso"
--[[Translation missing --]]
L["Duskwatch Reinforcement"] = "Duskwatch Reinforcement"
L["Duskwatch Sentry"] = "Avizor Vigía del ocaso"
--[[Translation missing --]]
L["Dwarven Bomber"] = "Dwarven Bomber"
--[[Translation missing --]]
L["Dynamite Mine Cart"] = "Dynamite Mine Cart"
--[[Translation missing --]]
L["E.D.N.A"] = "E.D.N.A"
L["Earlier Version"] = "Tienes una version anterior con el nombre de la ruta '%s'%s¿Quieres actualizarlo o crear una nueva copia?%s%s%s"
--[[Translation missing --]]
L["Earth Infused Golem"] = "Earth Infused Golem"
L["Earthen Custodian"] = "Custodio terráneo"
L["Earthen Guardian"] = "Guardián terráneo"
L["Earthen Warder"] = "Depositario terráneo"
L["Earthen Weaver"] = "Tejedor terráneo"
L["Earthrager"] = "Terracundo"
L["Earthshaper Telu"] = "Modelador de tierra Telu"
L["Ebonclaw Worg"] = "Huargo Garra de Ébano"
L["Ebonstone Golem"] = "Gólem de ébano"
L["Echelon"] = "Echelon"
L["Echo of Doragosa"] = "Eco de Doragosa"
L["Eck the Ferocious"] = "Eck el Feroz"
--[[Translation missing --]]
L["Eco-Dome Al'dani"] = "Eco-Dome Al'dani"
--[[Translation missing --]]
L["ecoDomeAldaniShortName"] = "EDA"
--[[Translation missing --]]
L["eda2BossNote"] = "Defeating G23 is required to spawn the boss"
--[[Translation missing --]]
L["EDAItem1Description"] = "Usable by |T4620672:15:15|t Khaz Algar Enchanting (25)"
--[[Translation missing --]]
L["EdgeOfReality"] = "Edge of Reality"
L["Edit"] = "Editar"
--[[Translation missing --]]
L["Efficiency Score"] = "Efficiency Score"
--[[Translation missing --]]
L["EfficiencyScoreTip"] = "Efficiency Score indicates how valuable an NPCs dungeon count is compared to their raw health."
--[[Translation missing --]]
L["Elaena Emberlanz"] = "Elaena Emberlanz"
L["Elder Brightleaf"] = "Ancestro Hojabrillante"
L["Elder Ironbranch"] = "Ancestro Hierrorrama"
L["Elder Leaxa"] = "Anciana Leaxa"
L["Elder Nadox"] = "Ancestro Nadox"
--[[Translation missing --]]
L["Elder Shadeweaver"] = "Elder Shadeweaver"
L["Elder Stonebark"] = "Ancestro Cortezapiedra"
L["Elemental"] = "Elemental"
L["Elfyra"] = "Elfyra"
L["Embalming Fluid"] = "Líquido de embalsamar"
L["Embalming Slime"] = "Babosa embalsamadora"
L["Emberhusk Dominator"] = "Dominador Caparabrasa"
L["Emberon"] = "Ascuas"
L["Embershard Scorpion"] = "Escorpión Pizcabrasa"
L["Emissary of the Tides"] = "Emisaria de las mareas"
--[[Translation missing --]]
L["Empty"] = "Empty"
--[[Translation missing --]]
L["Empty Anima Vessel"] = "Empty Anima Vessel"
L["Empyrean Assassin"] = "Asesino empíreo"
--[[Translation missing --]]
L["Enable Compartment Button"] = "Enable Compartment Button"
L["Enable Minimap Button"] = "Activar Botón del Minimapa"
L["Enchanted Broodling"] = "Cría encantada"
L["Enchanted Emissary"] = "Emisaria encantada"
--[[Translation missing --]]
L["encounteredErrors"] = [=[MDT has encountered errors.
Click to view them.]=]
--[[Translation missing --]]
L["Encrypted"] = "Encrypted"
L["Enemies related to seasonal affixes are currently hidden"] = "Los enemigos relacionados a afijos de temporada están actualmente ocultos"
L["Enemy Info"] = "Información enemiga"
L["Enemy Info NPC Creature Type"] = "Tipo de Criatura"
L["Enemy Info NPC Enemy Forces"] = "Fuerzas Enemigas"
L["Enemy Info NPC Enemy Forces (Teeming)"] = "Fuerzas Enemigas (Bullente)"
L["Enemy Info NPC Health"] = "Vida (+%d %s)"
L["Enemy Info NPC Id"] = "Identidad PNJ"
L["Enemy Info NPC Level"] = "Nivel"
L["Enemy Info NPC Name"] = "Nombre"
L["Enemy Info NPC Stealth"] = "Sigilo"
L["Enemy Info NPC Stealth Detect"] = "Detectar Sigilo"
--[[Translation missing --]]
L["Engine Speaker"] = "Engine Speaker"
--[[Translation missing --]]
L["Engorged Crawler"] = "Engorged Crawler"
--[[Translation missing --]]
L["Enrage"] = "Enrage"
L["Enraged Direhorn"] = "Cuernoatroz iracundo"
L["Enraged Mask"] = "Máscara enfurecida"
L["Enraged Spirit"] = "Espíritu iracundo"
L["Enraging Ghoul"] = "Necrófago iracundo"
L["Enslave Demon"] = "Esclavizar demonio"
L["Enslaved Proto-Drake"] = "Protodraco esclavizado"
L["Enslaved Shieldmaiden"] = "Doncella escudera esclavizada"
L["Enthralled Guard"] = "Guarda sometido"
L["Entropic Spire of Ny'alotha"] = "Aguja entrópica de Ny'alotha"
L["Epoch Ripper"] = "Destripador de Época"
L["Eredar Chaosbringer"] = "Portador de caos eredar"
L["Erekem"] = "Erekem"
L["Eric \"The Swift\""] = "Eric \"el Veloz\""
L["Erkhart Stormvein"] = "Erkhart Venatormenta"
--[[Translation missing --]]
L["Error Message:"] = "Error Message:"
--[[Translation missing --]]
L["errorLabel1"] = "MDT has encountered errors."
--[[Translation missing --]]
L["errorLabel2"] = "Please update MDT to the latest version and visit either GitHub or Discord and report the error message below."
--[[Translation missing --]]
L["errorLabel3"] = "Press CTRL + C to copy!"
--[[Translation missing --]]
L["Erudax"] = "Erudax"
L["Erudite Slayer"] = "Asesina erudita"
L["Erunak Stonespeaker"] = "Erunak Hablapiedra"
L["Etherdiver"] = "Colimbo de éter"
L["Ethereal Restorer"] = "Restaurador etéreo"
--[[Translation missing --]]
L["Ethereal Sha"] = "Ethereal Sha"
--[[Translation missing --]]
L["Everbloom Cultivator"] = "Everbloom Cultivator"
L["Everbloom Mender"] = "Ensalmador del Vergel Eterno"
L["Everbloom Naturalist"] = "Naturalista del Vergel Eterno"
--[[Translation missing --]]
L["everbloomShortName"] = "EB"
L["Executioner Varruth"] = "Verdugo Varruth"
L["Executor of the Caliph"] = "Ejecutor del califa"
L["Executor Tarvold"] = "Ejecutor Tarvold"
--[[Translation missing --]]
L["Exhumed Spirit"] = "Exhumed Spirit"
L["Expand the top toolbar to gain access to drawing and note features."] = "Expande la barra de herramientas superior para ganar acceso a características de dibujo y notas."
L["Experimental Sludge"] = "Fango experimental"
L["Expert Technician"] = "Técnico experto"
L["Explosive"] = "Explosiva"
L["Export"] = "Exportar"
L["Export the preset as a text string"] = "Exportar la ruta como una cadena de texto"
--[[Translation missing --]]
L["ExportStringShareExternalWebsite"] = "You can share MDT exports on external websites"
L["Eye of Azshara"] = "Ojo de Azshara"
L["Eye of Azshara Sublevel"] = "Subnivel de Ojo de Azshara"
--[[Translation missing --]]
L["Eye of Sethraliss"] = "Eye of Sethraliss"
L["Eye of Taldaram"] = "Ojo de Taldaram"
--[[Translation missing --]]
L["Eye Of The Queen"] = "Eye Of The Queen"
L["Eye Stalk"] = "Ojo acechador"
--[[Translation missing --]]
L["eyeOfAzsharaShortName"] = "EoA"
L["Faceless Corruptor"] = "Corruptor ignoto"
L["Faceless Horror"] = "Horror ignoto"
L["Faceless Maiden"] = "Doncella sin rostro"
--[[Translation missing --]]
L["Faceless Seer"] = "Faceless Seer"
L["Faceless Watcher"] = "Vigía ignoto"
L["Faithless Tender"] = "Cuidador infiel"
L["Fallen Deathspeaker"] = "Portavoz de la muerte caído"
L["Fallen Waterspeaker"] = "Orador del agua caído"
L["Famished Broken"] = "Tábido famélico"
L["Famished Tick"] = "Garrapata famélica"
--[[Translation missing --]]
L["Fanatical Conjuror"] = "Fanatical Conjuror"
L["Fanatical Headhunter"] = "Rebanacabezas fanático"
L["Fear"] = "Miedo"
L["Feasting Skyscreamer"] = "Vociferador de cielos hambriento"
L["Feckless Assistant"] = "Ayudante inútil"
L["Fel Bat"] = "Murciélago vil"
L["Fel Scorcher"] = "Carbonizador vil"
L["Felblight Stalker"] = "Acechador añublovil"
L["Felborne Botanist"] = "Botanista vilificada"
L["Felbound Enforcer"] = "Déspota de vínculo vil"
L["Felguard Destroyer"] = "Destructor guardia vil"
L["Fel-Infused Fury"] = "Furia imbuida de vileza"
L["Felspite Dominator"] = "Dominador Flemavil"
L["Felstrider Enforcer"] = "Déspota Zancavil"
L["Felstrider Orbcaster"] = "Lanzaorbes Zancavil"
L["Felsworn Infester"] = "Infestador jurapenas"
L["Felsworn Myrmidon"] = "Mirmidón jurapenas"
L["Fen Hatchling"] = "Cría del pantano"
L["Fen Hornet"] = "Avispón de pantano"
L["Fenryr"] = "Fenryr"
L["Feral Bloodswarmer"] = "Enjambrista de sangre feral"
--[[Translation missing --]]
L["Fervent Sharpshooter"] = "Fervent Sharpshooter"
L["Festerhide Grizzly"] = "Oso pardo con piel supurante"
L["Fetid Maggot"] = "Cresa fétida"
L["Fetid Rotsinger"] = "Cantaputrefacción fétida"
L["Feugen"] = "Feugen"
--[[Translation missing --]]
L["ffAbandonTip"] = "Use the /ff slash command to start the M+ abandon vote"
L["Field of the Eternal Hunt"] = "Campos de la Cacería Eterna"
L["Filth Caller"] = "Clamainmundicia"
L["Finger Food"] = "Comida para picar"
L["Fishface"] = "Carapez"
L["Flame Channeler"] = "Canalizador de llamas"
L["Flame Leviathan"] = "Leviatán de llamas"
L["Flamecaller Aymi"] = "Invocallamas Aymi"
L["Flamegullet"] = "Gargantardiente"
--[[Translation missing --]]
L["Flamethrower"] = "Flamethrower"
--[[Translation missing --]]
L["Flameweaver Koegler"] = "Flameweaver Koegler"
L["Flashfrost Chillweaver"] = "Tejefrío Raudoescarcha"
L["Flashfrost Earthshaper"] = "Modelador de tierra Raudoescarcha"
--[[Translation missing --]]
L["Flavor Scientist"] = "Flavor Scientist"
L["Fleeting Manifestation"] = "Manifestación fugaz"
L["Flesh Crafter"] = "Modelador de carne"
--[[Translation missing --]]
L["Flesh Horror"] = "Flesh Horror"
L["Flesheating Ghoul"] = "Necrófago carnívoro"
L["Fleshrender Nok'gar"] = "Sacrificador Nok'gar"
L["Fleshripper Vulture"] = "Buitre desgarracarnes"
--[[Translation missing --]]
L["Flying Snow"] = "Flying Snow"
L["Focused Ritualist"] = "Ritualista enfocado"
--[[Translation missing --]]
L["Font of Fealty"] = "Font of Fealty"
L["Footbomb Hooligan"] = "Hincha del bombalón"
L["Forces"] = "Tropas"
L["Forces only: 5/200"] = "Tropas sólo: 5/200"
L["Forces+%: 5/200 (2.5%)"] = "Tropas+%: 5/200 (2.5%)"
L["Forest Swarmer"] = "Enjambrista del bosque"
L["Forge Construct"] = "Ensamblaje de forja"
--[[Translation missing --]]
L["Forge Loader"] = "Forge Loader"
--[[Translation missing --]]
L["Forge Master Damian"] = "Forge Master Damian"
--[[Translation missing --]]
L["Forgebound Mender"] = "Forgebound Mender"
L["Forgemaster Gorek"] = "Maestro de forja Gorek"
--[[Translation missing --]]
L["Forgemaster Throngus"] = "Forgemaster Throngus"
L["Forgewrought Monstrosity"] = "Monstruosidad forjada"
L["Forgotten Denizen"] = "Morador olvidado"
L["Forgotten One"] = "Olvidado"
L["Forgotten Spirit"] = "Espíritu olvidado"
--[[Translation missing --]]
L["Forlorn Cloister"] = "Forlorn Cloister"
L["Forlorn Spirit"] = "Espíritu melancólico"
L["Forsworn Castigator"] = "Castigadora abjurante"
L["Forsworn Champion"] = "Campeón abjurante"
L["Forsworn Goliath"] = "Goliat abjurante"
L["Forsworn Helion"] = "Helión abjurante"
L["Forsworn Inquisitor"] = "Inquisidora abjurante"
L["Forsworn Justicar"] = "Justicar abjurante"
L["Forsworn Mender"] = "Ensalmador abjurante"
L["Forsworn Skirmisher"] = "Hostigador abjurante"
L["Forsworn Squad-Leader"] = "Líder de escuadrón abjurante"
L["Forsworn Stealthclaw"] = "Garrasigilo abjurante"
L["Forsworn Usurper"] = "Usurpador abjurante"
L["Forsworn Vanguard"] = "Vanguardia abjurante"
L["Forsworn Warden"] = "Celador abjurante"
L["Fortified"] = "Reforzada"
--[[Translation missing --]]
L["Forward Train Cars"] = "Forward Train Cars"
L["Foul Mother"] = "Madre hedionda"
L["frackingNote"] = "Tótem de hidrofracturación%sUsable por jugadores%sIncapazita Terracundo por 1min - El daño lo rompe"
--[[Translation missing --]]
L["Fragment of Hatred"] = "Fragment of Hatred"
--[[Translation missing --]]
L["Fragrant Lotus"] = "Fragrant Lotus"
L["Freehold"] = "Fuerte Libre"
L["Freehold Barhand"] = "Camarera de Fuerte Libre"
L["Freehold Deckhand"] = "Marinero de cubierta de Fuerte Libre"
L["Freehold Pack Mule"] = "Mula de carga de Fuerte Libre"
L["Freehold Shipmate"] = "Compañero de tripulación de Fuerte Libre"
L["Freehold Sublevel"] = "Subnivel de Fuerte Libre"
L["freeholdBeguilingPatrolNote"] = "Semana 2/5/8/11: G53 es estacionaria en Emisaria de las Mareas 13"
L["freeholdGraveyardDescription1"] = "Se desbloquea después de derrotar a Capitan de los cielos Kragg"
L["freeholdGraveyardDescription2"] = "Se desbloquea después de derrotar al Consejo de Capitanes"
--[[Translation missing --]]
L["freeholdShortName"] = "FH"
L["Frenzied Bat"] = "Murciélago demenciado"
L["Frenzied Geist"] = "Geist demenciado"
L["Frenzied Ghoul"] = "Necrófago demenciado"
--[[Translation missing --]]
L["Frenzied Mite"] = "Frenzied Mite"
L["Frenzied Nightclaw"] = "Garranoche enloquecido"
--[[Translation missing --]]
L["Frenzied Spirit"] = "Frenzied Spirit"
L["Freya"] = "Freya"
L["Frostbringer"] = "Portaescarcha"
L["Fulminating Lasher"] = "Azotador fulminante"
L["Fungalmancer"] = "Fungimántico"
L["Fungi Stormer"] = "Agitador de hongos"
L["Fungret Shroomtender"] = "Cuidachampiñones fungarete"
L["G.U.A.R.D."] = "GUARDIA"
L["Gal'darah"] = "Gal'darah"
L["Galecaller Apprentice"] = "Aprendiz Clamavendavales"
L["Galecaller Faye"] = "Clamavendavales Faye"
L["Galvazzt"] = "Galvazzt"
L["Gamesman's Hall"] = "Sala del Tablero"
--[[Translation missing --]]
L["Gardens of Repose"] = "Gardens of Repose"
L["Gashtooth"] = "Tajadientes"
--[[Translation missing --]]
L["Gate of the Setting Sun"] = "Gate of the Setting Sun"
--[[Translation missing --]]
L["Gate Watch Tower"] = "Gate Watch Tower"
--[[Translation missing --]]
L["gateOfTheSettingSunShortName"] = "GATE"
L["Gatewarden Zo'mazz"] = "Celador de la puerta Zo'mazz"
L["Gazerax"] = "Avizorax"
--[[Translation missing --]]
L["Geezle Gigazap"] = "Geezle Gigazap"
--[[Translation missing --]]
L["Gekkan"] = "Gekkan"
L["General Bjarngrim"] = "General Bjarngrim"
L["General Kaal"] = "General Kaal"
--[[Translation missing --]]
L["General Pa'valak"] = "General Pa'valak"
--[[Translation missing --]]
L["General Umbriss"] = "General Umbriss"
L["General Vezax"] = "General Vezax"
L["General Xakal"] = "General Xakal"
L["Gerenth the Vile"] = "Gerenth el Vil"
--[[Translation missing --]]
L["Ghastly Parishioner"] = "Ghastly Parishioner"
--[[Translation missing --]]
L["Ghastly Voidsoul"] = "Ghastly Voidsoul"
L["Ghostly Baker"] = "Panadero fantasmal"
L["Ghostly Chef"] = "Chef fantasmal"
L["Ghostly Councilor"] = "Consejero fantasmal"
L["Ghostly Philanthropist"] = "Filántropo fantasmal"
L["Ghostly Protector"] = "Protector fantasmal"
L["Ghostly Retainer"] = "Criado fantasmal"
L["Ghostly Steward"] = "Administrador fantasmal"
L["Ghostly Understudy"] = "Suplente fantasmal"
L["Ghoul Tormentor"] = "Torturador necrófago"
L["Giant"] = "Gigante"
L["Gilded Priestess"] = "Sacerdotisa dorada"
L["Gildedfur Stag"] = "Venado de pelaje dorado"
L["Gilgoblin Aquamage"] = "Mago acuático Gilgoblin"
L["Gilgoblin Hunter"] = "Cazador Gilgoblin"
L["Glacial Proto-Dragon"] = "Protodragón glacial"
L["Glayvianna Soulrender"] = "Desgarradora de almas Glayvianna"
L["Glazer"] = "Observador"
--[[Translation missing --]]
L["Glintrok Greenhorn"] = "Glintrok Greenhorn"
--[[Translation missing --]]
L["Glintrok Hexxer"] = "Glintrok Hexxer"
--[[Translation missing --]]
L["Glintrok Ironhide"] = "Glintrok Ironhide"
--[[Translation missing --]]
L["Glintrok Oracle"] = "Glintrok Oracle"
--[[Translation missing --]]
L["Glintrok Scout"] = "Glintrok Scout"
--[[Translation missing --]]
L["Glintrok Skulker"] = "Glintrok Skulker"
L["Globgrog"] = "Globgrog"
L["Gloom Horror"] = "Horror tenebroso"
L["Gluth"] = "Gluth"
L["Gluttonous Tick"] = "Garrapata glotona"
L["Gnarled Ancient"] = "Anciano nudoso"
L["Gnarlroot"] = "Tuercerraíces"
L["Gnome-Eating Slime"] = "Babosa comegnomos"
L["Gnomercy 4.U."] = "Gnomisericordia PAT 1"
L["God-King Skovald"] = "Rey dios Skovald"
--[[Translation missing --]]
L["Goldie Baronbottom"] = "Goldie Baronbottom"
L["Gorak Tul"] = "Gorak Tul"
L["Gorechop"] = "Tajasangre"
L["Goregrind"] = "Picacrúor"
L["Goregrind Bits"] = "Trozos de picacrúor"
L["Gorestained Piglet"] = "Lechón manchado de sangre"
L["Gortok Palehoof"] = "Gortok Pezuña Pálida"
L["Gothik the Harvester"] = "Gothik el Cosechador"
--[[Translation missing --]]
L["Grain Cellar"] = "Grain Cellar"
L["Grand Magus Telestra"] = "Gran maga Telestra"
L["Grand Overseer"] = "Gran sobrestante"
L["Grand Proctor Beryllia"] = "Gran procuradora Beryllia"
L["Grand Shadow-Weaver"] = "Gran tejesombras"
L["Grand Vizier Ertan"] = "Gran visir Ertan"
L["Grand Widow Faerlina"] = "Gran Viuda Faerlina"
L["Granyth"] = "Granyth"
L["Graveyard"] = "Cementerio"
L["Grease Bot"] = "Robot grasiento"
L["Grievous"] = "Dolorosa"
--[[Translation missing --]]
L["Grim Batol"] = "Grim Batol"
--[[Translation missing --]]
L["grimBatolShortName"] = "GB"
L["Grimhorn the Enslaver"] = "Cuernomacabro el Esclavista"
L["Grimrail Bombardier"] = "Bombardero Malavía"
L["Grimrail Laborer"] = "Obrero Malavía"
L["Grimrail Loader"] = "Cargador Malavía"
L["Grimrail Overseer"] = "Sobrestante Malavía"
L["Grimrail Scout"] = "Exploradora Malavía"
L["Grimrail Technician"] = "Técnico Malavía"
--[[Translation missing --]]
L["GrimrailDepot"] = "Grimrail Depot"
--[[Translation missing --]]
L["grimrailDepotShortName"] = "GB"
L["Grip"] = "Atracción"
L["Gripping Terror"] = "Terror atenazante"
L["Gritslime Snail"] = "Caracol de baba abrasiva"
L["Grobbulus"] = "Grobbulus"
L["Grom'kar Battlemaster"] = "Maestro de batalla Grom'kar"
L["Grom'kar Boomer"] = "Dinamitero Grom'kar"
L["Grom'kar Captain"] = "Capitana Grom'kar"
L["Grom'kar Chainmaster"] = "Maestra de cadenas Grom'kar"
L["Grom'kar Cinderseer"] = "Vidente de las cenizas Grom'kar"
L["Grom'kar Deadeye"] = "Grom'kar Mortojo"
L["Grom'kar Deckhand"] = "Marinero de cubierta Grom'kar"
L["Grom'kar Far Seer"] = "Clarividente Grom'kar"
L["Grom'kar Flameslinger"] = "Exhaladora de llamas Grom'kar"
L["Grom'kar Footsoldier"] = "Soldado de a pie Grom'kar"
L["Grom'kar Grenadier"] = "Granadero Grom'kar"
L["Grom'kar Gunner"] = "Artillera Grom'kar"
L["Grom'kar Hulk"] = "Mole Grom'kar"
L["Grom'kar Incinerator"] = "Incineradora Grom'kar"
L["Grom'kar Technician"] = "Técnico Grom'kar"
L["Grotesque Horror"] = "Horror grotesco"
L["Grubby Dirtcruncher"] = "Mascabarro mugriento"
--[[Translation missing --]]
L["Gu Cloudstrike"] = "Gu Cloudstrike"
L["Guard Captain Atu"] = "Capitán de la guardia Atu"
--[[Translation missing --]]
L["Guard Captain Suleyman"] = "Guard Captain Suleyman"
L["Guardian Construct"] = "Ensamblaje guardián"
L["Guardian Elemental"] = "Elemental guardián"
L["Guardian Lasher"] = "Azotador guardián"
L["Guardian of Life"] = "Guardián de la vida"
L["Guardian Sentry"] = "Centinela guardián"
L["Guardian's Library"] = "Biblioteca del Guardián"
L["Gulping Goliath"] = "Goliat tragaldabas"
--[[Translation missing --]]
L["Gundrak"] = "Gundrak"
L["Gunker"] = "Mugroso"
--[[Translation missing --]]
L["Gurthan Iron Maw"] = "Gurthan Iron Maw"
--[[Translation missing --]]
L["Gurthan Swiftblade"] = "Gurthan Swiftblade"
L["Gushing Slime"] = "Baba chorreante"
L["Gust Soldier"] = "Soldado de ráfaga"
--[[Translation missing --]]
L["Gusting Proto-Dragon"] = "Gusting Proto-Dragon"
L["Gutchewer Bear"] = "Oso mascatripas"
L["Gutshot"] = "Rompetripas"
L["Gutstabber"] = "Trinchatripas"
L["Hadal Darkfathom"] = "Hadal Brazasombría"
L["Hadronox"] = "Hadronox"
--[[Translation missing --]]
L["Hadronox's Lair"] = "Hadronox's Lair"
--[[Translation missing --]]
L["Haiyan the Unstoppable"] = "Haiyan the Unstoppable"
L["Hakkar the Soulflayer"] = "Hakkar el Cazador de Almas"
L["Halkias"] = "Halkias"
--[[Translation missing --]]
L["Hall of the Keepers"] = "Hall of the Keepers"
L["Hall of the Moon"] = "Sala de la Luna"
--[[Translation missing --]]
L["HallOfTheKeepers"] = "Hall of the Keepers"
--[[Translation missing --]]
L["Halls of Atonement"] = "Halls of Atonement"
--[[Translation missing --]]
L["Halls of Infusion"] = "Halls of Infusion"
--[[Translation missing --]]
L["Halls of Lightning"] = "Halls of Lightning"
--[[Translation missing --]]
L["Halls of Stone"] = "Halls of Stone"
L["Halls of Valor"] = "Cámaras del Valor"
L["Halls of Valor Sublevel"] = "Subnivel de Cámaras del Valor"
--[[Translation missing --]]
L["HallsOfAtonementFloor1"] = "Halls of Atonement"
--[[Translation missing --]]
L["HallsOfAtonementFloor2"] = "The Nave of Pain"
--[[Translation missing --]]
L["HallsOfAtonementFloor3"] = "The Sanctuary of Souls"
--[[Translation missing --]]
L["hallsOfAtonementShortName"] = "HOA"
--[[Translation missing --]]
L["HallsOfInfusion"] = "Halls of Infusion"
--[[Translation missing --]]
L["hallsOfInfusionShortName"] = "HOI"
--[[Translation missing --]]
L["hallsOfValorShortName"] = "HOV"
--[[Translation missing --]]
L["Hapless Assistant"] = "Hapless Assistant"
L["Harbaron"] = "Harbaron"
L["Hardened Iron Golem"] = "Gólem de hierro endurecido"
L["Hardened Steel Berserker"] = "Rabioso de acero endurecido"
L["Hardened Steel Reaver"] = "Atracador de acero endurecido"
L["Hardened Steel Skycaller"] = "Clamacielos de acero endurecido"
--[[Translation missing --]]
L["hardResetButton"] = "Reset MDT"
--[[Translation missing --]]
L["hardResetPrompt"] = [=[Do you really want to reset all settings to default?
|cFFFF0000Try updating the AddOn to the latest version first!
Only do this if MDT is not loading at all and is in a broken state.
This will delete ALL YOUR ROUTES!|r
This will reload the UI!]=]
--[[Translation missing --]]
L["hardResetPromptTitle"] = "Delete ALL settings"
L["Harlan Sweete"] = "Harlan Sweete"
--[[Translation missing --]]
L["Harthak Flameseeker"] = "Harthak Flameseeker"
--[[Translation missing --]]
L["Harthak Stormcaller"] = "Harthak Stormcaller"
L["Harugia the Bloodthirsty"] = "Harugia la Sanguinaria"
L["Hatchling Nest"] = "Nido de crías"
L["Hatecoil Arcanist"] = "Arcanista Espiral de Odio"
L["Hatecoil Crusher"] = "Triturador Espiral de Odio"
L["Hatecoil Oracle"] = "Oráculo Espiral de Odio"
L["Hatecoil Stormweaver"] = "Tejetormentas Espiral de Odio"
L["Hatecoil Warrior"] = "Guerrero Espiral de Odio"
L["Hatecoil Wavebinder"] = "Vinculaolas Espiral de Odio"
L["Hatecoil Wrangler"] = "Retador Espiral de Odio"
--[[Translation missing --]]
L["Hateful Essence"] = "Hateful Essence"
L["Hatespawn Slime"] = "Babosa Criaodio"
L["Haunting Sha"] = "Sha mortificador"
L["Head Custodian Javlin"] = "Custodio jefe Javlin"
L["Head Machinist Sparkflux"] = "Maquinista jefe Flujochispa"
L["Headless Client"] = "Cliente decapitado"
--[[Translation missing --]]
L["Headmaster's Study"] = "Headmaster's Study"
L["Heart Guardian"] = "Guardián de corazón"
L["Heartsbane Runeweaver"] = "Tejerruna Aterracorazón"
L["Heartsbane Soulcharmer"] = "Hechizaalmas Aterracorazón"
L["Heartsbane Vinetwister"] = "Rizavid Aterracorazón"
L["Heavin the Breaker"] = "Heavin el Rompedor"
L["Heavy Scrapbot"] = "Robot de chatarra pesado"
L["Heigan the Unclean"] = "Heigan el Impuro"
L["Helarjar Champion"] = "Campeón Helarjar"
L["Helarjar Mistcaller"] = "Clamaneblina Helarjar"
L["Helblaze Felbringer"] = "Portavil Llama Infernal"
L["Helblaze Imp"] = "Diablillo Llama Infernal"
L["Helblaze Soulmender"] = "Ensalmador de almas Llama Infernal"
L["Hellblaze Temptress"] = "Tentadora Llama Infernal"
L["Helmouth Cliffs"] = "Acantilados Boca Infernal"
L["helpPlateDungeon"] = "Personalizar opciones de mazmorra"
L["helpPlateDungeonSelect"] = "Selecciona una mazmorra y navega a diferentes subniveles"
L["helpPlateNPC"] = "Click para seleccionar enemigos%sCTRL-Click para seleccionar un único enemigo%sSHIFT-Click para seleccionar enemigos y crear un nuevo grupo de enemigos"
L["helpPlatePresets"] = "Gestiona, comparte y colabora en rutas"
L["helpPlatePulls"] = "Crear y gestionar tus pulls%sClick derecho para más opciones"
L["Helya"] = "Helya"
--[[Translation missing --]]
L["Herald Of Ansurek"] = "Herald Of Ansurek"
L["Herald Volazj"] = "Heraldo Volazj"
--[[Translation missing --]]
L["Hibernate"] = "Hibernate"
L["High Adjudicator Aleez"] = "Gran adjudicadora Aleez"
L["High Channeler Ryvati"] = "Alta canalizadora Ryvati"
L["High Contrast"] = "Contraste Alto"
--[[Translation missing --]]
L["High Inquisitor Whitemane"] = "High Inquisitor Whitemane"
--[[Translation missing --]]
L["High Priest Aemya"] = "High Priest Aemya"
--[[Translation missing --]]
L["High Speaker Eirich"] = "High Speaker Eirich"
L["Hired Assassin"] = "Asesino contratado"
--[[Translation missing --]]
L["Hired Muscle"] = "Hired Muscle"
L["HK-8 Aerial Oppression Unit"] = "Unidad de opresión aérea KPU7"
L["Hodir"] = "Hodir"
L["Hold CTRL to single-select enemies."] = "Mantén CTRL para seleccionar enemigos individualmente."
L["Hold SHIFT to create a new pull while selecting enemies."] = "Mantén SHIFT para crear un nuevo pull mientras seleccionas enemigos."
L["Hold SHIFT to delete all presets with the delete preset button."] = "Mantén SHIFT para eliminar todos las rutas con el botón de eliminar rutas."
L["Honored Raptor"] = "Raptor honrado"
--[[Translation missing --]]
L["Honor's Ascent"] = "Honor's Ascent"
L["Hoodoo Hexer"] = "Aojador hudú"
--[[Translation missing --]]
L["Hoptallus"] = "Hoptallus"
L["Horde Berserker"] = "Rabioso de la Horda"
L["Horde Cleric"] = "Clérigo de la Horda"
L["Horde Ranger"] = "Forestal de la Horda"
--[[Translation missing --]]
L["Houndmaster Braun"] = "Houndmaster Braun"
--[[Translation missing --]]
L["Hourglass Cannon"] = "Hourglass Cannon"
L["Hourglass Tidesage"] = "Sabiomar del Reloj de Arena"
--[[Translation missing --]]
L["Howling Gale"] = "Howling Gale"
--[[Translation missing --]]
L["Hozen Party Animal"] = "Hozen Party Animal"
L["Hulking Berserker"] = "Rabioso descomunal"
--[[Translation missing --]]
L["Hulking Bloodguard"] = "Hulking Bloodguard"
--[[Translation missing --]]
L["Hulking Warshell"] = "Hulking Warshell"
L["Humanoid"] = "Humanoide"
L["Hungry Lasher"] = "Azotador hambriento"
L["Hylbrande"] = "Hylbrande"
L["Hymdall"] = "Hymdall"
L["Hyrja"] = "Hyrja"
--[[Translation missing --]]
L["icc"] = "Icecrown Citadel"
--[[Translation missing --]]
L["iccFloor1"] = "The Lower Citadel"
--[[Translation missing --]]
L["iccFloor2"] = "The Rampart of Skulls"
--[[Translation missing --]]
L["iccFloor3"] = "Deathbringer's Rise"
--[[Translation missing --]]
L["iccFloor4"] = "The Frost Queen's Lair"
--[[Translation missing --]]
L["iccFloor5"] = "The Upper Reaches"
--[[Translation missing --]]
L["iccFloor6"] = "Royal Quarters"
--[[Translation missing --]]
L["iccFloor7"] = "The Frozen Throne"
--[[Translation missing --]]
L["iccFloor8"] = "Frostmourne"
L["Ichoron"] = "Ícoron"
L["Ickor Bileflesh"] = "Ickor Carnebilis"
L["If the Minimap Button is enabled"] = "Si el Botón del Minimapa está activado"
L["Ignis the Furnace Master"] = "Ignis, el Maestro de la Caldera"
L["Illysanna Ravencrest"] = "Illysanna Cresta Cuervo"
L["Imacu'tya"] = "Imacu'tya"
L["Imbued Stormcaller"] = "Clamatormentas imbuido"
--[[Translation missing --]]
L["imbuedIronBarDescription"] = "Usable by Warriors, Dwarves, and Khaz Algar Blacksmiths (25)"
L["Immoliant Fury"] = "Furia inmoladora"
L["Import"] = "Importar"
L["Import a preset from a text string"] = "Importar una ruta de una cadena de texto"
--[[Translation missing --]]
L["Import Data"] = "Import Data"
L["Import Preset"] = "Importar Ruta"
L["Imprison"] = "Encarcelar"
L["In the bottom right corner"] = "En la esquina inferior derecha"
L["Incapacitate"] = "Incapacitado"
L["Incinerator Arkolath"] = "Incinerador Arkolath"
--[[Translation missing --]]
L["incompatibleVersionError"] = "This version of World of Warcraft is not compatible with Mythic Dungeon Tools."
--[[Translation missing --]]
L["Inconspicuous Plant"] = "Inconspicuous Plant"
L["Increase Brush Size"] = "Aumentar tamaño de pincel"
L["Infected Bear"] = "Oso infectado"
L["Infected Lasher"] = "Azotador infectado"
L["Infected Peasant"] = "Campesino infectado"
L["Infectious Ghoul"] = "Necrófago infeccioso"
--[[Translation missing --]]
L["Infernal Imp"] = "Infernal Imp"
L["Infested"] = "Infestada"
L["Infested Icecaller"] = "Llamahielos infestada"
L["Infinite Adversary"] = "Adversario Infinito"
L["Infinite Agent"] = "Agente infinito"
L["Infinite Chronoweaver"] = "Cronomante del Infinito"
L["Infinite Diversionist"] = "Diversionista del Infinito"
L["Infinite Hunter"] = "Cazador Infinito"
L["Infinite Infiltrator"] = "Infiltrado del Infinito"
L["Infinite Keeper"] = "Guardián Infinito"
L["Infinite Riftmage"] = "Maga de falla infinita"
L["Infinite Saboteur"] = "Saboteador Infinito"
L["Infinite Slayer"] = "Destripador Infinito"
L["Infinite Timebender"] = "Moldeatiempo del Infinito"
L["Infinite Timereaver"] = "Atracador del Tiempo Infinito"
L["Infinite Timeslicer"] = "Cercenatiempo del Infinito"
L["Infinite Twilight Magus"] = "Magus Crepuscular del Infinito"
L["Infinite Watchkeeper"] = "Vigía infinita"
L["Infinite Whelp"] = "Cría Infinita"
--[[Translation missing --]]
L["Inflamed Hozen Brawler"] = "Inflamed Hozen Brawler"
L["Infused Pyromancer"] = "Piromántico imbuido"
L["Infused Quill-feather"] = "Pluma imbuida"
L["Infused Whelp"] = "Cría imbuida"
L["Infuser Sariya"] = "Inyectora Sariya"
--[[Translation missing --]]
L["Infuser's Rotunda"] = "Infuser's Rotunda"
--[[Translation missing --]]
L["InfusersRotunda"] = "Infuser's Rotunda"
--[[Translation missing --]]
L["Infusion Chamber"] = "Infusion Chamber"
--[[Translation missing --]]
L["Infusion Chambers"] = "Infusion Chambers"
--[[Translation missing --]]
L["InfusionChamber"] = "Infusion Chamber"
L["Ingra Maloch"] = "Ingra Maloch"
L["Ingvar the Plunderer"] = "Ingvar el Desvalijador"
--[[Translation missing --]]
L["Ink of Ozumat"] = "Ink of Ozumat"
L["Inquisitor Sigar"] = "Inquisidor Sigar"
L["Inquisitor Tormentorum"] = "Inquisidor Tormentorum"
L["Insatiable Brute"] = "Bruto insaciable"
L["Insert Note"] = "Insertar Nota"
--[[Translation missing --]]
L["Inspiring"] = "Inspiring"
--[[Translation missing --]]
L["Instructor Chillheart"] = "Instructor Chillheart"
L["Instructor Razuvious"] = "Instructor Razuvious"
L["Interment Construct"] = "Ensamblaje de sepelio"
L["Interrogation Specialist"] = "Especialista en interrogatorios"
--[[Translation missing --]]
L["Interruptible"] = "Interruptible"
--[[Translation missing --]]
L["Invading Mite"] = "Invading Mite"
L["Invalid import string"] = "Cadena de importación no válida"
--[[Translation missing --]]
L["Invigorating Fish Stick"] = "Invigorating Fish Stick"
--[[Translation missing --]]
L["Invoked Shadowflame Spirit"] = "Invoked Shadowflame Spirit"
L["Ionar"] = "Ionar"
--[[Translation missing --]]
L["I'pa"] = "I'pa"
L["Iridikron"] = "Iridikron"
L["Iridikron's Creation"] = "Creación de Iridikron"
L["Iron Infantry"] = "Infantería de la Horda de Hierro"
L["Iron Mender"] = "Ensalmador férreo"
L["Iron Star"] = "Estrella de hierro"
--[[Translation missing --]]
L["IronDocks"] = "Iron Docks"
--[[Translation missing --]]
L["ironDocksIronStar"] = "Iron Star"
--[[Translation missing --]]
L["ironDocksShortName"] = "ID"
L["Ironhull Apprentice"] = "Aprendiz Cascoférreo"
L["Ironroot Lasher"] = "Azotador Raíz Férrea"
L["Irontide Bonesaw"] = "Sierrahuesos Marea de Hierro"
L["Irontide Buccaneer"] = "Bucanero Marea de Hierro"
L["Irontide Cleaver"] = "Acuchillador Marea de Hierro"
L["Irontide Corsair"] = "Corsaria Marea de Hierro"
L["Irontide Crackshot"] = "Escopetero Marea de Hierro"
L["Irontide Crusher"] = "Triturador Marea de Hierro"
--[[Translation missing --]]
L["Irontide Curseblade"] = "Irontide Curseblade"
L["Irontide Enforcer"] = "Déspota Marea de Hierro"
L["Irontide Marauder"] = "Maleante Marea de Hierro"
L["Irontide Mastiff"] = "Mastín Marea de Hierro"
L["Irontide Oarsman"] = "Remero Marea de Hierro"
L["Irontide Officer"] = "Oficial Marea de Hierro"
L["Irontide Powdershot"] = "Tirapólvora Marea de Hierro"
L["Irontide Raider"] = "Asaltante Marea de Hierro"
L["Irontide Ravager"] = "Devastador Marea de Hierro"
L["Irontide Stormcaller"] = "Clamatormentas Marea de Hierro"
L["Irontide Thug"] = "Matón Marea de Hierro"
L["Irontide Waveshaper"] = "Tallaolas Marea de Hierro"
L["Irontorch Commander"] = "Antorchaférrea comandante"
L["Ironwing Flamespitter"] = "Alahierro escupefuego"
L["Ivanyr"] = "Ivanyr"
--[[Translation missing --]]
L["Ixin"] = "Ixin"
--[[Translation missing --]]
L["Ixkreten The Unbreakable"] = "Ixkreten The Unbreakable"
--[[Translation missing --]]
L["Izo The Grand Splicer"] = "Izo The Grand Splicer"
--[[Translation missing --]]
L["Jabbing Flyer"] = "Jabbing Flyer"
L["Jagged Hound"] = "Can dentado"
--[[Translation missing --]]
L["Jandice Barov"] = "Jandice Barov"
L["Jazshariu"] = "Jazshariu"
L["Jedoga Shadowseeker"] = "Jedoga Buscasombras"
L["Jes Howlis"] = "Jes Howlis"
L["Jiang"] = "Jiang"
L["Join"] = "Unirse"
L["Join Crew"] = "Unirse al grupo"
L["Join Live Session"] = "Unirse a la Sesión en Directo:%s%s: %s - %s"
L["Junkyard D.0.G."] = "P3RR0 de desguace"
L["Juvenile Runestag"] = "Venado rúnico juvenil"
L["K.U.-J.0."] = "KU-J0"
--[[Translation missing --]]
L["karaLowerShortName"] = "LOWER"
--[[Translation missing --]]
L["karaUpperShortName"] = "UPPER"
--[[Translation missing --]]
L["Kargesh Highguard"] = "Kargesh Highguard"
--[[Translation missing --]]
L["Kargesh Ribcrusher"] = "Kargesh Ribcrusher"
--[[Translation missing --]]
L["Keeza Quickfuse"] = "Keeza Quickfuse"
L["Kel'Thuzad"] = "Kel'Thuzad"
L["Keristrasza"] = "Keristrasza"
L["Khajin the Unyielding"] = "Khajin la Implacable"
--[[Translation missing --]]
L["Kikatal The Harvester"] = "Kikatal The Harvester"
L["King"] = "Rey"
L["King A'akul"] = "Rey A'akul"
L["King Bjorn"] = "Rey Bjorn"
L["King Dazar"] = "Rey Dazar"
L["King Deepbeard"] = "Rey Barbaprofunda"
L["King Dred"] = "Rey Dred"
L["King Gobbamak"] = "Rey Gobbamak"
L["King Haldor"] = "Rey Haldor"
L["King Rahu'ai"] = "Rey Rahu'ai"
L["King Ranulf"] = "Rey Ranulf"
L["King Timalji"] = "Rey Timalji"
L["King Tor"] = "Rey Tor"
L["King Ymiron"] = "Rey Ymiron"
L["Kings' Rest"] = "Reposo de los Reyes"
L["Kings' Rest Sublevel"] = "Subnivel de Reposo de los Reyes"
--[[Translation missing --]]
L["kingsRestShortName"] = "KR"
L["Kin-Tara"] = "Kin-Tara"
L["Klotos"] = "Klotos"
L["Knight Captain Valyri"] = "Capitana caballero Valyri"
L["Knock"] = "Empujar"
--[[Translation missing --]]
L["Kobold Flametender"] = "Kobold Flametender"
--[[Translation missing --]]
L["Kobold Taskworker"] = "Kobold Taskworker"
L["Kokia Blazehoof"] = "Kokia Pezuña de Fuego"
L["Kologarn"] = "Kologarn"
L["Koramar"] = "Koramar"
--[[Translation missing --]]
L["Krastinovian Carver"] = "Krastinovian Carver"
L["krBrutePatrolNote"] = "Este bruto dejará de patrullar cuando llegue Emisaria de las Mareas 7"
L["krGraveyardNote1"] = "Se desbloquea después de derrotar al El consejo de las Tribus"
--[[Translation missing --]]
L["Krik'thik Demolisher"] = "Krik'thik Demolisher"
--[[Translation missing --]]
L["Krik'thik Infiltrator"] = "Krik'thik Infiltrator"
--[[Translation missing --]]
L["Krik'thik Rager"] = "Krik'thik Rager"
--[[Translation missing --]]
L["Krik'thik Sapper"] = "Krik'thik Sapper"
--[[Translation missing --]]
L["Krik'thik Wind Shaper"] = "Krik'thik Wind Shaper"
L["Krik'thir the Gatewatcher"] = "Krik'thir el Vigía de las puertas"
L["Krolusk Hatchling"] = "Cría de crolusco"
L["Krolusk Pup"] = "Cachorro de crolusco"
L["krSkipNote"] = [=[Guía espiritual incólume%sSe desbloquea después de derrotar a Ensamblaje de purificación 1
 ]=]
L["Krystallus"] = "Krystallus"
L["Kryxis the Voracious"] = "Kryxis el Voraz"
--[[Translation missing --]]
L["Kuai the Brute"] = "Kuai the Brute"
L["Kul Tiran Footman"] = "Lacayo de Kul Tiras"
L["Kul Tiran Halberd"] = "Alabardero de Kul Tiras"
L["Kul Tiran Marksman"] = "Tirador de Kul Tiras"
L["Kul Tiran Vanguard"] = "Vanguardia de Kul Tiras"
L["Kul Tiran Wavetender"] = "Cuidaolas de Kul Tiras"
L["Kula the Butcher"] = "Kula la Carnicera"
L["Kul'tharok"] = "Kul'tharok"
L["Kur'talos Ravencrest"] = "Kur'talos Cresta Cuervo"
L["Kyrakka"] = "Kyrakka"
L["Kyrian Dark-Praetor"] = "Pretora oscura kyriana"
L["Kyrian Stitchwerk"] = "Remendado kyriano"
--[[Translation missing --]]
L["Kyrioss"] = "Kyrioss"
--[[Translation missing --]]
L["Lady Baihu"] = "Lady Baihu"
L["Lady Blaumeux"] = "Lady Blaumeux"
L["Lady Hatecoil"] = "Lady Espiral de Odio"
L["Lady Naz'jar"] = "Lady Naz'jar"
L["Lady Velandras Ravencrest"] = "Lady Velandras Cresta Cuervo"
L["Lady Waycrest"] = "Lady Crestavía"
L["Lakesis"] = "Lakesis"
L["Language"] = "Lenguaje"
L["LargePresetWarning"] = "Estás intentando compartir una ruta muy grande (%d caracteres)%sSe recomienda usar la función de exportación y compartir rutas grandes a través de sitios web externos.%s¿Estás seguro de que deseas compartir esta ruta?%s"
L["Lashing Voidling"] = "Retoño del Vacío azotador"
L["Lava Flare"] = "Bengala de lava"
L["Lavanthor"] = "Lavanthor"
--[[Translation missing --]]
L["Leaping Spark"] = "Leaping Spark"
--[[Translation missing --]]
L["Legion"] = "Legion"
L["Legion Hound"] = "Can de la Legión"
L["Lerai, Timesworn Maiden"] = "Lerai, doncella vetusta"
L["Lesser Sha"] = "Sha inferior"
L["Level %d %s"] = "Nivel %d %s"
L["Levels below 10 will hide enemies related to seasonal affixes"] = "Niveles inferiores a 10 ocultarán enemigos relacionados a afijos de temporada"
L["Ley-Guardian Eregos"] = "Guardián-Ley Eregos"
L["Leymor"] = "Leymor"
L["Library Floor"] = "Suelo de la Biblioteca"
L["Life Warden Gola"] = "Celador de vida Gola"
L["Lightning Charged Iron Dwarf"] = "Enano férreo de Relámpago cargado"
L["Lightning Construct"] = "Ensamblaje de relámpagos"
--[[Translation missing --]]
L["Lightspawn"] = "Lightspawn"
--[[Translation missing --]]
L["Lilian Voss"] = "Lilian Voss"
L["Link Spells"] = "Enlazar Hechizos"
L["Liu Flameheart"] = "Liu Corazón Llameante"
L["Live"] = "Directo"
L["Live Session"] = "Sesión en Directo"
L["Living Current"] = "Corriente viva"
L["Living Mojo"] = "Mojo viviente"
L["Living Monstrosity"] = "Monstruosidad viviente"
L["Living Rot"] = "Putrefacción viva"
L["Living Waste"] = "Residuo viviente"
--[[Translation missing --]]
L["Loaderbot"] = "Loaderbot"
L["Loatheb"] = "Loatheb"
L["Local color blind mode"] = "Modo daltónicos local"
--[[Translation missing --]]
L["localeButtonTooltip1"] = "Requires the \"AddonLocale\" AddOn"
--[[Translation missing --]]
L["localeButtonTooltip2"] = "Click to start settings dialog in chat"
L["Locked"] = "Bloqueada"
L["Loken"] = "Loken"
L["Lord Chamberlain"] = "Lord chambelán"
L["Lord Etheldrin Ravencrest"] = "Lord Etheldrin Cresta Cuervo"
L["Lord Ravencrest's Chamber"] = "Aposento de Lord Cresta Cuervo"
L["Lord Stormsong"] = "Lord Canto Tormenta"
L["Lord Waycrest"] = "Lord Crestavía"
L["Lost Soul"] = "Alma perdida"
L["Loszkeleth"] = "Loszkeleth"
L["Lower Broken Stair"] = "La Escalera Quebrada Inferior"
--[[Translation missing --]]
L["Lower Pinnacle"] = "Lower Pinnacle"
--[[Translation missing --]]
L["LowerChamber"] = "Lower Chamber"
--[[Translation missing --]]
L["Lowly Moleherd"] = "Lowly Moleherd"
L["Loyal Creation"] = "Creación leal"
L["Loyal Stoneborn"] = "Natopiedra fiel"
L["Lubricator"] = "Lubricador"
L["Ludwig Von Tortollan"] = "Ludwig Von Tortollan"
L["L'ura"] = "L'ura"
L["Lurking Tempest"] = "Tempestad acechante"
L["Mad Scientist"] = "Científico loco"
L["Maddened Survivalist"] = "Superviviente enajenado"
L["Maexxna"] = "Maexxna"
L["Mage Hunter Ascendant"] = "Ascendiente cazador de magos"
L["Mage Hunter Initiate"] = "Iniciado cazador de magos"
L["Mage Slayer"] = "Asesino de magos"
L["Mage-Lord Urom"] = "Señor de la magia Urom"
L["MaggotNote"] = [=[Nota en Cresa devoradora:%s%sCresa devoradora con el beneficio 'Parasitario' intentara 'Infestar' a los Jugadores%sTras un lanzar exitoso de 'Infestar' la Cresa devoradora desaparecera y engendrará 2x Cresa devoradora después del perjuicio se agote en el jugador infestado.%sSolo puedes ganar 1 cuenta por matar la inicial Cresa devoradora - Las 2 reciéntes Cresas devoradoras no cuentan para tropas enemigas.%s%sCampesino infectado engendran 3x Cresa devoradora de los cuales 1 cuenta para tropas enemigas.%sEstas Cresas devoradoras están mapeados al lado de los Campesinos infectados.

]=]
--[[Translation missing --]]
L["Magic"] = "Magic"
L["Magma Rager"] = "Furibundo de magma"
L["Magmatusk"] = "Magmacolmillo"
L["Maiden of Grief"] = "Doncella de Pena"
L["Maiden of Virtue"] = "Doncella de Virtud"
L["Make this preset the live preset"] = "Haz que esta ruta sea el preset en vivo"
--[[Translation missing --]]
L["Make window transparent in combat"] = "Make window transparent in combat"
L["Makogg Emberblade"] = "Makogg Hojascuas"
L["Mak'rana Hardshell"] = "Caparazón duro de Mak'rana"
L["Mak'rana Siltwalker"] = "Caminante de limo de Mak'rana"
L["Malfunctioning Scrapbot"] = "Robot de chatarra estropeado"
L["Mal'Ganis"] = "Mal'Ganis"
L["Malignant Defiler"] = "Rapiñador maligno"
L["Malignant Spawn"] = "Engendro maligno"
L["Mana Confluence"] = "Confluencia de maná"
L["Mana Devourer"] = "Devorador de maná"
L["Mana Saber"] = "Sable de maná"
L["Mana Wyrm"] = "Vermis de maná"
--[[Translation missing --]]
L["manaDevourerNote"] = "Mana Devourer 1 is representing the Boss because it also awards enemy forces"
L["Mana-Gorged Wyrm"] = "Vermis atiborrada de maná"
L["Mangrove Ent"] = "Ent mangle"
L["Maniacal Soulbinder"] = "Vinculador de almas maníaco"
L["Manifestation of Envy"] = "Manifestación de la envidia"
--[[Translation missing --]]
L["Manifested Shadow"] = "Manifested Shadow"
L["Manifested Timeways"] = "Líneas temporales manifestadas"
L["Marauding Geist"] = "Geist merodeador"
L["Margrave Stradama"] = "Margravina Stradama"
L["Marked Sister"] = "Hermana marcada"
L["Market Peacekeeper"] = "Pacificador del mercado"
L["Maruuk"] = "Maruuk"
--[[Translation missing --]]
L["Master Archer"] = "Master Archer"
L["Master Necromancer"] = "Maestro nigromante"
--[[Translation missing --]]
L["Master Snowdrift"] = "Master Snowdrift"
L["Master's Terrace"] = "El Bancal del Maestro"
L["Matron Alma"] = "Matriarca Alma"
L["Matron Bryndle"] = "Matriarca Bryndle"
L["Mature Krolusk"] = "Crolusco maduro"
--[[Translation missing --]]
L["MausoleumOfLegends"] = "Mausoleum Of Legends"
L["Maw of Souls"] = "Fauce de Almas"
--[[Translation missing --]]
L["mawOfSoulsShortName"] = "MOS"
L["Mchimba the Embalmer"] = "Mchimba el Embalsamador"
L["MDI Mode"] = "Modo MDI"
--[[Translation missing --]]
L["MDT Error"] = "MDT Error"
--[[Translation missing --]]
L["MDT: Cannot add enemy - you are trying to add too many enemies of the same kind"] = "MDT: Cannot add enemy - you are trying to add too many enemies of the same kind"
L["MDT: Error importing preset"] = "MDT: Error importando la ruta"
L["MDT: Spells for %s:"] = "MDT: Hechizos para %s:"
--[[Translation missing --]]
L["MDT: Use /mdt minimap to show the minimap icon again"] = "MDT: Use /mdt minimap to show the minimap icon again"
--[[Translation missing --]]
L["MDTGuideNote"] = "MDTGuide is not affiliated with Mythic Dungeon Tools and is a seperate AddOn."
L["Meathook"] = "Gancho"
L["Mech Jockey"] = "Jinete de meca"
--[[Translation missing --]]
L["Mechadrone Sniper"] = "Mechadrone Sniper"
--[[Translation missing --]]
L["Mechagon"] = "Mechagon"
L["Mechagon - Junkyard"] = "Mecandria - Desguace"
L["Mechagon - Workshop"] = "Mecandria - Taller"
L["Mechagon Cavalry"] = "Caballería de Mecandria"
L["Mechagon Citizen"] = "Ciudadano de Mecandria"
L["Mechagon City"] = "Ciudad de Mecandria"
L["Mechagon Island"] = "Isla Mecandria"
L["Mechagon Island (Tunnels)"] = "Isla Mecandria (Tuneles)"
L["Mechagon Mechanic"] = "Mecánico de Mecandria"
L["Mechagon Prowler"] = "Merodeador de Mecandria"
L["Mechagon Renormalizer"] = "Renormalizadora de Mecandria"
L["Mechagon Tinkerer"] = "Manitas de Mecandria"
L["Mechagon Trooper"] = "Agente de Mecandria"
--[[Translation missing --]]
L["mechagonCityShortName"] = "WORK"
--[[Translation missing --]]
L["mechagonIslandShortName"] = "YARD"
--[[Translation missing --]]
L["mechagonWorkshopShortName"] = "WORK"
L["Mechanical"] = "Mécanico"
L["Mechanized Peacekeeper"] = "Pacificador mecanizado"
L["Melded Berserker"] = "Rabioso fusionado"
L["Melidrussa Chillworn"] = "Melidrussa Ajafrío"
--[[Translation missing --]]
L["Menial Laborer"] = "Menial Laborer"
L["Mephistroth"] = "Mephistroth"
L["Merektha"] = "Merektha"
--[[Translation missing --]]
L["Metal Gunk"] = "Metal Gunk"
--[[Translation missing --]]
L["Middle-click to disable Minimap Button"] = "Middle-click to disable Minimap Button"
L["Midnight"] = "Medianoche"
L["Mightstone Breaker"] = "Rompedor Piedra de Poderío"
L["Millhouse Manastorm"] = "Molino Tormenta de Maná"
L["Millificent Manastorm"] = "Malífica Tormenta de Maná"
L["Mimiron"] = "Mimiron"
L["Mind Control"] = "Control Mental"
--[[Translation missing --]]
L["Mind Soothe"] = "Mind Soothe"
L["Mindbender Ghur'sha"] = "Dominamentes Ghur'sha"
L["Mindless Servant"] = "Sirviente descerebrado"
L["Mindshattered Screecher"] = "Estridador Mentequebrada"
L["Mine Rat"] = "Rata de mina"
L["minecartNote"] = "Carro de mina%sUsable por los jugadores"
--[[Translation missing --]]
L["Ming the Cunning"] = "Ming the Cunning"
L["Minion of Doubt"] = "Esbirro de la duda"
--[[Translation missing --]]
L["Minion of Ghur'sha"] = "Minion of Ghur'sha"
L["Minion of Zul"] = "Esbirro de Zul"
L["Minister of Air"] = "Ministro del Aire"
L["Mire Soldier"] = "Soldado de lodazal"
L["Misguided Nymph"] = "Ninfa desconcertada"
L["Mistcaller"] = "Clamaneblina"
--[[Translation missing --]]
L["Mists of Tirna Scithe"] = "Mists of Tirna Scithe"
--[[Translation missing --]]
L["mistsShortName"] = "MISTS"
L["Mistveil Defender"] = "Defensora Velo de Niebla"
L["Mistveil Gorgegullet"] = "Engullidor Velo de Niebla"
L["Mistveil Guardian"] = "Guardián Velo de Niebla"
L["Mistveil Matriarch"] = "Matriarca Velo de Niebla"
L["Mistveil Nightblossom"] = "Flor de noche Velo de Niebla"
L["Mistveil Shaper"] = "Modelador Velo de Niebla"
L["Mistveil Stalker"] = "Acechador Velo de Niebla"
L["Mistveil Stinger"] = "Aguijonero Velo de Niebla"
L["Mistveil Tender"] = "Cuidadora Velo de Niebla"
L["mlGraveyardNote1"] = "Se desbloquea después de derrotar a Repartetundas de pago"
L["mlGraveyardNote2"] = "Se desbloquea después de llegar al final del paseo en el carro de minas"
L["mlGraveyardNote3"] = "Se desbloquea después de derrotar a Rixxa Flujollama"
L["mlJockeyNote"] = "Jinete de mecas 21 y 22 tienen que ser marcar en el momento en que sus Pacificadores son destruidos"
L["Mogul Razdunk"] = "Mogul Razdunk"
--[[Translation missing --]]
L["Mogu'shan Palace"] = "Mogu'shan Palace"
--[[Translation missing --]]
L["mogushanPalaceShortName"] = "MOGU"
L["Molten Colossus"] = "Coloso fundido"
--[[Translation missing --]]
L["Molten Giant"] = "Molten Giant"
L["Monstrous Corpse Spider"] = "Araña cadáver monstruosa"
L["Monstrous Decay"] = "Descomposición monstruosa"
L["Monzumi"] = "Monzumi"
L["Moorabi"] = "Moorabi"
--[[Translation missing --]]
L["MoP Challenge Mode"] = "MoP Challenge Mode"
L["Moragg"] = "Moragg"
L["Morchie"] = "Mocri"
L["Mordretha, the Endless Empress"] = "Mordretha, la Emperatriz Eterna"
L["Moroes"] = "Moroes"
--[[Translation missing --]]
L["motherlodeShortName"] = "ML"
L["Mouseover a patrolling enemy with a blue border to view the patrol path."] = "Pase el ratón sobre un enemigo que patrulla con un borde azul para ver el camino de patrulla."
L["Mouseover the Live button while in a group to learn more about Live mode."] = "Pase el ratón sobre el botón Directo mientras está en un grupo para obtener más información sobre el modo Directo."
L["Move Object"] = "Mover Objeto"
L["Mueh'zala"] = "Mueh'zala"
L["Murkbrine Fishmancer"] = "Piscimante Salmuerasucia"
L["Murkbrine Scalebinder"] = "Sujetascamas Salmuerasucia"
L["Murkbrine Shellcrusher"] = "Rompeconchas Salmuerasucia"
L["Murkbrine Shorerunner"] = "Correcostas Salmuerasucia"
L["Murkbrine Wavejumper"] = "Saltaolas Salmuerasucia"
--[[Translation missing --]]
L["Mu'Shiba"] = "Mu'Shiba"
--[[Translation missing --]]
L["Mutated Hatchling"] = "Mutated Hatchling"
L["Mystic Ssa'veh"] = "Mística Ssa'veh"
L["Mythresh, Sky's Talons"] = "Mythresh, Garfas del Cielo"
L["Naeno Megacrash"] = "Naeno Megachoque"
--[[Translation missing --]]
L["Nakt"] = "Nakt"
L["Nal'asha"] = "Nal'asha"
L["Nalthor the Rimebinder"] = "Nalthor Clamaescarcha"
L["Nal'tira"] = "Nal'tira"
L["Naraxas"] = "Naraxas"
L["Nar'zudah"] = "Nar'zudah"
L["Nathrezim Infiltrator"] = "Infiltrado Nathrezim"
L["Nature's Blade"] = "Hoja de la Naturaleza"
--[[Translation missing --]]
L["Naxxramas"] = "Naxxramas"
L["Naxxramas Acolyte"] = "Acólito de Naxxramas"
L["Naxxramas Cultist"] = "Cultor de Naxxramas"
--[[Translation missing --]]
L["Naz'jar Frost Witch"] = "Naz'jar Frost Witch"
L["Naz'jar Honor Guard"] = "Guardia de honor Naz'jar"
L["Naz'jar Invader"] = "Invasor Naz'jar"
--[[Translation missing --]]
L["Naz'jar Oracle"] = "Naz'jar Oracle"
--[[Translation missing --]]
L["Naz'jar Ravager"] = "Naz'jar Ravager"
L["Naz'jar Sentinel"] = "Centinela Naz'jar"
L["Naz'jar Tempest Witch"] = "Bruja de la tempestad Naz'jar"
L["Necro Knight"] = "Caballero Necro"
L["Necrotic"] = "Necrótica"
L["Necrotic Spiderling"] = "Arañita necrótica"
--[[Translation missing --]]
L["necroticWakeShortName"] = "NW"
L["Neesa Nox"] = "Neesa Nox"
L["Nefarious Darkspeaker"] = "Hablaoscuro nefario"
L["Nekthara the Mangler"] = "Nekthara el Mutilador"
L["Neltharion's Lair"] = "Guarida de Neltharion"
L["Neltharion's Lair Sublevel"] = "Subnivel 1 de Guarida de Neltharion"
--[[Translation missing --]]
L["neltharionsLairShortName"] = "NL"
--[[Translation missing --]]
L["Neltharus"] = "Neltharus"
--[[Translation missing --]]
L["neltharusChain"] = "Burning Chain"
--[[Translation missing --]]
L["neltharusShortName"] = "NELT"
--[[Translation missing --]]
L["Nerubian Hauler"] = "Nerubian Hauler"
L["Ner'zhul"] = "Ner'zhul"
L["Netherspace"] = "Espacio Abisal"
L["New"] = "Nuevo"
L["New NPC at Cursor Position"] = "Nuevo NPC en la posición del ratón"
L["New Patrol Waypoint at Cursor Position"] = "Nuevo Punto de Referencia de Patrulla en la posición del ratón"
L["New Preset"] = "Nueva Ruta"
L["Next to the NPC"] = "Al lado del PNJ"
L["Nhallish"] = "Nhallish"
L["Night Watch Mariner"] = "Marino de la Guardia Nocturna"
L["Nightborne Reclaimer"] = "Reivindicador Nocheterna"
L["Nightborne Spellsword"] = "Hojahechizo Nocheterna"
--[[Translation missing --]]
L["Nightfall Commander"] = "Nightfall Commander"
--[[Translation missing --]]
L["Nightfall Curseblade"] = "Nightfall Curseblade"
--[[Translation missing --]]
L["Nightfall Dark Architect"] = "Nightfall Dark Architect"
--[[Translation missing --]]
L["Nightfall Darkcaster"] = "Nightfall Darkcaster"
--[[Translation missing --]]
L["Nightfall Ritualist"] = "Nightfall Ritualist"
--[[Translation missing --]]
L["Nightfall Shadowalker"] = "Nightfall Shadowalker"
--[[Translation missing --]]
L["Nightfall Shadowmage"] = "Nightfall Shadowmage"
--[[Translation missing --]]
L["Nightfall Tactician"] = "Nightfall Tactician"
L["Nightmare Dweller"] = "Habitante de la Pesadilla"
L["Nitrogg Thundertower"] = "Nitrogg Torre del Trueno"
--[[Translation missing --]]
L["Njorndir Preparation"] = "Njorndir Preparation"
L["Noble Skirmisher"] = "Hostigador noble"
--[[Translation missing --]]
L["noDungeonData1"] = "It seems that you have no dungeon data yet."
--[[Translation missing --]]
L["noDungeonData2"] = "Create your own data via /mdt devmode"
--[[Translation missing --]]
L["noDungeonData3"] = "Alternatively learn how to get optional dungeon data here:"
L["Nokhud Beastmaster"] = "Maestra de bestias Nokhud"
L["Nokhud Defender"] = "Defensor Nokhud"
L["Nokhud Hornsounder"] = "Sonacuernos Nokhud"
--[[Translation missing --]]
L["Nokhud Houndsman"] = "Nokhud Houndsman"
L["Nokhud Lancemaster"] = "Maestra de lanzas Nokhud"
L["Nokhud Longbow"] = "Arquera con arco largo Nokhud"
L["Nokhud Neophyte"] = "Neófito Nokhud"
L["Nokhud Plainstomper"] = "Pisallanuras Nokhud"
--[[Translation missing --]]
L["Nokhud Saboteur"] = "Nokhud Saboteur"
--[[Translation missing --]]
L["Nokhud Stormcaster"] = "Nokhud Stormcaster"
L["Nokhud Thunderfist"] = "Puñotrueno Nokhud"
--[[Translation missing --]]
L["Nokhud Villager"] = "Nokhud Villager"
--[[Translation missing --]]
L["Nokhud Warhound"] = "Nokhud Warhound"
--[[Translation missing --]]
L["Nokhud Warsmith"] = "Nokhud Warsmith"
L["Nokhud Warspear"] = "Lanza de guerra Nokhud"
--[[Translation missing --]]
L["nokhudOffensiveShortName"] = "NO"
--[[Translation missing --]]
L["None"] = "None"
L["Not specified"] = "No especificado"
L["Note Text:"] = "Texto de Nota:"
L["Noth the Plaguebringer"] = "Noth el Pesteador"
L["Novos the Summoner"] = "Novos el Invocador"
L["NPCs"] = "PNJs"
L["Nullmagic Hornswog"] = "Cornisapo anulamagia"
--[[Translation missing --]]
L["Nx"] = "Nx"
L["Oakheart"] = "Corazón de Roble"
L["Oasis Security"] = "Seguridad del Oasis"
L["Odyn"] = "Odyn"
L["Off-Duty Laborer"] = "Obrero fuera de servicio"
L["Officer Quarters"] = "Cuartel de los Oficiales"
L["Ogron Laborer"] = "Obrero ogron"
--[[Translation missing --]]
L["Okay"] = "Okay"
--[[Translation missing --]]
L["Ol' Waxbeard"] = "Ol' Waxbeard"
L["Olaf"] = "Olaf"
L["Olmyr the Enlightened"] = "Olmyr el Iluminado"
L["Omega Buster"] = "Destrozador omega"
--[[Translation missing --]]
L["Ook-Ook"] = "Ook-Ook"
L["Oozing Leftovers"] = "Sobras rezumantes"
--[[Translation missing --]]
L["Open an issue on GitHub"] = "Open an issue on GitHub"
--[[Translation missing --]]
L["Open Enemy Info"] = "Open Enemy Info"
L["Open MDI override options"] = "Abrir las opciones de anulación de MDI"
--[[Translation missing --]]
L["openSettingsTooltip"] = "Click to open settings"
L["Opera Hall Balcony"] = "Balcón de la Sala de la Ópera"
--[[Translation missing --]]
L["Opera Hall: Wikket"] = "Opera Hall: Wikket"
--[[Translation missing --]]
L["Operation: Floodgate"] = "Operation: Floodgate"
--[[Translation missing --]]
L["operationFloodgateShortName"] = "FLOOD"
L["Oppressive Banner"] = "Estandarte opresivo"
--[[Translation missing --]]
L["Orator Krixvizk"] = "Orator Krixvizk"
L["Ordnance Specialist"] = "Especialista de artillería"
L["Ore Elemental"] = "Elemental de mineral"
L["Ormorok the Tree-Shaper"] = "Ormorok el Talador"
L["Oros Coldheart"] = "Oros Corazongélido"
L["Oryphrion"] = "Oryphrion"
L["Oshir"] = "Oshir"
L["Ossified Conscript"] = "Conscripto osificado"
--[[Translation missing --]]
L["Overcharged Sentinel"] = "Overcharged Sentinel"
L["Overflowing"] = "Rebosante"
--[[Translation missing --]]
L["Overgorged Mite"] = "Overgorged Mite"
L["Overgrown Ancient"] = "Anciano desmesurado"
--[[Translation missing --]]
L["Overgrown Roots"] = "Overgrown Roots"
--[[Translation missing --]]
L["overgrownRootsDescription"] = "Usable by Night Elves, Tauren, Highmountain Tauren, Druids, and Khaz Algar Herbalists (25)"
L["Overloaded Mailemental"] = "Elemailtal sobrecargado"
L["Overseer Korgus"] = "Sobrestante Korgus"
L["Overseer Lahar"] = "Sobrestante Lahar"
L["Overseer's Redoubt"] = "Reducto del Sobrestante"
L["Overseer's Summit"] = "Cumbre del Sobrestante"
L["Ozumat"] = "Ozumat"
L["P.O.S.T. Master"] = "Jefe de correos"
L["P.O.S.T. Worker"] = "Trabajador de correos"
L["Paceran the Virulent"] = "Paceran el Virulento"
--[[Translation missing --]]
L["Pack Mole"] = "Pack Mole"
L["Paladin of the Silver Hand"] = "Paladín de la Mano de Plata"
L["Pallid Gorger"] = "Engullidor pálido"
L["Parts Recovery Technician"] = "Técnico de recuperación de piezas"
L["Patchwerk"] = "Remendejo"
L["Patchwerk Soldier"] = "Soldado Remendejo"
L["Patchwork Construct"] = "Ensamblaje de retazos"
L["Patchwork Golem"] = "Gólem de retazos"
L["Path of Illumination"] = "Senda de la Iluminación"
L["Patrol Captain Gerdo"] = "Capitán de patrulleros Gerdo"
L["Pendule"] = "Péndulo"
L["Peril"] = "Temeridad"
L["Pestilence Slime"] = "Baba de pestilencia"
L["Pestilent Harvester"] = "Cosechador pestilente"
L["Phantasmal Air"] = "Aire fantasmal"
L["Phantasmal Cloudscraper"] = "Desechanube fantasmal"
L["Phantasmal Fire"] = "Fuego fantasmal"
L["Phantasmal Mammoth"] = "Mamut fantasmal"
L["Phantasmal Murloc"] = "Múrloc fantasmal"
L["Phantasmal Naga"] = "Naga fantasmal"
L["Phantasmal Ogre"] = "Ogro fantasmal"
L["Phantasmal Water"] = "Agua fantasmal"
L["Phantasmal Wolf"] = "Lobo fantasmal"
L["Phantom Crew"] = "Tripulación fantasma"
L["Phantom Guardsman"] = "Aparición de custodio"
L["Phantom Guest"] = "Aparición de invitado"
--[[Translation missing --]]
L["Pile of Corpses"] = "Pile of Corpses"
L["Pistonhead Blaster"] = "Acribillador testapistón"
L["Pistonhead Mechanic"] = "Mecánico testapistón"
L["Pistonhead Scrapper"] = "Desguazadora testapistón"
L["Pitwarden Gwarnok"] = "Celador de fosa Gwarnok"
L["Plague Beast"] = "Bestia de peste"
L["Plague Bomb"] = "Bomba de peste"
L["Plague Doctor"] = "Doctora de peste"
L["Plague Slime"] = "Babosa de peste"
L["Plague Walker"] = "Caminante de peste"
L["Plaguebelcher"] = "Eructador de peste"
L["Plaguebinder"] = "Vinculapestes"
L["Plagueborer"] = "Perforapeste"
L["Plaguebound"] = "Ligado a la peste"
L["Plaguebound Devoted"] = "Devota ligada a la peste"
L["Plaguebound Fallen"] = "Caída ligada a la peste"
L["Plagued Bat"] = "Murciélago apestado"
L["Plagued Rat"] = "Rata apestada"
--[[Translation missing --]]
L["Plaguefall"] = "Plaguefall"
--[[Translation missing --]]
L["plaguefallDevotedNote"] = "Plaguefall Devoted which have already been transformed by Oozing Carcass before engaging Ickor Bileflesh do not award Enemy Forces."
--[[Translation missing --]]
L["plaguefallShortName"] = "PF"
L["Plagueroc"] = "Roc de peste"
L["Plain Texture"] = "Textura Plana"
L["Players can join the live session by either clicking this button or the Live Session chat link"] = "Los jugadores pueden unirse a la Sesión en Directo clickando este botón o el enlace del chat de la Sesión en Directo"
L["Please report any bugs on https://github.com/Nnoggie/MythicDungeonTools/issues"] = "Por favor, informe de cualquier error en https://github.com/Nnoggie/MythicDungeonTools/issues"
L["Plundering Geist"] = "Geist desvalijador"
--[[Translation missing --]]
L["Poison"] = "Poison"
L["Poisonous Skitterer"] = "Arácnida venenosa"
L["Polymorph"] = "Polimorfia"
L["Portal Guardian"] = "Guardián de portal"
L["Portal Keeper"] = "Vigilante de portal"
L["Portalmancer Zo'honn"] = "Portalmante Zo'honn"
L["Portrait"] = "Retrato"
L["Posh Vacationer"] = "Vacacionista elegante"
L["Preset '%s' already exists"] = "La ruta '%s' ya existe"
L["Preset Export"] = "Exportar Ruta"
L["Preset Name"] = "Nombre de Ruta"
--[[Translation missing --]]
L["Prideful"] = "Prideful"
L["Priestess Alun'za"] = "Sacerdotisa Alun'za"
L["Priestess of Misery"] = "Sacerdotisa de la miseria"
L["Primal Gust"] = "Soplo primigenio"
L["Primal Juggernaut"] = "Gigante primigenio"
L["Primal Stormshield"] = "Escudo de tormenta primigenio"
L["Primal Terrasentry"] = "Terracentinela primigenio"
L["Primal Thundercloud"] = "Cumulonimbo primigenio"
L["Primal Tsunami"] = "Tsunami primigenio"
L["Primalist Arcblade"] = "Filoarco primalista"
L["Primalist Cinderweaver"] = "Primalista tejecinéreo"
L["Primalist Earthshaker"] = "Sacudetierras primalista"
L["Primalist Flamedancer"] = "Primalista danzallamas"
L["Primalist Galesinger"] = "Cantavientos primalista"
L["Primalist Geomancer"] = "Geomántico primalista"
L["Primalist Icecaller"] = "Llamahielos primalista"
L["Primalist Ravager"] = "Primalista devastador"
L["Primalist Shockcaster"] = "Primalista taumaturgo de descargas"
L["Primalist Shocktrooper"] = "Soldado de choque primalista"
L["Primalist Stormspeaker"] = "Primalista hablatormentas"
L["Primalist Thunderbeast"] = "Bestiatrueno primalista"
L["Prince Keleseth"] = "Príncipe Keleseth"
L["Prince Taldaram"] = "Príncipe Taldaram"
--[[Translation missing --]]
L["Prioress Murrpray"] = "Prioress Murrpray"
--[[Translation missing --]]
L["Priory of the Sacred Flame"] = "Priory of the Sacred Flame"
--[[Translation missing --]]
L["priory1BossNote"] = "The mini-boss you decide to fight together with the boss does not award enemy forces"
--[[Translation missing --]]
L["prioryItemDescription"] = "Usable by Priests or |cFFF48CBAPaladins|r"
--[[Translation missing --]]
L["prioryShortName"] = "PRIO"
L["Prison Bars"] = "Barras de la prisión"
L["Prison Gate"] = "Puerta de la prisión"
--[[Translation missing --]]
L["Professor Slate"] = "Professor Slate"
--[[Translation missing --]]
L["Progenitor Relic"] = "Progenitor Relic"
L["Proto-Drake Handler"] = "Cuidador de protodracos"
L["Proto-Drake Rider"] = "Jinete de protodracos"
--[[Translation missing --]]
L["Provide feedback in Discord"] = "Provide feedback in Discord"
L["Pull Drop Clear Pull"] = "Limpiar Pull"
--[[Translation missing --]]
L["Pull Drop Clear Pulls"] = "Clear Pulls"
L["Pull Drop Close"] = "Cerrar"
L["Pull Drop Color"] = "Color"
L["Pull Drop Color Settings"] = "Configuraciones de color"
L["Pull Drop Colorize Preset"] = "Colorear Ruta"
L["Pull Drop Delete"] = "Eliminar"
L["Pull Drop Insert after"] = "Insertar después"
L["Pull Drop Insert before"] = "Insertar antes"
L["Pull Drop Merge"] = "Unir"
L["Pull Drop Merge down"] = "Unir abajo"
L["Pull Drop Merge up"] = "Unir arriba"
L["Pull Drop Move down"] = "Mover abajo"
L["Pull Drop Move up"] = "Mover arriba"
L["Pull Drop Reset Color"] = "Reiniciar Color"
L["Pull Drop Reset Preset"] = "Reiniciar Ruta"
L["Purification Construct"] = "Ensamblaje de purificación"
L["Putrid Butcher"] = "Carnicero pútrido"
L["Putrid Pyromancer"] = "Piromántico pútrido"
L["Qalashi Blacksmith"] = "Herrero qalashi"
L["Qalashi Bonesplitter"] = "Partehuesos qalashi"
L["Qalashi Bonetender"] = "Cuidahuesos qalashi"
L["Qalashi Hunter"] = "Cazador qalashi"
L["Qalashi Irontorch"] = "Antorchaférrea qalashi"
L["Qalashi Lavabearer"] = "Portalava qalashi"
L["Qalashi Lavamancer"] = "Lavamántico qalashi"
L["Qalashi Plunderer"] = "Desvalijador qalashi"
L["Qalashi Spinecrusher"] = "Aplastaspinazos qalashi"
L["Qalashi Thaumaturge"] = "Taumaturga qalashi"
L["Qalashi Trainee"] = "Recluta qalashi"
L["Qalashi Warden"] = "Celador qalashi"
L["Quaking"] = "Sísmica"
--[[Translation missing --]]
L["Quartermaster Koratite"] = "Quartermaster Koratite"
L["Queen Patlaa"] = "Reina Patlaa"
L["Queen Wasi"] = "Reina Wasi"
--[[Translation missing --]]
L["Quilen Guardian"] = "Quilen Guardian"
L["Raal the Gluttonous"] = "Raal el Glotón"
--[[Translation missing --]]
L["Radiating Voidstone"] = "Radiating Voidstone"
--[[Translation missing --]]
L["Rafters"] = "Rafters"
L["Rageclaw"] = "Garrafuria"
L["Raging"] = "Furibunda"
L["Raging Bloodhorn"] = "Cuernosangre enfurecido"
L["Raging Construct"] = "Ensamblaje enfurecido"
--[[Translation missing --]]
L["Raigonn"] = "Raigonn"
L["Railmaster Rocketspark"] = "Maestro de raíles Chispahete"
L["Rainbow"] = "Arcoíris"
L["Rampaging Clefthoof"] = "Uñagrieta arrasador"
L["Rancid Gasbag"] = "Saco de gas rancio"
--[[Translation missing --]]
L["Rank Overseer"] = "Rank Overseer"
--[[Translation missing --]]
L["Rashanan"] = "Rashanan"
L["Rat"] = "Rata"
--[[Translation missing --]]
L["Rattlegore"] = "Rattlegore"
--[[Translation missing --]]
L["Ravaging Scavenger"] = "Ravaging Scavenger"
--[[Translation missing --]]
L["Ravenous Cinderbee"] = "Ravenous Cinderbee"
--[[Translation missing --]]
L["Ravenous Crawler"] = "Ravenous Crawler"
--[[Translation missing --]]
L["Ravenous Destroyer"] = "Ravenous Destroyer"
L["Ravenous Dreadbat"] = "Murciélago aterrador voraz"
--[[Translation missing --]]
L["Ravenous Scarab"] = "Ravenous Scarab"
--[[Translation missing --]]
L["Ravenous Wolf"] = "Ravenous Wolf"
L["Ravenshold"] = "Bastión de los Cuervos"
L["Razorscale"] = "Tajoescama"
L["Reanimated Crossbowman"] = "Ballestero reanimado"
L["Reanimated Guardian"] = "Guardián reanimado"
L["Reanimated Honor Guard"] = "Guardia de honor reanimado"
L["Reanimated Mage"] = "Mago reanimado"
L["Reanimated Ritual Bones"] = "Huesos de ritual reanimados"
L["Reanimated Warrior"] = "Guerrero reanimado"
L["Reanimation Totem"] = "Tótem de reanimación"
L["Reaping"] = "Segadora"
--[[Translation missing --]]
L["Rear Train Cars"] = "Rear Train Cars"
L["receiveErrorUpdate"] = "MDT no pudó recibir una ruta, ¡por favor asegurate que el remitente %s tiene la  ultima versión de MDT instalada!"
L["Receiving: ..."] = "Reciviendo: ..."
L["Red, Green and Blue"] = "Rojo, Verde y Azúl"
L["Redo"] = "Rehacer"
--[[Translation missing --]]
L["redoDrawing"] = "Redo Drawing"
L["Reformed Maiden"] = "Doncella reformada"
L["Refreshment Vendor"] = "Vendedora de refrigerios"
L["Refti Custodian"] = "Custodio refti"
L["Refti Defender"] = "Defensor refti"
L["Regal Mistdancer"] = "Bailarín de la niebla regio"
--[[Translation missing --]]
L["Regenerating Sha"] = "Regenerating Sha"
--[[Translation missing --]]
L["Reinforced Drone"] = "Reinforced Drone"
L["Rek the Hardened"] = "Rek la Endurecida"
L["Relentless"] = "Incansable"
L["Remnant of Fury"] = "Remanente de furia"
L["Rename"] = "Renombrar"
L["Rename Preset"] = "Renombrar Ruta"
L["Rename the preset"] = "Renombrar la ruta"
L["Repentance"] = "Arrepentimiento"
--[[Translation missing --]]
L["Reposing Knight"] = "Reposing Knight"
--[[Translation missing --]]
L["Repurposed Loaderbot"] = "Repurposed Loaderbot"
L["Research Scribe"] = "Escriba de investigación"
L["Reset"] = "Reiniciar"
L["Reset %s?"] = "Reiniciar %s?"
L["Reset Preset"] = "Reiniciar Ruta"
L["Reset the preset to the default state"] = "Reiniciar la ruta al estado predeterminado"
--[[Translation missing --]]
L["Residual Hatred"] = "Residual Hatred"
--[[Translation missing --]]
L["Resin Flake"] = "Resin Flake"
L["Restless Tides"] = "Mareas inquietas"
--[[Translation missing --]]
L["Retired Lord Vul'azak"] = "Retired Lord Vul'azak"
L["Return to Karazhan Lower"] = "Regreso a Karazhan inferior"
L["Return to Karazhan Upper"] = "Regreso a Karazhan superior"
L["Return to the live preset"] = "Volver a ruta en directo"
L["Rezan"] = "Rezan"
L["Rift Warden"] = "Celador de falla"
L["Rigged Plagueborer"] = "Perforapeste preparado"
L["Right click a pull for more options."] = "Click derecho en un pull para más opciones."
L["Right click an enemy to open the enemy info window."] = "Click derecho en un enemigo para abrir la ventana de información del enemigo."
L["Right click for more info"] = "Click derecho para más información"
L["Right-click to lock Minimap Button"] = "Click derecho para bloquear el Botón del Minimapa"
L["Right-Click to reset NPC position"] = "Click derecho para reiniciar posición de PNJ"
L["Ring-Lord Conjurer"] = "Lord del anillo conjurador"
L["Ring-Lord Sorceress"] = "Hechicera del señor del anillo"
L["Riptide Shredder"] = "Triturador Mareaviva"
L["Rira Hackclaw"] = "Rira Cortagarra"
L["Risen Arcanist"] = "Arcanista resucitado"
L["Risen Archer"] = "Arquera resucitada"
L["Risen Bonesoldier"] = "Guerrero esquelético resucitado"
L["Risen Companion"] = "Compañero resucitado"
L["Risen Cultist"] = "Cultor renacido"
L["Risen Dragon"] = "Dragón resucitado"
L["Risen Drakkari Bat Rider"] = "Jinete de murciélagos Drakkari resucitado"
L["Risen Drakkari Death Knight"] = "Caballero de la Muerte Drakkari resucitado"
L["Risen Drakkari Handler"] = "Cuidador Drakkari resucitado"
L["Risen Drakkari Soulmage"] = "Mago de almas Drakkari resucitado"
L["Risen Drakkari Warrior"] = "Guerrero Drakkari resucitado"
--[[Translation missing --]]
L["Risen Footman"] = "Risen Footman"
--[[Translation missing --]]
L["Risen Guard"] = "Risen Guard"
L["Risen Lancer"] = "Lancero resucitado"
--[[Translation missing --]]
L["Risen Mage"] = "Risen Mage"
L["Risen Mystic"] = "Mística resucitada"
L["Risen Scout"] = "Explorador resucitado"
L["Risen Soul"] = "Alma resucitada"
L["Risen Squire"] = "Escudero resucitado"
L["Risen Swordsman"] = "Espadachín resucitado"
L["Risen Warlord"] = "Señor de la guerra resucitado"
L["Risen Warrior"] = "Guerrero resucitado"
--[[Translation missing --]]
L["Ritual of Bones"] = "Ritual of Bones"
L["Ritualist Lesha"] = "Ritualista Lesha"
L["Rixxa Fluxflame"] = "Rixxa Flujollama"
--[[Translation missing --]]
L["Rock Smasher"] = "Rock Smasher"
L["Rockback Gnasher"] = "Rechinador Rocalomo"
L["Rockback Snapper"] = "Sacudidor Rocalomo"
L["Rockbound Pelter"] = "Escoriador ligarroca"
L["Rockbound Sprite"] = "Duende ligarroca"
L["Rockbound Trapper"] = "Trampero ligarroca"
L["Rocket Tonk"] = "Tonque cohete"
L["Rockspine Stinger"] = "Aguijón Rocaspina"
L["Rokmora"] = "Rokmora"
L["Rook Spiderling"] = "Arañita del torreón"
L["Rook Spinner"] = "Hiladora del torreón"
--[[Translation missing --]]
L["rookeryShortname"] = "ROOK"
--[[Translation missing --]]
L["rookItemDescription"] = [=[After defeating |cFFFF0000Kyrioss|r loot |cFF00FF00Stormrook Feather|r 
Use it on a nearby |cFF00FF00Chained Stormrook|r to gain this buff for 5 minutes.]=]
L["Root"] = "Raíz"
L["Rotation"] = "Rotación"
--[[Translation missing --]]
L["Rotbow Ranger"] = "Rotbow Ranger"
L["Rotbow Stalker"] = "Acechador putriarco"
L["Rotfang Hyena"] = "Hiena colmillomugre"
L["Rotheart Dryad"] = "Dríade Corazón infecto"
L["Rotheart Keeper"] = "Vigilante Corazón Infecto"
L["Rotmarrow Slime"] = "Baba putremédula"
L["Rotspew"] = "Flemapútrida"
L["Rotspew Leftovers"] = "Restos de Flemapútrida"
L["Rotting Maggot"] = "Cresa en podredumbre"
L["Rotting Slimeclaw"] = "Garrababosa putrefacta"
L["Rowdy Reveler"] = "Juerguista pendenciera"
--[[Translation missing --]]
L["Royal Acolyte"] = "Royal Acolyte"
--[[Translation missing --]]
L["Royal Jelly Purveyor"] = "Royal Jelly Purveyor"
--[[Translation missing --]]
L["Royal Swarmguard"] = "Royal Swarmguard"
--[[Translation missing --]]
L["Royal Venomshell"] = "Royal Venomshell"
--[[Translation missing --]]
L["Royal Wicklighter"] = "Royal Wicklighter"
--[[Translation missing --]]
L["Ruby Overlook"] = "Ruby Overlook"
--[[Translation missing --]]
L["RubyLifePools"] = "Ruby Life Pools"
--[[Translation missing --]]
L["rubyLifePoolsShortName"] = "RLP"
L["Ruin's Descent"] = "Descenso de la Ruina"
L["Ruins Dweller"] = "Habitante de las ruinas"
L["Rune Etched Sentry"] = "Avizor con runas grabadas"
L["Rune Seal Keeper"] = "Guardiana del sello rúnico"
L["Runecarver Slave"] = "Esclavo grabador de runas"
L["Runecarver Sorn"] = "Grabador de runas Sorn"
L["Runemaster Molgeim"] = "Maestro de runas Molgeim"
L["Runestag Elderhorn"] = "Venado rúnico cuernoviejo"
L["Runic Disciple"] = "Discípula rúnica"
L["Runic Protector"] = "Protector rúnico"
--[[Translation missing --]]
L["Saboteur Kip'tilak"] = "Saboteur Kip'tilak"
L["Sacrificial Pits"] = "Fosa de Sacrificios"
L["Sacristy of Elune"] = "Dependencia de Elune"
L["Sadana Bloodfury"] = "Sadana Furia Sangrienta"
L["Safety Shark"] = "Tiburón de seguridad"
L["Salramm the Fleshcrafter"] = "Salramm el Modelador de carne"
L["Saltscale Lurker"] = "Rondador Escama de Sal"
L["Saltscale Skulker"] = "Vagador Escama de Sal"
L["Saltsea Droplet"] = "Gotita de agua salada"
L["Saltwater Snapper"] = "Sacudidor marino"
L["Samh'rek, Beckoner of Chaos"] = "Samh'rek, Invocador del Caos"
L["Sand-Crusted Striker"] = "Asediadora arenada"
L["Sandfury Stonefist"] = "Puñopiedra Furiarena"
L["Sandswept Marksman"] = "Tirador Arrasarenas"
L["Sanguine"] = "Sanguina"
L["Sanguine Cadet"] = "Cadete sanguino"
--[[Translation missing --]]
L["Sanguine Depths"] = "Sanguine Depths"
--[[Translation missing --]]
L["Sanguine DepthsFloor1"] = "Depths of Despair"
--[[Translation missing --]]
L["Sanguine DepthsFloor2"] = "Amphitheater of Sorrow"
--[[Translation missing --]]
L["sanguineDepthsShortName"] = "SD"
L["Sap"] = "Porrazo"
L["Sapped Voidlord"] = "Señor del Vacío debilitado"
L["Sapphiron"] = "Sapphiron"
L["Saprish"] = "Saprish"
L["Sathel the Accursed"] = "Sathel la Detestable"
L["Saurolisk Bonenipper"] = "Saurolisco roehuesos"
L["Savage Cave Beast"] = "Bestia salvaje de cueva"
L["Savage Worg"] = "Huargo salvaje"
--[[Translation missing --]]
L["Scaffolding"] = "Scaffolding"
L["Scalebane Lieutenant"] = "Teniente Azote Escamado"
L["Scaled Krolusk Rider"] = "Jinete de croluscos escamados"
L["Scaled Krolusk Tamer"] = "Domador de croluscos escamados"
--[[Translation missing --]]
L["Scare Beast"] = "Scare Beast"
--[[Translation missing --]]
L["Scarlet Cannoneer"] = "Scarlet Cannoneer"
--[[Translation missing --]]
L["Scarlet Centurion"] = "Scarlet Centurion"
--[[Translation missing --]]
L["Scarlet Defender"] = "Scarlet Defender"
--[[Translation missing --]]
L["Scarlet Evangelist"] = "Scarlet Evangelist"
--[[Translation missing --]]
L["Scarlet Evoker"] = "Scarlet Evoker"
--[[Translation missing --]]
L["Scarlet Fanatic"] = "Scarlet Fanatic"
--[[Translation missing --]]
L["Scarlet Flamethrower"] = "Scarlet Flamethrower"
--[[Translation missing --]]
L["Scarlet Hall Guardian"] = "Scarlet Hall Guardian"
--[[Translation missing --]]
L["Scarlet Halls"] = "Scarlet Halls"
--[[Translation missing --]]
L["Scarlet Initiate"] = "Scarlet Initiate"
--[[Translation missing --]]
L["Scarlet Judicator"] = "Scarlet Judicator"
--[[Translation missing --]]
L["Scarlet Monastery"] = "Scarlet Monastery"
--[[Translation missing --]]
L["Scarlet Myrmidon"] = "Scarlet Myrmidon"
--[[Translation missing --]]
L["Scarlet Pupil"] = "Scarlet Pupil"
--[[Translation missing --]]
L["Scarlet Purifier"] = "Scarlet Purifier"
--[[Translation missing --]]
L["Scarlet Scholar"] = "Scarlet Scholar"
--[[Translation missing --]]
L["Scarlet Scourge Hewer"] = "Scarlet Scourge Hewer"
--[[Translation missing --]]
L["Scarlet Treasurer"] = "Scarlet Treasurer"
--[[Translation missing --]]
L["Scarlet Zealot"] = "Scarlet Zealot"
--[[Translation missing --]]
L["scarletHallsShortName"] = "HALLS"
--[[Translation missing --]]
L["scarletMonasteryShortName"] = "SCARL"
L["Scavenging Leaper"] = "Saltador carroñero"
--[[Translation missing --]]
L["Scholomance"] = "Scholomance"
--[[Translation missing --]]
L["Scholomance Acolyte"] = "Scholomance Acolyte"
--[[Translation missing --]]
L["Scholomance Neophyte"] = "Scholomance Neophyte"
--[[Translation missing --]]
L["scholomanceShortName"] = "SCOLO"
L["Scorchling"] = "Agostizo"
L["Scourge Brute"] = "Tosco de la Plaga"
L["Scourge Hulk"] = "Mole de la Plaga"
L["Scourge Reanimator"] = "Reanimador de la Plaga"
--[[Translation missing --]]
L["Scrap Block"] = "Scrap Block"
L["Scrapbone Bully"] = "Abusón oseomorralla"
L["Scrapbone Grinder"] = "Moledor oseomorralla"
L["Scrapbone Grunter"] = "Gruñón oseomorralla"
L["Scrapbone Shaman"] = "Chamán oseomorralla"
L["Scrapbone Trashtosser"] = "Echabasura oseomorralla"
L["Scraphound"] = "Can de chatarra"
L["Scrimshaw Enforcer"] = "Déspota Tallamarfil"
L["Scrimshaw Gutter"] = "Matarife Tallamarfil"
L["Seacursed Mistmender"] = "Curanieblas maldecida por el mar"
L["Seacursed Slaver"] = "Esclavista maldecido por el mar"
L["Seacursed Soulkeeper"] = "Guardián de almas maldecido por el mar"
L["Seacursed Swiftblade"] = "Hoja presta maldecido por el mar"
L["Seasonal Affix:"] = "Afijo de temporada:"
L["Seaspray Crab"] = "Cangrejo de espuma marina"
--[[Translation missing --]]
L["Seat of the Archon"] = "Seat of the Archon"
L["Seat of the Triumvirate"] = "Trono del Triunvirato"
L["Seat of the Triumvirate Sublevel"] = "Subnivel de Trono del Triunvirato"
--[[Translation missing --]]
L["seatOfTheTriumvirateShortName"] = "SEAT"
--[[Translation missing --]]
L["Select all"] = "Select all"
L["Select the dungeon level"] = "Selecciona el nivel de mazmorra"
L["Sending: %.1f"] = "Enviando: %.1f"
L["Seneschal M'bara"] = "Senescal M'bara"
L["Sentient Oil"] = "Aceite sensible"
L["Sentinel Talondras"] = "Centinela Talondras"
--[[Translation missing --]]
L["Sentry Stagshell"] = "Sentry Stagshell"
L["Separation Assistant"] = "Asistente de separación"
L["Sergeant Bainbridge"] = "Sargento Bainbridge"
--[[Translation missing --]]
L["Sergeant Shaynemail"] = "Sergeant Shaynemail"
L["Serpentrix"] = "Serpentrix"
L["Servant of Asaad"] = "Sirviente de Asaad"
--[[Translation missing --]]
L["Set Target Marker"] = "Set Target Marker"
L["Settings"] = "Opciones"
L["Sewer Gate"] = "Puerta de alcantarilla"
L["Sewer Vicejaw"] = "Malafauce de cloaca"
L["Sha of Doubt"] = "Sha de la duda"
--[[Translation missing --]]
L["Sha of Violence"] = "Sha of Violence"
L["Shackle Undead"] = "Encadenar No-Muerto"
L["Shackled Soul"] = "Alma encadenada"
L["Shade of Medivh"] = "Sombra de Medivh"
L["Shade of Naxxramas"] = "Sombra de Naxxramas"
L["Shade of Xavius"] = "Sombra de Xavius"
--[[Translation missing --]]
L["Shado-Pan Ambusher"] = "Shado-Pan Ambusher"
--[[Translation missing --]]
L["Shado-Pan Disciple"] = "Shado-Pan Disciple"
--[[Translation missing --]]
L["Shado-Pan Monastery"] = "Shado-Pan Monastery"
--[[Translation missing --]]
L["Shado-Pan Stormbringer"] = "Shado-Pan Stormbringer"
--[[Translation missing --]]
L["Shado-Pan Warden"] = "Shado-Pan Warden"
--[[Translation missing --]]
L["shadoPanMonasteryShortName"] = "SHADO"
L["Shadow Hunter"] = "Cazadora de las Sombras"
L["Shadow Mistress"] = "Señora de las Sombras"
L["Shadow of Zul"] = "Sombra de Zul"
L["Shadow Stalker"] = "Acechador sombrío"
L["Shadowblade Stalker"] = "Acechador Hoja de las Sombras"
L["Shadow-Borne Champion"] = "Campeón Sombralóbrega"
L["Shadow-Borne Warrior"] = "Guerrero Sombralóbrega"
L["Shadow-Borne Witch Doctor"] = "Médico brujo Sombralóbrega"
L["Shadowguard Champion"] = "Campeón de la Guardia de las Sombras"
L["Shadowguard Conjurer"] = "Conjurador de la Guardia de las Sombras"
L["Shadowguard Riftstalker"] = "Acechador de falla de la Guardia de las Sombras"
L["Shadowguard Subjugator"] = "Subyugador de la Guardia de las Sombras"
L["Shadowguard Trickster"] = "Tramposo de la Guardia de las Sombras"
L["Shadowguard Voidbender"] = "Dominador del Vacío de la Guardia de las Sombras"
--[[Translation missing --]]
L["Shadowlands"] = "Shadowlands"
--[[Translation missing --]]
L["Shadowlands Season 4"] = "Shadowlands Season 4"
L["Shadowmoon Bone-Mender"] = "Ensalmadora de huesos Sombraluna"
L["Shadowmoon Dominator"] = "Dominador Sombraluna"
--[[Translation missing --]]
L["Shadowmoon Enslaver"] = "Shadowmoon Enslaver"
L["Shadowmoon Exhumer"] = "Exhumadora Sombraluna"
L["Shadowmoon Loyalist"] = "Leal Sombraluna"
--[[Translation missing --]]
L["ShadowmoonBurialGrounds"] = "Shadowmoon Burial Grounds"
--[[Translation missing --]]
L["shadowmoonShortName"] = "SBG"
L["Shady Dealer"] = "Vendedor sospechoso"
L["Shalebiter"] = "Muerdesquisto"
L["Shambling Arbalest"] = "Arbalestero renqueante"
L["Shambling Infester"] = "Infestador renqueante"
L["Shard of Halkias"] = "Fragmento de Halkias"
L["Share"] = "Compartir"
L["Share the preset with your party members"] = "Comparte la ruta con tus miembros del grupo"
L["Sha-Touched Guardian"] = "Guardián influenciado por el sha"
L["Shattered Visage"] = "Semblante destrozado"
L["Shieldbearer of Zul"] = "Portaescudos de Zul"
L["Shift-Click to delete all presets for this dungeon"] = "Shift-Click para eliminar todos las rutas de esta mazmorra"
--[[Translation missing --]]
L["Shikaar Ranger"] = "Shikaar Ranger"
L["Shiprat"] = "Rata de barco"
L["Shock Bot"] = "Robot de descargas"
L["Shortcut"] = "Atajo"
--[[Translation missing --]]
L["Shreddinator 3000"] = "Shreddinator 3000"
L["Shrieking Terror"] = "Terror chillón"
L["Shrieking Whelp"] = "Cría aullante"
L["Shrine of the Storm"] = "Altar de la Tormenta"
L["Shrine of the Storm Sublevel"] = "Subnivel de Altar de la Tormenta"
L["Shrine Templar"] = "Templario del santuario"
L["shrineGraveyardNote1"] = "Se desbloquea después de derrotar a Lord Canto Tormenta"
--[[Translation missing --]]
L["shrineOfTheStormsShortName"] = "SOTS"
L["Shroud Hound"] = "Can embozado"
--[[Translation missing --]]
L["Shrouded"] = "Shrouded"
L["Shrouded Fang"] = "Colmillo velado"
L["Shuffling Corpse"] = "Cadáver esquivo"
--[[Translation missing --]]
L["Shuffling Horror"] = "Shuffling Horror"
L["Siege of Boralus"] = "Asedio de Boralus"
L["Siege of Boralus (Upstairs)"] = "Asedio de Boralus (Piso de arriba)"
L["Siege of Boralus Sublevel"] = "Subnivel de Asedio de Boralus"
--[[Translation missing --]]
L["Siege of Niuzao Temple"] = "Siege of Niuzao Temple"
L["siegeDuplicateNote"] = "G39 puede ser duplicada si una mision del mundo está presente en el area"
L["siegeGraveyardNote1"] = "Se desbloquea después de derrotar a Sargento Empuente / Cortador Ganchorrojo"
L["siegeGraveyardNote2"] = "Se desbloquea después de derrotar a Capitana siniestra Lockwood"
L["siegeGraveyardNote3"] = "Se desbloquea después de derrotar a Hadal Brazasombría"
L["siegeGutterNote2"] = "G72 Los Destripadores pueden usarse para Fuerzas Enemigas marcandoles con daño y desencadenando la muerte instantánea de los lacayos junto a ellos"
L["siegeGuttersNote"] = "Nota en Destripadores:%sLos Lacayos mataran instantáneamente a los Destripadores cuando un jugador se acerque a ellos. Si mueren sin recibir daño del grupo, no darán fuerzas enemigas."
L["Siegemaster Olugar"] = "Maestro de asedio Olugar"
L["Siegemaster Rokra"] = "Maestro de asedio Rokra"
--[[Translation missing --]]
L["siegeOfBoralusShortName"] = "SIEGE"
--[[Translation missing --]]
L["siegeOfNiuzaoTempleShortName"] = "SIEGE"
--[[Translation missing --]]
L["Sik'thik Amber-Weaver"] = "Sik'thik Amber-Weaver"
--[[Translation missing --]]
L["Sik'thik Amberwing"] = "Sik'thik Amberwing"
--[[Translation missing --]]
L["Sik'thik Battle-Mender"] = "Sik'thik Battle-Mender"
--[[Translation missing --]]
L["Sik'thik Bladedancer"] = "Sik'thik Bladedancer"
--[[Translation missing --]]
L["Sik'thik Builder"] = "Sik'thik Builder"
--[[Translation missing --]]
L["Sik'thik Demolisher"] = "Sik'thik Demolisher"
--[[Translation missing --]]
L["Sik'thik Engineer"] = "Sik'thik Engineer"
--[[Translation missing --]]
L["Sik'thik Guardian"] = "Sik'thik Guardian"
--[[Translation missing --]]
L["Sik'thik Soldier"] = "Sik'thik Soldier"
--[[Translation missing --]]
L["Sik'thik Swarmer"] = "Sik'thik Swarmer"
--[[Translation missing --]]
L["Sik'thik Vanguard"] = "Sik'thik Vanguard"
--[[Translation missing --]]
L["Sik'thik Warden"] = "Sik'thik Warden"
--[[Translation missing --]]
L["Sik'thik Warrior"] = "Sik'thik Warrior"
L["Silence"] = "Silencio"
L["Silt Crab"] = "Cangrejo de cieno"
--[[Translation missing --]]
L["Sinstone Statue"] = "Sinstone Statue"
--[[Translation missing --]]
L["Sir Braunpyke"] = "Sir Braunpyke"
L["Sir Zeliek"] = "Sir Zeliek"
L["Sister Briar"] = "Hermana Brezo"
L["Sister Malady"] = "Hermana Enfermedad"
L["Sister Solena"] = "Hermana Solena"
L["Sjonnir The Ironshaper"] = "Sjonnir el Afilador"
L["Skadi the Ruthless"] = "Skadi el Despiadado"
--[[Translation missing --]]
L["Skardyn Monstrosity"] = "Skardyn Monstrosity"
--[[Translation missing --]]
L["Skarmorak"] = "Skarmorak"
L["Skarvald the Constructor"] = "Skarvald el Constructor"
L["Skeletal Hound"] = "Can esquelético"
L["Skeletal Hunting Raptor"] = "Raptor de caza esquelético"
L["Skeletal Marauder"] = "Maleante esquelético"
L["Skeletal Monstrosity"] = "Monstruosidad esquelética"
L["Skeletal Raptor"] = "Raptor esquelético"
L["Skeletal Smith"] = "Herrero esquelético"
L["Skeletal Usher"] = "Ujier esquelético"
L["Skeletal Waiter"] = "Camarero esquelético"
L["Skeletal Warrior"] = "Guerrero esquelético"
--[[Translation missing --]]
L["Skittering Assistant"] = "Skittering Assistant"
L["Skittering Crawler"] = "Reptador sigiloso"
--[[Translation missing --]]
L["Skittering Darkness"] = "Skittering Darkness"
L["Skittering Swarmer"] = "Enjambrista deslizante"
L["Skittish"] = "Inquieta"
L["Skjal"] = "Skjal"
L["Skrog Tidestomper"] = "Vapuleamareas skrog"
L["Skrog Wavecrasher"] = "Machacaolas skrog"
L["Skulking Gutstabber"] = "Trinchatripas merodeadora"
L["Skulking Zealot"] = "Zelote merodeador"
L["Skulloc"] = "Skulloc"
L["Skycap'n Kragg"] = "Capitán de los cielos Kragg"
L["Skyfall Star"] = "Estrella de Hundecielos"
L["Skylord Tovra"] = "Señora del cielo Tovra"
L["Slad'ran"] = "Slad'ran"
L["Slag"] = "Escoria"
--[[Translation missing --]]
L["Sleep Walk"] = "Sleep Walk"
--[[Translation missing --]]
L["Sleepy Hozen Brawler"] = "Sleepy Hozen Brawler"
L["Slime Elemental"] = "Elemental de babas"
L["Slime Tentacle"] = "Tentáculo de baba"
L["Slimy Morsel"] = "Bocado baboso"
L["Slithering Ooze"] = "Moco serpenteante"
L["Slow"] = "Lento"
--[[Translation missing --]]
L["Sludge"] = "Sludge"
L["Sludge Belcher"] = "Eructador de lodo"
L["Smashspite the Hateful"] = "Atizarrabias el Odioso"
--[[Translation missing --]]
L["Smuggled Creature"] = "Smuggled Creature"
L["Snarling Dockhound"] = "Can de muelle gruñidor"
--[[Translation missing --]]
L["So' Cartel Assassin"] = "So' Cartel Assassin"
L["So'azmi"] = "So'azmi"
--[[Translation missing --]]
L["Sodden Hozen Brawler"] = "Sodden Hozen Brawler"
L["Soggodon the Breaker"] = "Soggodon el Aniquilador"
L["Soggy Shiprat"] = "Rata de barco empapada"
L["So'leah"] = "So'leah"
L["Solsten"] = "Solsten"
L["Son of Hakkar"] = "Hijo de Hakkar"
--[[Translation missing --]]
L["Sootsnout"] = "Sootsnout"
L["Soul Essence"] = "Esencia de alma"
L["Soulbound Goliath"] = "Goliat de almas"
L["Soulforged Bonereaver"] = "Espetahuesos forjado con almas"
L["Soulharvester Duuren"] = "Cosechador de almas Duuren"
L["Soulharvester Galtmaa"] = "Cosechadora de almas Galtmaa"
L["Soulharvester Mandakh"] = "Cosechador de almas Mandakh"
L["Soulharvester Tumen"] = "Cosechadora de almas Tumen"
--[[Translation missing --]]
L["Soul-Scribe"] = "Soul-Scribe"
L["Soul-Torn Champion"] = "Campeón infausto"
L["Spare Parts"] = "Piezas de repuesto"
L["Spark Channeler"] = "Canalizador de chispas"
--[[Translation missing --]]
L["Speaker Brokk"] = "Speaker Brokk"
--[[Translation missing --]]
L["Speaker Dorlita"] = "Speaker Dorlita"
--[[Translation missing --]]
L["Speaker Shadowcrown"] = "Speaker Shadowcrown"
L["Spectral Apprentice"] = "Aprendiz espectral"
L["Spectral Attendant"] = "Auxiliar espectral"
L["Spectral Beastmaster"] = "Maestra de bestias espectral"
L["Spectral Berserker"] = "Rabiosa espectral"
L["Spectral Brute"] = "Bruto espectral"
L["Spectral Charger"] = "Destrero espectral"
L["Spectral Headhunter"] = "Rebanacabezas espectral"
L["Spectral Hex Priest"] = "Sacerdote de maleficio espectral"
L["Spectral Invoker"] = "Invocadora espectral"
L["Spectral Journeyman"] = "Oficial espectral"
L["Spectral Patron"] = "Parroquiano espectral"
L["Spectral Retainer"] = "Criado espectral"
L["Spectral Sentry"] = "Avizor espectral"
L["Spectral Stable Hand"] = "Mozo de establo espectral"
L["Spectral Valet"] = "Ayuda de cámara espectral"
L["Spectral Witch Doctor"] = "Médica bruja espectral"
L["Spellbound Battleaxe"] = "Hacha de batalla vinculada"
L["Spellbound Scepter"] = "Cetro vinculado"
L["Spider"] = "Araña"
L["Spider Tank"] = "Tanque araña"
L["Spinemaw Acidgullet"] = "Gargantácida faucespina"
L["Spinemaw Gorger"] = "Engullidor faucespina"
L["Spinemaw Larva"] = "Larva faucespina"
L["Spinemaw Reaver"] = "Atracador faucespina"
L["Spinemaw Staghorn"] = "Astado faucespina"
--[[Translation missing --]]
L["Spires of Ascension"] = "Spires of Ascension"
--[[Translation missing --]]
L["spiresOfAscensionShortName"] = "SOA"
L["Spirit of Vengeance"] = "Espíritu de venganza"
--[[Translation missing --]]
L["Spiteful"] = "Spiteful"
L["Spitting Cobra"] = "Cobra escupidora"
--[[Translation missing --]]
L["Splotch"] = "Splotch"
L["Sporecaller Zancha"] = "Clamaesporas Zancha"
L["Spriggan Barkbinder"] = "Vinculacortezas spriggan"
L["Spriggan Mendbender"] = "Dominaensalmos spriggan"
L["Spurlok, Timesworn Sentinel"] = "Spurlok, centinela vetusta"
L["Squallbringer Cyraz"] = "Portapesares Cyraz"
L["Stalagg"] = "Stalagg"
L["Start or join the current |cFF00FF00Live Session|r"] = "Empieza o únete a la |cFF00FF00Sesión en Directo|r actual"
--[[Translation missing --]]
L["Starved Crawler"] = "Starved Crawler"
--[[Translation missing --]]
L["Starving Hound"] = "Starving Hound"
L["Static-charged Dervish"] = "Místico cargado con electricidad estática"
L["Stealthling"] = "Sigilita"
L["Steelbreaker"] = "Rompeacero"
L["Steeljaw Grizzly"] = "Oso pardo Quijacero"
L["Steward"] = "Administrador"
L["Stinging Parasite"] = "Parásito hiriente"
L["Stinging Swarm"] = "Enjambre punzante"
L["Stinkbreath"] = "Tufoaliento"
L["Stitched Colossus"] = "Coloso cosido"
L["Stitched Giant"] = "Gigante cosido"
L["Stitched Vanguard"] = "Vanguardia cosida"
L["Stitchflesh's Creation"] = "Creación de Cosecarne"
L["Stitching Assistant"] = "Ayudante de costura"
--[[Translation missing --]]
L["stolenPowerDescription"] = "Usable by Rogues, Priests, and Khaz Algar Engineers (25)"
L["Stoneborn Eviscerator"] = "Evisceradora natopiedra"
L["Stoneborn Reaver"] = "Atracador natopiedra"
L["Stoneborn Slasher"] = "Mutilador natopiedra"
L["Stoneclaw Grubmaster"] = "Domalarvas Garrapétrea"
L["Stoneclaw Hunter"] = "Cazador Garrapétrea"
L["Stonefiend Anklebiter"] = "Muerdetobillos maligno de piedra"
L["Stonefury"] = "Rocafuria"
L["Stoneskin Gargoyle"] = "Gárgola piel de piedra"
L["Stonevault Geomancer"] = "Geomántico Grutacanto"
--[[Translation missing --]]
L["stoneVaultShortName"] = "SV"
L["Stonewall Gargon"] = "Gargon muropiedra"
L["Storm Drake"] = "Draco de tormenta"
L["Storm Tempered Keeper"] = "Vigilante de tormenta templado"
L["Storm Warrior"] = "Guerrero de la tormenta"
L["Stormcaller Arynga"] = "Clamatormentas Arynga"
L["Stormcaller Boroo"] = "Clamatormentas Boroo"
L["Stormcaller Brundir"] = "Clamatormentas Brundir"
L["Stormcaller Solongo"] = "Clamatormentas Solongo"
L["Stormcaller Zarii"] = "Clamatormentas Zarii"
--[[Translation missing --]]
L["Stormflurry Totem"] = "Stormflurry Totem"
L["Stormforged Construct"] = "Ensamblaje Tronaforjado"
L["Stormforged Giant"] = "Gigante Tronaforjado"
L["Stormforged Guardian"] = "Guardián Tronaforjado"
L["Stormforged Lieutenant"] = "Teniente Tronaforjado"
L["Stormforged Mender"] = "Ensalmador Tronaforjado"
L["Stormforged Runeshaper"] = "Creador de runas Tronaforjado"
L["Stormforged Sentinel"] = "Centinela Tronaforjado"
L["Stormforged Tactician"] = "Táctico Tronaforjado"
L["Stormfury Revenant"] = "Aparecido Furiatormenta"
--[[Translation missing --]]
L["Stormguard Gorren"] = "Stormguard Gorren"
--[[Translation missing --]]
L["Storming"] = "Storming"
L["Storming Vortex"] = "Vórtice tormentoso"
--[[Translation missing --]]
L["Stormrider Vokmar"] = "Stormrider Vokmar"
L["Storm's End"] = "Fin Tormentoso"
--[[Translation missing --]]
L["Stormstout Brewery"] = "Stormstout Brewery"
--[[Translation missing --]]
L["Stormstout Brewhall"] = "Stormstout Brewhall"
--[[Translation missing --]]
L["stormstoutBreweryShortName"] = "BREW"
L["Stormsurge Totem"] = "Tótem de oleada tormentosa"
L["Stormwake Hydra"] = "Hidra Levantatormentas"
--[[Translation missing --]]
L["Stout Brew Alemental"] = "Stout Brew Alemental"
L["Stranglevine Lasher"] = "Azotador de vid estranguladora"
--[[Translation missing --]]
L["Stratholme City"] = "Stratholme City"
--[[Translation missing --]]
L["streetBazaarEventNote1"] = "Bazaar Event first wave"
--[[Translation missing --]]
L["streetBazaarEventNote2"] = "Bazaar Event second wave"
--[[Translation missing --]]
L["streetBazaarEventNote3"] = "Bazaar Event third wave"
--[[Translation missing --]]
L["streetOasisBossNote1"] = "Myza's Oasis first wave"
--[[Translation missing --]]
L["streetOasisBossNote2"] = "Myza's Oasis second wave"
L["Strider Tonk"] = "Tonque zancudo"
L["Strife"] = "Discordia"
--[[Translation missing --]]
L["Striker Ga'dok"] = "Striker Ga'dok"
L["Stun"] = "Aturdir"
L["Subjugated Soul"] = "Alma subyugada"
--[[Translation missing --]]
L["Subterranean Proto-Dragon"] = "Subterranean Proto-Dragon"
--[[Translation missing --]]
L["Sudsy Brew Alemental"] = "Sudsy Brew Alemental"
L["Sunken Denizen"] = "Morador hundido"
--[[Translation missing --]]
L["Support MDT on Patreon"] = "Support MDT on Patreon"
L["Support Officer"] = "Oficial de apoyo"
--[[Translation missing --]]
L["Sureki Conscript"] = "Sureki Conscript"
--[[Translation missing --]]
L["Sureki Militant"] = "Sureki Militant"
--[[Translation missing --]]
L["Sureki Silkbinder"] = "Sureki Silkbinder"
--[[Translation missing --]]
L["Sureki Unnaturaler"] = "Sureki Unnaturaler"
--[[Translation missing --]]
L["Sureki Venomblade"] = "Sureki Venomblade"
--[[Translation missing --]]
L["Sureki Webmage"] = "Sureki Webmage"
L["Surgeon Stitchflesh"] = "Cirujano Cosecarne"
L["Surgical Assistant"] = "Auxiliar quirúrgico"
L["Svala Sorrowgrave"] = "Svala Tumbapena"
--[[Translation missing --]]
L["Swampface"] = "Swampface"
--[[Translation missing --]]
L["Taah'bat"] = "Taah'bat"
--[[Translation missing --]]
L["Taener Duelmal"] = "Taener Duelmal"
L["Tainted Sentry"] = "Avizor corrupto"
L["Taintheart Deadeye"] = "Mortojo Corazón Ruin"
L["Taintheart Stalker"] = "Acechador Corazón Ruin"
L["Taintheart Summoner"] = "Invocador Corazón Ruin"
L["Talixae Flamewreath"] = "Talixae Corona de Fuego"
L["Tamed Phoenix"] = "Fénix domesticado"
--[[Translation missing --]]
L["Tamed Ruinstalker"] = "Tamed Ruinstalker"
L["Tank Buster MK1"] = "Tronchatanques MK1"
--[[Translation missing --]]
L["Taran Zhu"] = "Taran Zhu"
--[[Translation missing --]]
L["Tarasek Delver"] = "Tarasek Delver"
L["Tarspitter Lurker"] = "Rondador Escupebrea"
L["Tarspitter Slug"] = "Oruga Escupebrea"
L["Taskmaster Askari"] = "Capataz Askari"
--[[Translation missing --]]
L["Taste Tester"] = "Taste Tester"
--[[Translation missing --]]
L["Tasting Room Attendant"] = "Tasting Room Attendant"
L["Taunt"] = "Provocar"
--[[Translation missing --]]
L["TazaveshFloor1"] = "The Veiled Market"
--[[Translation missing --]]
L["TazaveshFloor2"] = "The Grand Menagerie"
--[[Translation missing --]]
L["TazaveshFloor3"] = "The P.O.S.T."
--[[Translation missing --]]
L["TazaveshFloor4"] = "Myza's Oasis"
--[[Translation missing --]]
L["TazaveshFloor5"] = "Stormheim"
--[[Translation missing --]]
L["TazaveshFloor6"] = "Aggramar's Vault"
--[[Translation missing --]]
L["TazaveshFloor7"] = "Boralus Harbor"
--[[Translation missing --]]
L["TazaveshFloor8"] = "The Opulent Nexus"
--[[Translation missing --]]
L["TazaveshLower"] = "Tazavesh: Streets of Wonder"
--[[Translation missing --]]
L["tazaveshLowerShortName"] = "STRT"
--[[Translation missing --]]
L["TazaveshUpper"] = "Tazavesh: So'leah's Gambit"
--[[Translation missing --]]
L["tazaveshUpperShortName"] = "GMBT"
L["tdBuffGateNote"] = "Probablidad de contener un aliado el cual te puede dar un beneficio dependiendo de su raza:%sOrco/Enano: 10%% Fuerza/Agilidad%sNo-Muerto/Humano: 10%% Aguante%sTauren/Draenei: 1%% Vida+Maná por cada 10s%sElfo de la Sangre/Gnomo: 10%% Intelecto"
L["tdGraveyardNote1"] = "Se desbloquea después de derrotar a Reina de las arenas"
L["tdGraveyardNote2"] = "Se desbloquea después de derrotar a Jes Howlis"
L["tdGraveyardNote3"] = "Se desbloquea después de derrotar a Capitana Caballero Valyri"
L["tdHowlisNote"] = "Jes Howlis abrirá esta celda y los enemigos tendrán amenaza dentro de ella"
L["TDPrisonKeyText"] = "Llave de celda descartada%Posible ubicación de aparecer%sAbre 1x Barras de la prisión"
L["tdWardenFightingNote"] = "G23 está luchando y eventualmente eliminará Celador del bloque"
L["Teeming"] = "Bullente"
L["Teera"] = "Teera"
L["Telash Greywing"] = "Telash Alagrís"
L["Tempest Channeler"] = "Canalizadora de la tempestad"
L["Temple Adept"] = "Adepto del templo"
L["Temple Attendant"] = "Auxiliar del templo"
L["Temple of Sethraliss"] = "Templo de Sethraliss"
L["Temple of Sethraliss Sublevel"] = "Subnivel de Templo de Sethraliss"
--[[Translation missing --]]
L["Temple of the Jade Serpent"] = "Temple of the Jade Serpent"
L["templeEyeNote"] = "Ojo de Sethraliss%sLleva los dos Ojos a la Calavera de Sethraliss%sCada Ojo que lleves a la Calavera da 12 fuerzas enemigas"
L["templeGraveyardNote1"] = "Se desbloquea despues de derrotar a Merektha"
L["templeGraveyardNote2"] = "Se desbloquea despues de derrotar al evento de Calavera de Sethraliss"
--[[Translation missing --]]
L["templeOfSethralisShortName"] = "TOS"
--[[Translation missing --]]
L["TempleOfTheJadeSerpent"] = "Temple of the Jade Serpent"
--[[Translation missing --]]
L["templeOfTheJadeSerpentShortName"] = "JADE"
L["Temporal Deviation"] = "Divergencia temporal"
L["Temporal Fusion"] = "Fusión temporal"
--[[Translation missing --]]
L["Terrified Broker"] = "Terrified Broker"
L["Territorial Bladebeak"] = "Picoespada territorial"
L["Territorial Eagle"] = "Águila territorial"
L["Test Subject"] = "Sujeto de pruebas"
L["Thaddius"] = "Thaddius"
--[[Translation missing --]]
L["Thalnos the Soulrender"] = "Thalnos the Soulrender"
L["Thane Korth'azz"] = "Señor feudal Korth'azz"
--[[Translation missing --]]
L["The Antechamber of Ulduar"] = "The Antechamber of Ulduar"
--[[Translation missing --]]
L["The Arachnid Quarter"] = "The Arachnid Quarter"
L["The Arcway"] = "La Arquería"
L["The Arcway Sublevel"] = "Subnivel de La Arquería"
L["The Balconies"] = "Los Balcones"
L["The Banquet Hall"] = "La Sala de Banquetes"
L["The Brig"] = "Calabozo"
--[[Translation missing --]]
L["The Brood Pit"] = "The Brood Pit"
--[[Translation missing --]]
L["The Burning Cauldron"] = "The Burning Cauldron"
--[[Translation missing --]]
L["The Candle King"] = "The Candle King"
L["The Cellar"] = "Bodega"
--[[Translation missing --]]
L["The Coaglamation"] = "The Coaglamation"
--[[Translation missing --]]
L["The Construct Quarter"] = "The Construct Quarter"
--[[Translation missing --]]
L["The Crimson Assembly Hall"] = "The Crimson Assembly Hall"
L["The Crybaby Hozen"] = "El Hozen Llorica"
--[[Translation missing --]]
L["The Culling of Stratholme"] = "The Culling of Stratholme"
L["The Curator"] = "Curator"
--[[Translation missing --]]
L["The Darkness"] = "The Darkness"
--[[Translation missing --]]
L["The Dawnbreaker"] = "The Dawnbreaker"
L["The Drain"] = "El Sumidero"
L["The Emerald Archives"] = "Archivos Esmeralda"
--[[Translation missing --]]
L["The Everbloom"] = "The Everbloom"
--[[Translation missing --]]
L["The Festering Sanctum"] = "The Festering Sanctum"
--[[Translation missing --]]
L["The Gilded Gate"] = "The Gilded Gate"
L["The Golden Beetle"] = "El Alfazaque Dorado"
L["The Golden Serpent"] = "Serpiente dorada"
L["The Grand Foyer"] = "Gran Recibidor"
L["The Grand Hall"] = "El Gran Salón"
--[[Translation missing --]]
L["The Great Wheel"] = "The Great Wheel"
L["The Grimewalker"] = "El Caminante de la Mugre"
L["The Guest Chambers"] = "Los Aposentos de los Invitados"
L["The High Gate"] = "La Puerta Insigne"
L["The Hold"] = "El Bastión"
--[[Translation missing --]]
L["The Inner Sanctum of Ulduar"] = "The Inner Sanctum of Ulduar"
L["The Jeweled Estate"] = "Hacienda Enjoyada"
--[[Translation missing --]]
L["The Lower Necropolis"] = "The Lower Necropolis"
L["The Menagerie"] = "Animalario"
--[[Translation missing --]]
L["The Military Quarter"] = "The Military Quarter"
--[[Translation missing --]]
L["The Mind's Eye"] = "The Mind's Eye"
L["The MOTHERLODE!!"] = "Veta Madre"
L["The MOTHERLODE!! Sublevel"] = "Subnivel Veta Madre"
L["The Naglfar"] = "Naglfar"
--[[Translation missing --]]
L["The Necrotic Wake"] = "The Necrotic Wake"
--[[Translation missing --]]
L["The Nexus"] = "The Nexus"
L["The Nodding Tiger"] = "El Tigre Asertivo"
--[[Translation missing --]]
L["The Oculus"] = "The Oculus"
--[[Translation missing --]]
L["The Plague Quarter"] = "The Plague Quarter"
L["The Platinum Pummeler"] = "Repartetundas de platino"
L["The preset will continuously synchronize between all party members participating in the Live Session"] = "La ruta se sincronizará continuamente entre todos los miembros del grupo que participan en la Sesión en vivo"
--[[Translation missing --]]
L["The Prison of Yogg-Saron"] = "The Prison of Yogg-Saron"
L["The Prophet Tharon'ja"] = "El profeta Tharon'ja"
L["The Raging Tempest"] = "La Tempestad Enfurecida"
L["The Raven's Crown"] = "Corona del Cuervo"
L["The Ravenscrypt"] = "Cripta de los Cuervos"
--[[Translation missing --]]
L["The Reliquary"] = "The Reliquary"
L["The Robodrome"] = "El Robódromo"
--[[Translation missing --]]
L["The Rookery"] = "The Rookery"
L["The Rook's Host"] = "Nido del Grajo"
L["The Rupture"] = "Ruptura"
L["The Sand Queen"] = "Reina de las arenas"
L["The selected affixes are not the ones of the current week"] = "Los afijos seleccionados no son los de la semana actual"
L["The selected dungeon level is below 10"] = "La mazmorra seleccionada es inferior al nivel 10"
L["The selected level will affect displayed npc health"] = "El nivel seleccionado afectará a la salud del PNJ mostrada"
L["The Servant's Quarters"] = "Alcobas de los Sirvientes"
L["The Songbird Queen"] = "La Reina Cantora"
--[[Translation missing --]]
L["The Spark of Imagination"] = "The Spark of Imagination"
--[[Translation missing --]]
L["The Stonevault"] = "The Stonevault"
L["The Talking Fish"] = "El Pez Parlante"
--[[Translation missing --]]
L["The Tasting Room"] = "The Tasting Room"
L["The Under Junk"] = "Sotocachivache"
L["The Underrot"] = "Catacumbas Putrefactas"
L["The Underrot Sublevel"] = "Subnivel de Catacumbas Putrefactas"
--[[Translation missing --]]
L["The Upper Necropolis"] = "The Upper Necropolis"
--[[Translation missing --]]
L["The Upper Study"] = "The Upper Study"
--[[Translation missing --]]
L["The Vault of Tyr"] = "The Vault of Tyr"
--[[Translation missing --]]
L["The Vestibules of Drak'Tharon"] = "The Vestibules of Drak'Tharon"
--[[Translation missing --]]
L["The Violet Hold"] = "The Violet Hold"
--[[Translation missing --]]
L["The Vortex Pinnacle"] = "The Vortex Pinnacle"
--[[Translation missing --]]
L["The War Within Season 1"] = "War Within Season 1"
--[[Translation missing --]]
L["The War Within Season 2"] = "War Within Season 2"
--[[Translation missing --]]
L["The War Within Season 3"] = "War Within Season 3"
L["The Warden's Court"] = "Corte de la Celadora"
--[[Translation missing --]]
L["TheArcaneConservatory"] = "The Arcane Conservatory"
--[[Translation missing --]]
L["Theater of Pain"] = "Theater of Pain"
--[[Translation missing --]]
L["theaterOfPain_miniBossNote"] = "Only one duelist will be alive."
--[[Translation missing --]]
L["TheaterOfPainFloor1"] = "Theater of Pain"
--[[Translation missing --]]
L["TheaterOfPainFloor2"] = "Chamber of Conquest"
--[[Translation missing --]]
L["TheaterOfPainFloor3"] = "Altars of Agony"
--[[Translation missing --]]
L["TheaterOfPainFloor4"] = "Upper Barrow of Carnage"
--[[Translation missing --]]
L["TheaterOfPainFloor5"] = "Lower Barrow of Carnage"
--[[Translation missing --]]
L["theaterOfPainShortName"] = "TOP"
--[[Translation missing --]]
L["TheAzureVault"] = "The Azure Vault"
--[[Translation missing --]]
L["TheBurningCauldron"] = "The Burning Cauldron"
--[[Translation missing --]]
L["TheHeadteachersEnclave"] = "The Headteacher's Enclave"
--[[Translation missing --]]
L["TheNecroticWakeFloor1"] = "The Necrotic Wake"
--[[Translation missing --]]
L["TheNecroticWakeFloor2"] = "Stitchwerks"
--[[Translation missing --]]
L["TheNecroticWakeFloor3"] = "Zolramus"
--[[Translation missing --]]
L["TheNokhudOffensive"] = "The Nokhud Offensive"
--[[Translation missing --]]
L["ThePitch"] = "The Pitch"
--[[Translation missing --]]
L["TheScrollkeepersSanctum"] = "The Scrollkeeper's Sanctum"
--[[Translation missing --]]
L["TheVaultOfTyr"] = "The Vault of Tyr"
L["Thistle Acolyte"] = "Acólita de cardo"
L["Thorim"] = "Thorim"
L["Thornguard"] = "Guardaspina"
L["Thrashbite the Scornful"] = "Tollinador el Desdeñoso"
--[[Translation missing --]]
L["Throne of Ancient Conquerors"] = "Throne of Ancient Conquerors"
--[[Translation missing --]]
L["Throne of Tides"] = "Throne of Tides"
--[[Translation missing --]]
L["throneOfTidesShortName"] = "TOTT"
L["Thunderhead"] = "Tronatesta"
--[[Translation missing --]]
L["Thundering"] = "Thundering"
L["Thunderlord Wrangler"] = "Retador Señor del Trueno"
--[[Translation missing --]]
L["Ticking Time Bomb"] = "Ticking Time Bomb"
L["Tidesage Enforcer"] = "Déspota Sabiomar"
L["Tidesage Initiate"] = "Iniciado Sabiomar"
L["Tidesage Spiritualist"] = "Espiritualista Sabiomar"
L["Timecap'n Hooktail"] = "Cronocapitana Colagarfio"
L["Time-Displaced Trooper"] = "Soldado desplazado en el tiempo"
L["Timeline Marauder"] = "Maleante temporal"
L["Time-Lost Aerobot"] = "Aerobot perdido en el tiempo"
L["Time-Lost Rocketeer"] = "Artificiero perdido en el tiempo"
L["Time-Lost Smack-o-Tron"] = "Bofetrón perdido en el tiempo"
L["Time-Lost Tidehunter"] = "Cazamareas perdido en el tiempo"
L["Time-Lost Wakethrasher"] = "Destrozaolas perdido en el tiempo"
L["Time-Lost Waveshaper"] = "Moldeaolas perdido en el tiempo"
--[[Translation missing --]]
L["Timer"] = "Timer"
L["Timestream Anomaly"] = "Anomalía de la línea temporal"
L["Timestream Leech"] = "Parásito de la línea temporal"
L["Tirathon Saltheril"] = "Tirathon Saltheril"
L["Tirnenn Villager"] = "Aldeana tirnenn"
--[[Translation missing --]]
L["Titanic Defense Turret"] = "Titanic Defense Turret"
L["Titanium Siegebreaker"] = "Rompedor del asedio de titanio"
L["Titanium Thunderer"] = "Tronador de titanio"
L["Titanium Vanguard"] = "Vanguardia de titanio"
L["T'lonja"] = "T'lonja"
L["To share a different preset while the live session is active simply navigate to the preferred preset and click the new 'Set to Live' Button next to the preset-dropdown"] = "Para compartir una ruta diferente mientras la Sesión en vivo está activa, simplemente navegé a la ruta preferida y haga click en el nuevo botón 'Establecer en Directo' junto al menú desplegable de rutas"
L["tocNotes"] = "Herramienta para planificar y optimizar las rutas de mazmorras de Piedras Angulares"
--[[Translation missing --]]
L["togc"] = "Trial of the Grand Crusader"
--[[Translation missing --]]
L["togcFloor1"] = "The Argent Coliseum"
--[[Translation missing --]]
L["togcFloor2"] = "The Icy Depths"
--[[Translation missing --]]
L["Toggle MDT"] = "Toggle MDT"
L["Toggle Window"] = "Activar Ventana"
L["Toiling Groundskeeper"] = "Guardés esforzado"
L["Tol Dagor"] = "Tol Dagor"
L["Tol Dagor Sublevel1"] = "Subnivel de Tol Dagor"
--[[Translation missing --]]
L["tolDagorShortName"] = "TD"
L["Tomb Horror"] = "Horror de tumbas"
L["Tomb Stalker"] = "Acechador de tumbas"
--[[Translation missing --]]
L["Torchsnarl"] = "Torchsnarl"
L["Tormented Bloodseeker"] = "Buscasangre atormentado"
L["Tormented Soul"] = "Alma atormentada"
L["Total"] = "Total"
--[[Translation missing --]]
L["Totem"] = "Totem"
L["Toxic Lurker"] = "Rondador tóxico"
L["Toxic Monstrosity"] = "Monstruosidad tóxica"
L["Toxic Saurid"] = "Sáurido tóxico"
L["Tracker Zo'korss"] = "Rastreador Zo'korss"
--[[Translation missing --]]
L["Train Depot"] = "Train Depot"
--[[Translation missing --]]
L["Training Grounds"] = "Training Grounds"
L["Trash"] = "Basura"
L["Tred'ova"] = "Tred'ova"
L["Treemouth"] = "Bocaárbol"
L["Tribunal of the Ages"] = "Tribunal de las Eras"
L["Trickclaw Mystic"] = "Mística zarpatruco"
L["Tricktotem"] = "Trucotótem"
--[[Translation missing --]]
L["Trilling Attendant"] = "Trilling Attendant"
L["Trixie Tazer"] = "Trixie Descarga"
L["Trollgore"] = "Cuernotrol"
L["Trothak"] = "Trothak"
L["Troubled Soul"] = "Alma atribulada"
L["Tunneling Ghoul"] = "Necrófago tunelador"
L["Turbulent Squall"] = "Borrasca turbulenta"
--[[Translation missing --]]
L["Turn Evil"] = "Turn Evil"
--[[Translation missing --]]
L["Turned Speaker"] = "Turned Speaker"
L["Twilight Adherent"] = "Partidario Crepuscular"
L["Twilight Apostle"] = "Apóstol Crepuscular"
--[[Translation missing --]]
L["Twilight Beguiler"] = "Twilight Beguiler"
--[[Translation missing --]]
L["Twilight Brute"] = "Twilight Brute"
L["Twilight Darkcaster"] = "Taumaturgo oscuro Crepuscular"
--[[Translation missing --]]
L["Twilight Destroyer"] = "Twilight Destroyer"
--[[Translation missing --]]
L["Twilight Earthcaller"] = "Twilight Earthcaller"
--[[Translation missing --]]
L["Twilight Enforcer"] = "Twilight Enforcer"
--[[Translation missing --]]
L["Twilight Flamerender"] = "Twilight Flamerender"
L["Twilight Frost Mage"] = "Mago de escarcha Crepuscular"
L["Twilight Grove"] = "Arboleda del Crepúsculo"
L["Twilight Guardian"] = "Guardián Crepuscular"
L["Twilight Initiate"] = "Iniciado Crepuscular"
--[[Translation missing --]]
L["Twilight Lavabender"] = "Twilight Lavabender"
--[[Translation missing --]]
L["Twilight Overseer"] = "Twilight Overseer"
L["Twilight Pyromancer"] = "Piromántico Crepuscular"
L["Twilight Shadowblade"] = "Hoja de las Sombras Crepuscular"
L["Twilight Slayer"] = "Destripador Crepuscular"
--[[Translation missing --]]
L["Twilight Warlock"] = "Twilight Warlock"
L["Twilight Worshipper"] = "Venerador Crepuscular"
L["Twisted Abomination"] = "Abominación retorcida"
L["Tyr, the Infinite Keeper"] = "Tyr, el Guardián Infinito"
L["Tyrannical"] = "Tiránica"
--[[Translation missing --]]
L["Tyr's Terrace"] = "Tyr's Terrace"
L["Tyr's Vanguard"] = "Vanguardia de Tyr"
L["Ukhel Beastcaller"] = "Clamabestias Ukhel"
L["Ukhel Corruptor"] = "Corruptor Ukhel"
L["Ukhel Deathspeaker"] = "Portavoz de la muerte Ukhel"
--[[Translation missing --]]
L["Ukhel Willcrusher"] = "Ukhel Willcrusher"
L["Ularogg Cragshaper"] = "Ularogg Formarriscos"
--[[Translation missing --]]
L["Uldaman: Legacy of Tyr"] = "Uldaman: Legacy of Tyr"
--[[Translation missing --]]
L["UldamanLegacyOfTyr"] = "Uldaman: Legacy of Tyr"
--[[Translation missing --]]
L["uldamanShortName"] = "ULD"
--[[Translation missing --]]
L["Ulduar"] = "Ulduar"
L["Umbral War-Adept"] = "Adepto de guerra umbrío"
L["Umbrelskul"] = "Umbracráneo"
L["Unbound Abomination"] = "Abominación desatada"
--[[Translation missing --]]
L["Unbound Ethereal"] = "Unbound Ethereal"
L["Unbound Firestorm"] = "Tormenta de Fuego desatada"
--[[Translation missing --]]
L["Uncategorized"] = "Uncategorized"
L["Undead"] = "No muerto"
--[[Translation missing --]]
L["Undercrawler"] = "Undercrawler"
L["Underrot Tick"] = "Garrapata de las Catacumbas Putrefactas"
L["underrotMatronNote"] = "Matriarca 4+5 puede aparecer en la plataforma izquierda o derecha"
--[[Translation missing --]]
L["underrotShortName"] = "UR"
L["underrotSkipNote"] = "Atajo%sSe desbloquea despues de matar a Clamaesporas Zancha"
L["underrotVoidNote"] = "Apariciones de Emisario Tocado del vacio 2 y 3 son aleatorios.%s Solo uno de ellos sera presente a la vez."
L["Understone Demolisher"] = "Demoledor Sotopiedra"
L["Understone Drudge"] = "Bracero Sotopiedra"
L["Understone Drummer"] = "Tamborilero Sotopiedra"
L["Undo"] = "Deshacer"
--[[Translation missing --]]
L["undoDrawing"] = "Undo Drawing"
L["Undying Servant"] = "Sirviente imperecedero"
L["Undying Stonefiend"] = "Maligno de piedra imperecedero"
L["Unholy Axe"] = "Hacha profana"
L["Unholy Staff"] = "Bastón profano"
L["Unholy Swords"] = "Espadas profanas"
--[[Translation missing --]]
L["Unknown"] = "Unknown"
L["Unrelenting Construct"] = "Ensamblaje inflexible"
L["Unruly Ogron"] = "Ogron indisciplinado"
--[[Translation missing --]]
L["Unruly Patron"] = "Unruly Patron"
--[[Translation missing --]]
L["Unruly Stormrook"] = "Unruly Stormrook"
L["Unruly Textbook"] = "Libro de texto indisciplinado"
L["Unstable Amalgamation"] = "Amalgama inestable"
L["Unstable Canister"] = "Bote inestable"
L["Unstable Corruption"] = "Corrupción inestable"
L["Unstable Curator"] = "Conservador inestable"
--[[Translation missing --]]
L["Unstable Darkness"] = "Unstable Darkness"
L["Unstable Larva"] = "Larva inestable"
L["Unstable Squall"] = "Borrasca inestable"
--[[Translation missing --]]
L["Unstable Test Subject"] = "Unstable Test Subject"
L["Unyielding Constrictor"] = "Constrictor implacable"
L["Unyielding Contender"] = "Contendiente implacable"
--[[Translation missing --]]
L["Unyielding Garrison"] = "Unyielding Garrison"
L["Update"] = "Actualizar"
--[[Translation missing --]]
L["updateNote"] = "Please update this AddOn to the latest version or remove it"
L["Upper Broken Stair"] = "La Escalera Quebrada Superior"
L["Upper Library"] = "La Biblioteca Superior"
L["Upper Livery Stables"] = "Caballerizas Superiores"
--[[Translation missing --]]
L["Upper Pinnacle"] = "Upper Pinnacle"
--[[Translation missing --]]
L["UpperChamber"] = "Upper Chamber"
L["Upstairs"] = "Piso de arriba"
L["Urg'roth, Breaker of Heroes"] = "Urg'roth, Quebrador de Héroes"
L["Urh Relic"] = "Reliquia Urh"
L["Use /mdt reset to restore the default position and scale of MDT."] = "Haga '/mdt reset' para restaurar la posición y escala predeterminadas de MDT."
L["Use as a starting point:"] = "Usar como punto de referencia:"
--[[Translation missing --]]
L["Use forces count"] = "Use forces count in Sidebar"
--[[Translation missing --]]
L["Utgarde Keep"] = "Utgarde Keep"
--[[Translation missing --]]
L["Utgarde Pinnacle"] = "Utgarde Pinnacle"
L["Valarjar Aspirant"] = "Aspirante Valarjar"
L["Valarjar Champion"] = "Campeón Valarjar"
L["Valarjar Falconer"] = "Halconera Valarjar"
L["Valarjar Marksman"] = "Tiradora Valarjar"
L["Valarjar Mystic"] = "Místico Valarjar"
L["Valarjar Purifier"] = "Purificador Valarjar"
L["Valarjar Runecarver"] = "Grabador de runas Valarjar"
L["Valarjar Shieldmaiden"] = "Doncella escudera Valarjar"
L["Valarjar Thundercaller"] = "Clamatruenos Valarjar"
L["Valarjar Trapper"] = "Trampero Valarjar"
--[[Translation missing --]]
L["Valiona"] = "Valiona"
L["Valow, Timesworn Keeper"] = "Valow, vigilante vetusto"
L["Varos Cloudstrider"] = "Varos Zancanubes"
L["Vault Guard"] = "Guardia de cámara"
L["Vault of the Betrayer"] = "Cámara de los Traidores"
L["Vault of the Wardens"] = "Cámara de las Celadoras"
L["Vault of the Wardens Sublevel"] = "Subnivel de Cámara de las Celadoras"
--[[Translation missing --]]
L["Vault Purifier"] = "Vault Purifier"
--[[Translation missing --]]
L["vaultOfTheWardensShortName"] = "VOTW"
--[[Translation missing --]]
L["Vaults of Kings Past"] = "Vaults of Kings Past"
L["Venom Stalker"] = "Acechador venenoso"
L["Venomfang"] = "Colmillo de veneno"
L["Venomous Ophidian"] = "Ofidio venenoso"
L["Venomous Sniper"] = "Francotirador venenoso"
L["Venomous Sniper Captain"] = "Capitán francotirador venenoso"
--[[Translation missing --]]
L["Vent Stalker"] = "Vent Stalker"
L["Ventunax"] = "Ventunax"
L["Venture Co. Alchemist"] = "Alquimista de Ventura y Cía."
--[[Translation missing --]]
L["Venture Co. Architect"] = "Venture Co. Architect"
--[[Translation missing --]]
L["Venture Co. Contractor"] = "Venture Co. Contractor"
--[[Translation missing --]]
L["Venture Co. Diver"] = "Venture Co. Diver"
L["Venture Co. Earthshaper"] = "Modelador de tierra de Ventura y Cía."
--[[Translation missing --]]
L["Venture Co. Electrician"] = "Venture Co. Electrician"
--[[Translation missing --]]
L["Venture Co. Honey Harvester"] = "Venture Co. Honey Harvester"
L["Venture Co. Longshoreman"] = "Estibador de Ventura y Cía."
L["Venture Co. Mastermind"] = "Cerebro de Ventura y Cía."
--[[Translation missing --]]
L["Venture Co. Patron"] = "Venture Co. Patron"
--[[Translation missing --]]
L["Venture Co. Pyromaniac"] = "Venture Co. Pyromaniac"
L["Venture Co. Skyscorcher"] = "Calcinacielos de Ventura y Cía."
--[[Translation missing --]]
L["Venture Co. Surveyor"] = "Venture Co. Surveyor"
L["Venture Co. War Machine"] = "Máquina de guerra de Ventura y Cía."
L["Venza Goldfuse"] = "Venza Fundioro"
L["Vermin Trapper"] = "Trampero de alimañas"
L["Vestige of Doubt"] = "Vestigio de duda"
--[[Translation missing --]]
L["Vestige of Hatred"] = "Vestige of Hatred"
L["Veteran Sparkcaster"] = "Chispaturgo veterano"
L["Vexamus"] = "Vexamus"
L["Viceroy Nezhar"] = "Virrey Nezhar"
L["Vicious Basilisk"] = "Basilisco sañoso"
L["Vicious Gargon"] = "Gargon sañoso"
L["Vicious Hyena"] = "Hiena sañosa"
L["Vicious Manafang"] = "Colmillo de maná sañoso"
L["Vicious Mandragora"] = "Mandrágora sañosa"
--[[Translation missing --]]
L["Vicious Snap Dragon"] = "Vicious Snap Dragon"
--[[Translation missing --]]
L["Vigilant Duskwatch"] = "Vigilant Duskwatch"
--[[Translation missing --]]
L["Vigilant Watchman"] = "Vigilant Watchman"
L["Vile Lasher"] = "Azotador vil"
L["Vile Rothexer"] = "Putrihechicera vil"
L["Vilebark Walker"] = "Caminante Cortezavil"
L["Vileshard Chunk"] = "Kacho Pizcavil"
L["Vileshard Crawler"] = "Reptador Pizcavil"
L["Vileshard Hulk"] = "Mole Pizcavil"
L["Vilethorn Blossom"] = "Flor Espinavil"
L["Viletongue Belcher"] = "Eructador Lenguavil"
--[[Translation missing --]]
L["Viqgoth"] = "Viqgoth"
L["Viq'Goth"] = "Viq'Goth"
L["Virtuous Lady"] = "Dama virtuosa"
L["Virulax Blightweaver"] = "Hilaañublos virulax"
L["Viz'aduum the Watcher"] = "Viz'aduum el Observador"
--[[Translation missing --]]
L["Vizier Jin'bak"] = "Vizier Jin'bak"
--[[Translation missing --]]
L["Void Ascendant"] = "Void Ascendant"
--[[Translation missing --]]
L["Void Bound Despoiler"] = "Void Bound Despoiler"
--[[Translation missing --]]
L["Void Bound Howler"] = "Void Bound Howler"
L["Void Discharge"] = "Descarga de Vacío"
L["Void Flayer"] = "Despellejador del Vacío"
--[[Translation missing --]]
L["Void Fragment"] = "Void Fragment"
L["Void Spawn"] = "Engendro del Vacío"
--[[Translation missing --]]
L["Void Speaker Eirich"] = "Void Speaker Eirich"
--[[Translation missing --]]
L["Void Touched Elemental"] = "Void Touched Elemental"
--[[Translation missing --]]
L["Void-Cursed Crusher"] = "Void-Cursed Crusher"
--[[Translation missing --]]
L["Voidrider"] = "Voidrider"
--[[Translation missing --]]
L["Voidstone Awakened"] = "Voidstone Awakened"
--[[Translation missing --]]
L["Voidstone Monstrosity"] = "Voidstone Monstrosity"
L["Void-Touched Emissary"] = "Emisaria tocada por el Vacío"
L["Voidweaver Mal'thir"] = "Tejevacío mal'thir"
--[[Translation missing --]]
L["Volatile Energy"] = "Volatile Energy"
L["Volatile Memory"] = "Recuerdo volátil"
--[[Translation missing --]]
L["Volatile Sapling"] = "Volatile Sapling"
L["Volcanic"] = "Volcánica"
L["Vol'kaal"] = "Vol'kaal"
L["Volkhan"] = "Volkhan"
L["Vol'zith the Whisperer"] = "Vol'zith la Susurradora"
--[[Translation missing --]]
L["Voracious Gorger"] = "Voracious Gorger"
--[[Translation missing --]]
L["VortexPinnacle"] = "Vortex Pinnacle"
--[[Translation missing --]]
L["vortexPinnacleShortName"] = "VP"
--[[Translation missing --]]
L["Vx"] = "Vx"
L["Vy Relic"] = "Reliquia Vy"
--[[Translation missing --]]
L["Walk of the Makers"] = "Walk of the Makers"
--[[Translation missing --]]
L["Wandering Candle"] = "Wandering Candle"
--[[Translation missing --]]
L["Wandering Pulsar"] = "Wandering Pulsar"
L["Wandering Shellback"] = "Lomocoraza deambulante"
L["Wanton Sapper"] = "Zapadora maliciosa"
--[[Translation missing --]]
L["War Lynx"] = "War Lynx"
L["War Ohuna"] = "Ohuna de guerra"
L["Warlord Parjesh"] = "Señor de la guerra Parjesh"
L["Warlord Sargha"] = "Señora de la guerra Sargha"
--[[Translation missing --]]
L["Warning"] = "Warning"
--[[Translation missing --]]
L["WARNING_OLD_DUNGEON_IMPORT"] = "This route is from a dungeon that is not available in the current version of MDT. Install MDT Legacy to import this route."
L["Warp Shade"] = "Sombra de distorsión"
L["Warp Stalker"] = "Acechador de distorsión"
L["Waste Pipes"] = "Tubos de Desagüe"
L["Waste Processing Unit"] = "Unidad de procesado de desperdicios"
--[[Translation missing --]]
L["Wastelander Farstalker"] = "Wastelander Farstalker"
--[[Translation missing --]]
L["Wastelander Pactspeaker"] = "Wastelander Pactspeaker"
--[[Translation missing --]]
L["Wastelander Phaseblade"] = "Wastelander Phaseblade"
--[[Translation missing --]]
L["Wastelander Ritualist"] = "Wastelander Ritualist"
--[[Translation missing --]]
L["Wastes Creeper"] = "Wastes Creeper"
L["Watcher Gashra"] = "Vigía Gashra"
L["Watcher Irideus"] = "Vigía Irideus"
L["Watcher Narjil"] = "Vigía Narjil"
L["Watcher Silthik"] = "Vigía Silthik"
L["Watchful Inquisitor"] = "Inquisidor vigilante"
L["Waterlogged Soul Guard"] = "Guardián de almas calado"
--[[Translation missing --]]
L["Waterworks Crocolisk"] = "Waterworks Crocolisk"
L["Waycrest Manor"] = "Mansión Crestavía"
L["Waycrest Reveler"] = "Juerguista de los Crestavía"
--[[Translation missing --]]
L["waycrestManorShortName"] = "WCM"
L["wcmWorldquestNote"] = "Nota en G52:%sG52 no estará presente mientras la misión del mundo Matriarca Christiane esta activa"
L["Weald Shimmermoth"] = "Polilla brillante de foresta"
L["Weaponized Crawler"] = "Reptador armado"
L["Weapons Tester"] = "Probador de armas"
--[[Translation missing --]]
L["Web Marauder"] = "Web Marauder"
L["Welding Bot"] = "Sueldabot"
--[[Translation missing --]]
L["Whisper of Fate"] = "Whisper of Fate"
L["Wholesome Hostess"] = "Anfitriona saludable"
L["Wicked Oppressor"] = "Opresora perversa"
L["Wild Lasher"] = "Azotador salvaje"
L["Wild Vortex"] = "Vórtice salvaje"
L["Wilted Oak"] = "Roble marchito"
L["Windspeaker Heldis"] = "Hablavientos Heldis"
--[[Translation missing --]]
L["Wing Leader Ner'onok"] = "Wing Leader Ner'onok"
--[[Translation missing --]]
L["Winged Carrier"] = "Winged Carrier"
L["Winter Revenant"] = "Aparecido invernal"
L["Winter Rumbler"] = "Estruendor invernal"
L["Wise Mari"] = "Maro el Sabio"
L["Wither Biter"] = "Mordedora marchita"
--[[Translation missing --]]
L["Wither Slasher"] = "Wither Slasher"
L["Witherbark"] = "Cortezamustia"
L["Withered Fiend"] = "Maligno Marchito"
L["Withered Manawraith"] = "Espectro de maná Marchito"
L["Witherling"] = "Vástago marchito"
L["Wo Relic"] = "Reliquia Wo"
--[[Translation missing --]]
L["Worker Bee"] = "Worker Bee"
L["Workshop Defender"] = "Defensor del taller"
L["Wrath of Azshara"] = "Cólera de Azshara"
--[[Translation missing --]]
L["Wrath of the Lich King"] = "Wrath of the Lich King"
L["Wrathguard Bladelord"] = "Señor de las espadas guardia de cólera"
L["Wrathguard Felblade"] = "Guardia de cólera hoja mácula"
L["Wrathguard Flamebringer"] = "Clamallamas guardia de cólera"
L["Wrathguard Invader"] = "Invasor guardia de cólera"
L["Wretched Belcher"] = "Eructador desdichado"
L["Wretched Plagueborer"] = "Perforapeste desdichado"
--[[Translation missing --]]
L["Wriggling Darkspawn"] = "Wriggling Darkspawn"
L["Wyrmtongue Scavenger"] = "Carroñero Lenguavermis"
L["Wyrmtongue Trickster"] = "Tramposo Lenguavermis"
L["Xav the Unfallen"] = "Xav el Invicto"
L["XB-488 Disposalbot"] = "Residuobot XG-488"
L["XD-175 Compactobot"] = "Compactobot XD-175"
--[[Translation missing --]]
L["Xephitik"] = "Xephitik"
L["Xevozz"] = "Xevozz"
L["Xiang"] = "Xiang"
--[[Translation missing --]]
L["Xin the Weaponmaster"] = "Xin the Weaponmaster"
L["Xira the Underhanded"] = "Xira la Furtiva"
L["XR-949 Salvagebot"] = "Recuperobot XR-949"
L["XT-002 Deconstructor"] = "Desarmador XA-002"
L["Yalnu"] = "Yalnu"
--[[Translation missing --]]
L["Yan-Zhu the Uncasked"] = "Yan-Zhu the Uncasked"
L["Yazma"] = "Yazma"
--[[Translation missing --]]
L["Yeasty Brew Alemental"] = "Yeasty Brew Alemental"
--[[Translation missing --]]
L["Yes Man"] = "Yes Man"
L["Ymirjar Berserker"] = "Rabioso Ymirjar"
L["Ymirjar Dusk Shaman"] = "Chamán del ocaso Ymirjar"
L["Ymirjar Flesh Hunter"] = "Cazador de carne Ymirjar"
L["Ymirjar Harpooner"] = "Arponero Ymirjar"
L["Ymirjar Necromancer"] = "Nigromante Ymirjar"
L["Ymirjar Savage"] = "Salvaje Ymirjar"
L["Ymirjar Warrior"] = "Guerrero Ymirjar"
L["Ymirjar Witch Doctor"] = "Médico brujo Ymirjar"
L["Ymiron, the Fallen King"] = "Ymiron, el Rey Caído"
L["Yogg-Saron"] = "Yogg-Saron"
L["You are using MDT. You rock!"] = "Estas usando MDT. Molas!"
L["You can always return to the current Live Session preset by clicking the 'Return to Live' button next to the preset-dropdown"] = "Siempre puede volver a la ruta actual de la Sesión en vivo haciendo click en el botón 'Volver a Directo' al lado del menú desplegable de rutas"
L["You can choose from different color palettes in the automatic pull coloring settings menu."] = "Puedes elegir entre diferentes paletas de colores en el menú de configuración del coloreado automático de pulls."
L["You can cycle through different floors by holding CTRL and using the mousewheel."] = "Puedes recorrer diferentes pisos manteniendo presionada la tecla CTRL y usando la rueda del ratón."
L["You can cycle through dungeons by holding ALT and using the mousewheel."] = "Puedes alternar las mazmorras manteniendo ALT y usando la rueda del ratón."
L["Young Storm Dragon"] = "Dragón de tormenta joven"
--[[Translation missing --]]
L["Yu'lon"] = "Yu'lon"
L["Zanazal the Wise"] = "Zanazal el Sabio"
L["Zanchuli Witch-Doctor"] = "Médica bruja Zanchuli"
--[[Translation missing --]]
L["Zealous Templar"] = "Zealous Templar"
L["Zoggosh"] = "Zoggosh"
L["Zo'gron"] = "Zo'gron"
L["Zolramus Bonecarver"] = "Tallahuesos de Zolramus"
L["Zolramus Bonemender"] = "Sueldahuesos de Zolramus"
L["Zolramus Gatekeeper"] = "Guardián de la puerta de Zolramus"
L["Zolramus Necromancer"] = "Nigromante de Zolramus"
L["Zolramus Siphoner"] = "Succionadora de Zolramus"
L["Zolramus Sorcerer"] = "Hechicero de Zolramus"
--[[Translation missing --]]
L["Zoom"] = "Zoom"
--[[Translation missing --]]
L["zoomIn"] = "In"
--[[Translation missing --]]
L["zoomOut"] = "Out"
L["Zo'phex"] = "Zo'phex"
L["Zul'gamux"] = "Zul'gamux"
--[[Translation missing --]]
L["Zul'Gurub"] = "Zul'Gurub"
L["Zuraal the Ascended"] = "Zuraal el Ascendido"
L["Zuramat the Obliterator"] = "Zuramat el Obliterador"

